def hello():
    print("Hi")