# 📚 CODE_REFERENCE_INDEX.md

主要コードの抜粋索引です。


## src\opencodeinterpreter_webui.py

```python
# 📁 ファイル名: opencodeinterpreter_webui.py
# 📂 フォルダ構成: /src/opencodeinterpreter_webui.py
# 🕠 目的: Gradio UIにユニットテスト生成 + 修正サイクル + テスト一括実行を統合

import gradio as gr
import os
import logging
from dotenv import load_dotenv
from openai import OpenAI
from uuid import uuid4

# --- 独自モジュール ---
from nexuscore.code_interpreter.sandbox_runner import run_and_repair, run_test_and_repair
from nexuscore.utils.diff_tools import generate_diff_report, score_code_improvement
from nexuscore.utils.test_generator import generate_unit_tests
from nexuscore.utils.file_utils import (
    extract_file_content,
    handle_uploaded_files,
    file_list_display,
    extract_zip_texts,
    download_history,
)

# --- Whisper 音声認識用 ---
def process_audio(audio_file):
    try:
        if audio_file is None:
            raise gr.Warning("録音がキャンセルされました。")
        with open(audio_file, "rb") as f:
            transcript = client.audio.transcriptions.create(
                model="whisper-1",
                file=f,
                language="ja",
                response_format="text"
            )
        return transcript
    except gr.Warning as w:
        raise w
    except Exception as e:
        logging.error(f"音声処理エラー: {str(e)}")
        raise gr.Error(f"音声処理エラー: {e}")

# --- Gradioユーティリティ関数 ---
def update_uuid(dialog_info):
    new_uuid = str(uuid4())
    logging.info(f"allocating new uuid {new_uuid} for conversation...")
    return [new_uuid, dialog_info[1]]

def history_to_messages(history):
    messages = []
    for msg in history:
        if isinstance(msg, dict) and "role" in msg and "content" in msg:
            messages.append(msg)
        elif isinstance(msg, (list, tuple)) and len(msg) == 2:
            messages.append({"role": "user", "content": msg[0]})
            messages.append({"role": "assistant", "content": msg[1]})
    return messages

def bot(user_message, files, history, dialog_info, frontend_preview):
    try:
        if files is None:
            files = []
        file_info, file_content, file_types, frontend_preview_str = handle_uploaded_files(files)
        user_input = user_message
        if file_info:
            user_input += "\n" + file_info
        if file_content:
            user_input += f"\n[\u30d5\u30a1\u30a4\u30eb\u5185\u5bb9（4000\u6587\u5b57\u307e\u3067）]\n{file_content[:4000]}"

        prev_messages = history if history and isinstance(history[0], dict) else history_to_messages(history)
        ai_response = "ファイルまたはテキストを受け取りました。"

        chatbot_value = prev_messages + [
            {"role": "user", "content": user_message},
            {"role": "assistant", "content": ai_response}
        ]
        return chatbot_value, chatbot_value, dialog_info, frontend_preview_str

    except Exception as e:
        logging.error(f"bot error: {e}")
        raise gr.Error(f"エラー: {e}")

def reset_textbox():
    return gr.update(value="")

def clear_history(history, dialog_info):
    return [], [], update_uuid(dialog_info), ""

# --- ユニットテスト生成 ---
def generate_and_show_tests(code: str) -> str:
    try:
        return generate_unit_tests(code)
    except Exception as e:
        logging.error(f"ユニットテスト生成失敗: {e}")
        return f"エラー: {e}"

# --- Gradio UI構成 ---
def gradio_launch():
    with gr.Blocks() as demo:
        with gr.Tabs():
            # タブ1: 修正・テスト
            with gr.Tab("🛠 修正サイクル"):
                code_input = gr.Textbox(label="💡 入力コード（エラーあり可）", lines=10)
                btn_testgen = gr.Button("🧪 ユニットテスト生成")
                test_output = gr.Code(label="📄 生成されたユニットテスト")
                btn_run_repair = gr.Button("🔁 修正のみ実行")
                btn_run_test_repair = gr.Button("🧪 修正+\u30c6スト一括")
                output_code = gr.Code(label="✅ 修正済みコード or レポート")

                btn_testgen.click(fn=generate_and_show_tests, inputs=code_input, outputs=test_output)
                btn_run_repair.click(fn=run_and_repair, inputs=code_input, outputs=output_code)
                btn_run_test_repair.click(fn=run_test_and_repair, inputs=code_input, outputs=output_code)

            # タブ2: チャット＋ファイル分析
            with gr.Tab("💬 Chat + ファイル分析"):
                chatbot = gr.Chatbot(label="OpenCodeInterpreter", height=600, type="messages")
                msg = gr.Textbox(placeholder="メッセージ入力 or 音声録音", scale=5)
                file_input = gr.File(file_types=[".py", ".txt", ".md", ".json", ".zip"], file_count="multiple")
                file_list = gr.Textbox(label="アップロードファイル一覧", interactive=False, max_lines=10)
                audio_input = gr.Audio(sources="microphone", type="filepath", label="音声録音")
                frontend_preview = gr.Textbox(label="ファイル先頭プレビュー（100字）")
                submit = gr.Button("Submit")
                clear = gr.Button("Clear")
                download_btn = gr.DownloadButton("履歴ダウンロード")
                session_state = gr.State([])
                dialog_info = gr.State(["", 0])

                demo.load(update_uuid, dialog_info, dialog_info)
                file_input.change(file_list_display, inputs=file_input, outputs=file_list)
                audio_input.change(process_audio, inputs=audio_input, outputs=msg)
                submit.click(bot, [msg, file_input, session_state, dialog_info, frontend_preview], [chatbot, session_state, dialog_info, frontend_preview])
                clear.click(lambda h, d: ([], [], update_uuid(d), ""), [session_state, dialog_info], [chatbot, session_state, dialog_info, frontend_preview])
                download_btn.click(download_history, [session_state], download_btn)

        demo.queue(max_size=20)
        demo.launch(share=True, inbrowser=True)

# --- 起動 ---
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    load_dotenv()
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        raise RuntimeError("OPENAI_API_KEY が未設定です。.envを確認してください。")
    client = OpenAI(api_key=api_key)
    gradio_launch()

```


## app\routes.py

```python
# app/routes.py
from flask import Blueprint, render_template, redirect, url_for, request, flash, Response
from app import db
from app.models import Product                      # ← models.py で定義した ORM クラス[1]
from app.forms  import ProductForm                  # ← WTForms フォーム
import csv, io
from datetime import datetime

bp = Blueprint('main', __name__)                    # ① Blueprint 宣言

# --------------------------------------------------
# ② 一覧＋新規登録
# --------------------------------------------------
@bp.route('/products', methods=['GET', 'POST'])
def manage_products():
    form = ProductForm()
    if form.validate_on_submit():                   # 追加ボタンが押されたとき
        product = Product(
            name= form.name.data,
            brand=form.brand.data,
            purchase_price=form.purchase_price.data,
            selling_price =form.selling_price.data,
            supplier_url  =form.supplier_url.data,
            image_url     =form.image_url.data,
            stock_status  =form.stock_status.data,
            transaction_fee=form.transaction_fee.data,
            shipping_cost   =form.shipping_cost.data,
            customs_duty    =form.customs_duty.data,
            procurement_fee =form.procurement_fee.data,
        )
        # 利益をその場で計算して保存
        product.profit = product.calculate_profit()      # [1]
        db.session.add(product)
        db.session.commit()
        flash('商品を登録しました', 'success')
        return redirect(url_for('main.manage_products'))

    products = Product.query.all()
    return render_template('products/manage.html',
                           form=form, products=products)

# --------------------------------------------------
# ③ CSV 取込
# --------------------------------------------------
@bp.route('/products/import', methods=['POST'])
def import_csv():
    if 'file' not in request.files:
        flash('CSV ファイルがありません', 'error')
        return redirect(url_for('main.manage_products'))

    f = request.files['file']
    if not f.filename.endswith('.csv'):
        flash('CSV だけアップロードできます', 'error')
        return redirect(url_for('main.manage_products'))

    stream  = io.StringIO(f.stream.read().decode('utf-8-sig'))
    reader  = csv.DictReader(stream)
    created = 0
    for row in reader:
        # 必須カラムチェック
        if not all(k in row for k in ('name', 'purchaseprice', 'sellingprice')):
            flash('必須列が不足しています', 'error')
            return redirect(url_for('main.manage_products'))

        p = Product(
            name = row['name'],
            brand= row.get('brand', ''),
            purchase_price=float(row['purchaseprice']),
            selling_price =float(row['sellingprice']),
            supplier_url  =row.get('supplierurl', ''),
            image_url     =row.get('imageurl', ''),
            stock_status  =row.get('stockstatus', 'true').lower() in ('true','1','yes'),
            transaction_fee=float(row.get('transactionfee',0)),
            shipping_cost   =float(row.get('shippingcost',0)),
            customs_duty    =float(row.get('customsduty',0)),
            procurement_fee =float(row.get('procurementfee',0)),
        )
        p.profit = p.calculate_profit()                 # [1]
        db.session.add(p)
        created += 1
    db.session.commit()
    flash(f'{created} 件取り込みました', 'success')
    return redirect(url_for('main.manage_products'))

# --------------------------------------------------
# ③ CSV 書出し
# --------------------------------------------------
@bp.route('/products/export')
def export_csv():
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow([
        'name','brand','purchaseprice','sellingprice',
        'transactionfee','shippingcost','customsduty','procurementfee',
        'supplierurl','imageurl','stockstatus'
    ])
    for p in Product.query.all():
        writer.writerow([
            p.name, p.brand, p.purchase_price, p.selling_price,
            p.transaction_fee, p.shipping_cost, p.customs_duty, p.procurement_fee,
            p.supplier_url, p.image_url, 'true' if p.stock_status else 'false'
        ])
    output.seek(0)
    data = '\ufeff' + output.getvalue()                  # UTF-8 BOM 付き[1]
    dt   = datetime.now().strftime('%Y%m%d%H%M%S')
    return Response(
        data, mimetype='text/csv',
        headers={'Content-Disposition': f'attachment; filename=products_{dt}.csv'}
    )

# --------------------------------------------------
# ④ 編集・削除
# --------------------------------------------------
@bp.route('/products/<int:pid>/edit', methods=['GET','POST'])
def edit_product(pid):
    product = Product.query.get_or_404(pid)
    form = ProductForm(obj=product)
    if form.validate_on_submit():
        form.populate_obj(product)
        product.profit = product.calculate_profit()
        db.session.commit()
        flash('更新しました', 'success')
        return redirect(url_for('main.manage_products'))
    return render_template('products/edit.html', form=form, product=product)

@bp.route('/products/<int:pid>/delete', methods=['POST'])
def delete_product(pid):
    product = Product.query.get_or_404(pid)
    db.session.delete(product)
    db.session.commit()
    flash('削除しました', 'success')
    return redirect(url_for('main.manage_products'))

# --------------------------------------------------
# ⑤ ルートリダイレクト
# --------------------------------------------------
@bp.route('/')
def index():
    return redirect(url_for('main.manage_products'))

```


## src\realtime_whisper.py

```python
# ファイル名例: realtime_whisper.py
# 必要なライブラリ: sounddevice, numpy, noisereduce, librosa, soundfile, openai, scipy
# インストール例:
# pip install sounddevice numpy noisereduce librosa soundfile openai scipy

import sounddevice as sd
import numpy as np
import threading
import time
import noisereduce as nr
import librosa
import soundfile as sf
import tempfile
import openai
from scipy.io.wavfile import write
import os

# Whisper APIキーは環境変数から取得
openai.api_key = os.getenv("OPENAI_API_KEY")

# --- メモ ---
# 1. エンターキーで録音終了、最大60秒まで録音
# 2. 録音後、ノイズリダクション＋音量正規化を自動実行
# 3. Whisper APIで日本語文字起こし
# 4. 一時ファイルは自動削除

def record_and_process_audio(max_duration=60, sample_rate=16000):
    print(f"録音開始: 最大{max_duration}秒、エンターキーで終了")
    recording = []
    event = threading.Event()
    start_time = time.time()

    def callback(indata, frames, t, status):
        if time.time() - start_time > max_duration:
            event.set()
            raise sd.CallbackAbort
        recording.append(indata.copy())

    def record_thread():
        with sd.InputStream(samplerate=sample_rate, channels=1, callback=callback):
            event.wait()

    def key_thread():
        input()  # エンターキー待ち
        event.set()

    t1 = threading.Thread(target=record_thread)
    t2 = threading.Thread(target=key_thread)
    t1.start()
    t2.start()
    t2.join(timeout=max_duration)
    t1.join(timeout=1)

    if not recording:
        return None

    audio_np = np.concatenate(recording, axis=0).flatten()

    # 一時ファイルに保存
    temp_wav = tempfile.NamedTemporaryFile(suffix='.wav', delete=False)
    write(temp_wav.name, sample_rate, audio_np)

    # ノイズ除去・音量正規化処理
    y, sr = librosa.load(temp_wav.name, sr=sample_rate)
    noise_sample = y[:int(sr*0.5)]  # 最初の0.5秒をノイズと仮定
    y_denoised = nr.reduce_noise(y=y, y_noise=noise_sample, sr=sr, stationary=False)
    y_normalized = librosa.util.normalize(y_denoised)

    # 処理後の音声を別ファイルに保存
    processed_wav = tempfile.NamedTemporaryFile(suffix='_processed.wav', delete=False)
    sf.write(processed_wav.name, y_normalized, sr)

    # 元の録音ファイルは削除
    temp_wav.close()
    os.unlink(temp_wav.name)

    return processed_wav.name

def transcribe_with_whisper(audio_path):
    with open(audio_path, "rb") as f:
        transcript = openai.audio.transcriptions.create(
            model="whisper-1",
            file=f,
            language="ja",
            response_format="text"
        )
    return transcript

if __name__ == '__main__':
    wav_path = record_and_process_audio(max_duration=60)
    if wav_path:
        print("録音・前処理完了、Whisperで文字起こし中...")
        text = transcribe_with_whisper(wav_path)
        print("認識結果:")
        print(text)
        os.unlink(wav_path)  # 処理後ファイル削除
    else:
        print("録音がキャンセルされました、または音声がありませんでした。")

```


## src\streamlit_legacy.py

```python
import streamlit as st
from openai import OpenAI
from dotenv import load_dotenv
import os
import io

# 音声録音用
from streamlit_mic_recorder import mic_recorder

# .envファイルからAPIキーを読み込む
load_dotenv()
api_key = os.getenv("OPENAI_API_KEY")
client = OpenAI(api_key=api_key)

st.title("ChatGPT風チャット＋音声入力＋ファイルアップロード")

# セッションステートでチャット履歴を管理
if "messages" not in st.session_state:
    st.session_state.messages = []

# ファイルアップロード
uploaded_files = st.file_uploader("ファイルをアップロード（複数可）", accept_multiple_files=True)
if uploaded_files:
    for file in uploaded_files:
        st.write(f"アップロード: {file.name}")
        # テキストファイルは内容表示
        if file.type.startswith("text"):
            content = file.read().decode("utf-8", errors="ignore")
            st.text_area(f"{file.name}の内容", content, height=100)
        # バイナリの場合はファイル名のみ表示

# 音声入力（録音）
st.subheader("音声入力（録音→Whisperで文字起こし）")
audio_data = mic_recorder(
    start_prompt="録音開始",
    stop_prompt="録音停止",
    format="webm",
    key="mic"
)

if audio_data:
    st.audio(audio_data["bytes"], format="audio/webm")
    audio_bytes_io = io.BytesIO(audio_data["bytes"])
    audio_bytes_io.name = "audio.webm"
    try:
        transcript = client.audio.transcriptions.create(
            model="whisper-1",
            file=audio_bytes_io,
            language="ja"
        )
        st.success("文字起こし結果:")
        st.write(transcript.text)
        # 文字起こし結果をチャット履歴に追加
        st.session_state.messages.append({"role": "user", "content": transcript.text})
    except Exception as e:
        st.error(f"文字起こしエラー: {e}")

# チャット履歴の表示
for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])

# ユーザーからの入力受付
if prompt := st.chat_input("メッセージを入力してください"):
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)

    # OpenAI APIでAI応答をストリーミング生成
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {"role": "system", "content": "あなたは有能なアシスタントです。"},
            *st.session_state.messages
        ],
        stream=True
    )

    with st.chat_message("assistant"):
        full_response = ""
        placeholder = st.empty()
        for chunk in response:
            content = getattr(chunk.choices[0].delta, "content", None)
            if content:
                full_response += content
                placeholder.markdown(full_response + "▌")
        placeholder.markdown(full_response)

    st.session_state.messages.append({"role": "assistant", "content": full_response})

```


## app\__init__.py

```python
# フォルダ: app
# ファイル名: __init__.py
# メモ: FlaskのSECRET_KEYをハードコーディングから環境変数読み込みに変更し、セキュリティを向上させました。
#      他の設定値も併せて環境変数から読み込めるように改良しています。

import os
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from dotenv import load_dotenv

# .envファイルから環境変数を読み込む
# これにより、.envファイルに記述した設定がos.getenv()で利用可能になります。
load_dotenv()

db = SQLAlchemy()

def create_app():
    app = Flask(__name__)

    # --- 基本設定 ---
    # ◀️ ハードコーディングされた秘密鍵を環境変数から読み込むように修正
    #    os.getenvの第2引数は、環境変数が設定されていない場合のデフォルト値です。
    #    本番環境では必ず強固なキーを環境変数に設定してください。
    app.config["SECRET_KEY"] = os.getenv("FLASK_SECRET_KEY", "a-very-secret-key-for-development-only")
    
    # データベースのURIも環境変数から取得するように変更
    app.config["SQLALCHEMY_DATABASE_URI"] = os.getenv("DATABASE_URI", "sqlite:///db.sqlite3")

    # --- Celery 用設定 ---
    # Celeryの接続情報も環境変数から取得するように変更
    app.config.from_mapping(
        CELERY=dict(
            broker_url=os.getenv("CELERY_BROKER_URL", "redis://localhost:6379/0"),
            result_backend=os.getenv("CELERY_RESULT_BACKEND", "redis://localhost:6379/0"),
            task_ignore_result=True,
        )
    )

    # --- 拡張機能の初期化 ---
    db.init_app(app)

    # Blueprint の登録（ここで１回だけ）
    from .routes import bp as main_bp
    app.register_blueprint(main_bp)

    # Celery を紐付け
    from .extensions import celery_init_app
    celery_init_app(app)

    return app

```


## src\history_manager.py

```python
# ファイル名: history_manager.py
import json
import os
from datetime import datetime
from typing import List, Dict, Any

class HistoryManager:
    def __init__(self, history_dir="history", prefix="history_"):
        self.history_dir = history_dir
        self.prefix = prefix
        os.makedirs(history_dir, exist_ok=True)
        self.history_path = self._generate_new_path()
        self.state_history: List[Dict[str, Any]] = []
        self.current_index: int = -1

    def _generate_new_path(self):
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        return os.path.join(self.history_dir, f"{self.prefix}{timestamp}.json")

    def add_state(self, state: Dict[str, Any]):
        # 未来の履歴を切り捨ててから追加
        self.state_history = self.state_history[:self.current_index + 1]
        self.state_history.append(state)
        self.current_index += 1
        self.save_history()

    def rollback(self):
        if self.current_index > 0:
            self.current_index -= 1
            self.save_history()
            return self.state_history[self.current_index]
        else:
            print("Already at oldest state")
            return self.state_history[0] if self.state_history else None

    def get_current_state(self):
        if self.current_index >= 0:
            return self.state_history[self.current_index]
        return None

    def save_history(self):
        with open(self.history_path, "w", encoding="utf-8") as f:
            json.dump({
                "history": self.state_history,
                "current_index": self.current_index
            }, f, ensure_ascii=False, indent=2)

```


## src\main_ui.py

```python
import os
import sys
import gradio as gr

# src ディレクトリの相対パスから modules と gradio_app を含める
sys.path.append(os.path.join(os.path.dirname(__file__), "./gradio_app"))
sys.path.append(os.path.join(os.path.dirname(__file__), "./modules"))

# 各UIタブをインポート
from app_ui import launch_app_ui
from revision_loop import launch_revision_ui
from streamlit_migrated_tab import tab_streamlit_port
from nexuscore.modules.whisper_handler import transcribe_audio  # Whisper処理（明示的なインポート）

# interactive_generator が存在する場合にのみ読み込む
try:
    from interactive_generator import app as generator_app
    has_generator = True
except ImportError:
    has_generator = False

def launch_all_tabs():
    with gr.Blocks(title="OpenCodeInterpreter") as demo:
        with gr.Tab("🧠 コード修正 + テスト"):
            launch_app_ui()

        with gr.Tab("🔁 修正ループ"):
            launch_revision_ui()

        with gr.Tab("🎙️ Whisper + GPTチャット"):
            tab_streamlit_port()

        if has_generator:
            with gr.Tab("🪄 生成タブ（任意）"):
                demo += generator_app  # ← generator_app を .launch() ではなく Blocks としてマウント

    demo.launch()

if __name__ == "__main__":
    launch_all_tabs()

```


## src\sandbox_executor.py

```python
# ファイル名: sandbox_executor.py
# メモ:
# - run_code_in_sandbox()を呼び出し、標準出力・標準エラー・出力ファイルを返す
# - エラー・タイムアウトも判定しやすい
# - opencodeinterpreter_webui.py等からimportして使う

from sandbox_runner import run_code_in_sandbox

def execute_code_and_return_output(
    code,
    jupyter_state=None,      # 互換性のため残しているが未使用
    lang="python",
    input_files=None,
    output_files=None,
    timeout=10,
    cpu="0.5",
    memory="256m"
):
    """
    サンドボックスでコードを実行し、結果・エラー・出力ファイルを返す
    """
    try:
        stdout, stderr, returncode, outputs = run_code_in_sandbox(
            code=code,
            lang=lang,
            input_files=input_files,
            output_files=output_files,
            timeout=timeout,
            cpu=cpu,
            memory=memory
        )
        if returncode == 0:
            return stdout, "OK", outputs
        elif stderr == "Timeout":
            return "Timeout", "Timeout", outputs
        else:
            return stderr, "Error", outputs
    except Exception as e:
        return str(e), "Error", {}

```


## tools\code_export_gemini_fixed.py

```python
# ======================================================================
# ファイル名: code_export_gemini_allpy_final.py
# 日付: 2025-08-26 (rev7.1 all-py-first)
#
# 機能概要:
# Gemini / GPT-5 等のLLM向けに、ソースと構造マニフェストを最適化して
# エクスポートするユーティリティ（Gradio UI付き）。
#
# ✅ 改良点（本版での要求反映）
# - 【Geminiでも*.pyを最優先】まず可能な限り .py を詰める挙動へ切替（一次充填を .py 限定）
# - Manifest選択時は常に「フォルダ展開＋ZIP」を両生成
# - プロファイル別ポリシー（Gemini ≤10MB / GPT-5 ≤50MB / Custom）
# - ドライラン（サイズ/件数プレビュー）＆詳細ログ（ZIPサイズ推移）
# - Custom 目標サイズUIは Custom 選択時のみ表示
# - 出力保持（ZIP最新8世代、Manifest最新10世代）
# - （任意）Windowsレジストリで直近設定を保存/復元
#
# 使用ソフト/前提:
# - Python 3.9+（推奨3.10+）
# - pip install gradio networkx  （networkxは未導入でも動作）
# - Git（任意: PROJECT_CHRONICLE.md 生成に利用）
# - VS Code 等の任意エディタ
#
# 実行:
#   python code_export_gemini_allpy_final.py
#   → ブラウザが http://127.0.0.1:7860 を開きます。
#
# 出力先:
#   <プロジェクトルート>/exports/
#   - <prefix>_gemini_YYYYMMDD_HHMMSS.zip
#   - <prefix>_manifest_YYYYMMDD_HHMMSS/ 以下に README.md / PROJECT_CHRONICLE.md /
#     CODE_STRUCTURE_MANIFEST.md / included_source/ を展開
#
# レジストリ（Windows任意）:
#   パス: HKEY_CURRENT_USER\Software\NexusCore\CodeExport
#   値  : LastProjectDir (SZ), LastProfile (SZ), LastSizeProfile (SZ), LastCustomMB (SZ)
# ======================================================================

from __future__ import annotations

import ast
import datetime
import fnmatch
import os
import re
import shutil
import subprocess
import traceback
import zipfile
import io
from collections import defaultdict
from math import log2
from pathlib import Path
from threading import Event
from typing import List, Tuple, Dict, Set, Any, Optional

import gradio as gr

try:
    import networkx as nx  # noqa: F401  # 将来の構造解析で使用予定
except Exception:
    nx = None

# --- Windows Registry (optional) ----------------------------------------
WINREG_AVAILABLE = False
try:
    import winreg  # type: ignore
    WINREG_AVAILABLE = True
except Exception:
    pass

REG_PATH = r"Software\NexusCore\CodeExport"


def _reg_get(name: str, default: Optional[str] = None) -> Optional[str]:
    if not WINREG_AVAILABLE:
        return default
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, REG_PATH, 0, winreg.KEY_READ) as k:
            val, _ = winreg.QueryValueEx(k, name)
            return str(val)
    except Exception:
        return default


def _reg_set(name: str, value: str) -> None:
    if not WINREG_AVAILABLE:
        return
    try:
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, REG_PATH) as k:
            winreg.SetValueEx(k, name, 0, winreg.REG_SZ, str(value))
    except Exception:
        pass


# === CONFIG ==============================================================

PROFILES = {
    "Gemini Manifest Pack": {
        "description": "【推奨】単一ZIP＋同内容のフォルダを生成。最重要コードを自動選抜し、構造マニフェストを同梱。",
        "mode": "manifest",
    },
    "Gemini Structured Pack": {
        "description": "元のディレクトリ構造を維持してZIP分割。大規模向け。",
        "mode": "structured",
    },
    "Gemini Legacy Pack": {
        "description": "全ソースを単一ファイルに結合する簡易パック。小規模向け。",
        "mode": "combined",
    },
}
DEFAULT_PROFILE = "Gemini Manifest Pack"

# --- パッケージング設定 --------------------------------------------------
MB = 1024 * 1024
KB = 1024

MANIFEST_INCLUDED_FILES_MAX = 120
ALWAYS_INCLUDE_FILES = {"requirements.txt", "pyproject.toml", ".env.template", "package.json"}
KEEP_FILES = ALWAYS_INCLUDE_FILES

# ===== プロファイル別ルール =====
PROFILE_RULES = {
    "gemini_10mb": {
        "target_bytes": int(float(os.getenv("GEMINI_TARGET_MB", "9.8")) * MB),
        "floor_bytes": int(float(os.getenv("GEMINI_FLOOR_MB", "9.0")) * MB),
        "allow_site_packages": False,
        "fallback_binary_max_bytes": 128 * KB,
        # Geminiはノートブックや巨大アセットを極力抑制
        "extra_excludes": {
            "exported_projects", "evaluation", "history", "logs",
            "htmlcov", "htmlcov_agents", "htmlcov_detailed", "htmlcov_final", "htmlcov_full",
            "*.ipynb",
        },
        "secondary_dirs": ["app", "src", "tools", "templates", "static", "config", "data", "docs"],
        "secondary_exts": {".py", ".md", ".json", ".yml", ".yaml", ".toml", ".ini", ".cfg",
                           ".sql", ".html", ".css", ".js"},
    },
    "gpt5_50mb": {
        "target_bytes": 50 * MB,
        "floor_bytes": int(45 * MB),
        "allow_site_packages": True,
        "fallback_binary_max_bytes": 1 * MB,
        # GPT-5は.ipynb等も積極採用
        "extra_excludes": set(),
        "secondary_dirs": ["app", "src", "tools", "templates", "static", "config", "data", "docs"],
        "secondary_exts": {".md", ".json", ".yml", ".yaml", ".toml", ".cfg", ".ini", ".sql",
                           ".ipynb", ".html", ".css", ".js"},
    },
    "custom": {
        "target_bytes": 24 * MB,  # Default
        "floor_bytes": int(20 * MB),
        "allow_site_packages": True,
        "fallback_binary_max_bytes": 512 * KB,
        "extra_excludes": set(),
        "secondary_dirs": ["app", "src", "tools", "templates", "static", "config", "data", "docs"],
        "secondary_exts": {".md", ".json", ".yml", ".yaml", ".toml", ".cfg", ".ini", ".sql",
                           ".ipynb", ".html", ".css", ".js", ".py"},
    }
}

# ===== 既定の除外 =====
IGNORED_DIRS_USER = {
    ".git", "__pycache__", "node_modules", "dist", "build",
    ".venv", "venv", "env", "myenv", "openenv",
    ".idea", ".vscode", ".mypy_cache", ".pytest_cache",
    ".gradio", "exports",
}

IGNORED_FILES_USER = {".coverage", ".env", ".gitattributes", ".gitignore", "*.log"}
EXPORT_DIR_NAME = "exports"

EXTENSION_WEIGHTS = {".py": 3, ".ipynb": 2, ".md": 1}
PATH_WEIGHTS = {"src": 3, "app": 3, "lib": 2, "tools": 2, "tests": -1, "docs": -1}
MAX_LOG_LINES = 600
stop_event = Event()


# ======================================================================
# Git 年代記
# ======================================================================
class ChronicleGenerator:
    def __init__(self, roots: List[Path]):
        self.roots = roots
        self.primary_root = roots[0] if roots else Path(".")

    def generate(self) -> str:
        if not (self.primary_root / ".git").exists():
            return ""
        try:
            cmd = ["git", "log", "--date=short", "--pretty=format:%H %ad %s", "--no-merges", "--since=1.year.ago"]
            result = subprocess.run(cmd, cwd=self.primary_root, capture_output=True, text=True,
                                    encoding="utf-8", errors="ignore")
            if result.returncode != 0:
                return ""
            commits = [{"date": p[1], "subject": p[2]} for line in result.stdout.strip().split("\n")
                       if (p := line.split(" ", 2)) and len(p) == 3]
            weekly_commits: Dict[str, List[str]] = defaultdict(list)
            for commit in commits:
                commit_date = datetime.datetime.strptime(commit["date"], "%Y-%m-%d")
                week_start = commit_date - datetime.timedelta(days=commit_date.weekday())
                weekly_commits[week_start.strftime("%Y-%m-%d")].append(commit["subject"])
            md = ["# 📖 プロジェクト年代記 (AI-Generated)",
                  "\n**Git履歴に基づいてAIが自動生成した進化の記録です。**\n"]
            for week_start_str in sorted(weekly_commits.keys(), reverse=True)[:12]:
                subjects = weekly_commits[week_start_str]
                week_start_date = datetime.datetime.strptime(week_start_str, "%Y-%m-%d")
                md.append(f"---\n### EPOCH: {week_start_date.strftime('%Y年%m月%d日')} の週\n")
                md.extend([f"- {s}" for s in subjects[:3]])
                if len(subjects) > 3:
                    md.append(f"- ...他 {len(subjects) - 3} 件の改善")
                md.append("")
            return "\n".join(md)
        except Exception:
            return ""


# ======================================================================
# ユーティリティ
# ======================================================================

def sanitize_name(name: str) -> str:
    return re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", name).strip("_") or "Unknown"


def generate_project_prefix(roots: List[Path]) -> str:
    if not roots:
        return "Export"
    names = [sanitize_name(r.name) for r in roots]
    return names[0] if len(names) == 1 else "-".join(names[:2]) + (f"-etc
```


## tools\code_export_gemini_old.py

```python
# ======================================================================
# code_export_gemini.py — Gemini 10ファイル制限最適化（4ファイル構成）
# 外部共有“安全寄り”デフォルト（KEEP優先 / .envは除外）
# 2025-08-24 rev: プロジェクト年代記の自動生成機能を追加
# ======================================================================

from __future__ import annotations

import ast
import datetime
import fnmatch
import os
import re
import subprocess
import traceback
import zipfile
from collections import defaultdict, Counter
from math import log2
from pathlib import Path
from threading import Event
from typing import List, Tuple, Dict, Set, Any

import gradio as gr

try:
    import networkx as nx
except ImportError:
    nx = None

# === CONFIG (変更なし) =======================================================
KEEP_FILES: Set[str] = {
    "requirements.txt", "pyproject.toml", "project_structure.json", ".env.template",
}
IGNORED_DIRS_USER: Set[str] = {
    ".git", "__pycache__", "node_modules", "dist", "build", ".venv", "venv",
    ".idea", ".vscode", ".mypy_cache", ".pytest_cache", "htmlcov", ".gradio", "exports",
    "openenv", "myenv", "old_tool", "quality_loop_test_sandbox", "result_images",
    "sandbox_repo", "scripts", "output", "patch_history", "policy_test_sandbox",
    "project_structure_export", "quality_gate_test_sandbox", "test_cache",
}
IGNORED_FILES_USER: Set[str] = {
    ".coverage", ".env", ".env.template", ".gitattributes", ".gitignore", ".nexus_context.json",
    ".python-version", "nexus_api_server.log", "nexus_core_run.log", "orchestrator_test.log",
    "quality_gate_test_run.log", "OpenCodeInterpreter.code-workspace", "launch.bat",
    "launch_all.ps1", "launch_dev.ps1", "LICENSE", "project_chronicle.jsonl",
    "project_structure.json", "fix_imports.py", "gradio_app.py", "main_cli.py",
    "project_structure_and_code_export.py", "pytest.ini", "vscode-extension.zip",
}
EXPORT_DIR_NAME = "exports"
MAX_COMBINED_CODE_SIZE_MB = 10
WIN_PATH_CAP = 250
FILE_TYPES: Tuple[str, ...] = (
    ".py", ".ipynb", ".md", ".txt", "package.json", ".json", ".yml", ".yaml", ".toml",
)
EXTENSION_WEIGHTS = {".py": 3, ".ipynb": 2, ".md": 1}
PATH_WEIGHTS = {"src": 2, "app": 2, "lib": 1, "nexuscore": 3, "tests": -1, "docs": -1}
stop_event = Event()

# === HELPERS (変更なし) =====================================================
# ... (sanitize_name, generate_project_prefix, etc. は変更ないため省略) ...
def sanitize_name(name: str) -> str:
    invalid_chars = r'[<>:"/\\|?*\x00-\x1f]'
    s = re.sub(invalid_chars, '_', name)
    s = re.sub(r'_+', '_', s).strip('_') or "Unknown"
    return s[:50]

def generate_project_prefix(roots: List[Path]) -> str:
    if not roots: return "Export"
    names = [sanitize_name(r.name) for r in roots]
    if len(names) == 1: return names[0]
    return "-".join(names) if len(names) <= 3 else f"{'-'.join(names[:2])}-etc{len(names)-2}"

def load_gitignore(root: Path) -> Set[str]:
    gi = root / ".gitignore"
    if not gi.exists(): return set()
    return {
        line.strip()
        for line in gi.read_text("utf-8", errors="ignore").splitlines()
        if line.strip() and not line.lstrip().startswith("#")
    }

def path_is_ignored(path: Path, root: Path, patterns: Set[str], export_root: Path) -> bool:
    if export_root in path.parents or path == export_root: return True
    for d in IGNORED_DIRS_USER:
        try:
            if (root / d) in path.parents: return True
        except Exception: pass
    try:
        rel = path.relative_to(root)
    except ValueError: return True
    for pat in patterns:
        if pat.endswith("/") and fnmatch.fnmatch(f"{rel}/", pat): return True
        if fnmatch.fnmatch(str(rel), pat) or fnmatch.fnmatch(path.name, pat): return True
    if path.is_file() and path.name in IGNORED_FILES_USER: return True
    return False

def build_import_map(root: Path, py_files: List[Path], progress: gr.Progress) -> Dict[Path, Set[Path]]:
    progress(0.35, desc="import依存関係を解析中...")
    module_of = {".".join(p.relative_to(root).with_suffix("").parts): p for p in py_files}
    mapping: Dict[Path, Set[Path]] = defaultdict(set)
    for i, pf in enumerate(py_files):
        if stop_event.is_set(): break
        try:
            tree = ast.parse(pf.read_text("utf-8", errors="ignore"))
        except Exception: continue
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for a in node.names:
                    tgt = module_of.get(a.name.split(".")[0])
                    if tgt: mapping[pf].add(tgt)
            elif isinstance(node, ast.ImportFrom) and node.module:
                tgt = module_of.get(node.module.split(".")[0])
                if tgt: mapping[pf].add(tgt)
        if i % 10 == 0 and py_files:
            progress(0.35 + (0.1 * i / len(py_files)), desc=f"import解析中... ({i+1}/{len(py_files)})")
    return mapping

def degree_centrality(mapping: Dict[Path, Set[Path]]) -> Dict[Path, float]:
    if not nx: return {k: float(len(v)) for k, v in mapping.items()}
    g = nx.DiGraph()
    for s, tgts in mapping.items():
        for t in tgts: g.add_edge(s, t)
    return nx.degree_centrality(g)

def loc_count(p: Path) -> int:
    try: return sum(1 for _ in p.open("r", encoding="utf-8", errors="ignore"))
    except Exception: return 0

def file_score(path: Path, root: Path, cent: Dict[Path, float]) -> float:
    score = EXTENSION_WEIGHTS.get(path.suffix.lower(), 0)
    score += next((PATH_WEIGHTS[p] for p in path.parts if p in PATH_WEIGHTS), 0)
    score += cent.get(path, 0) * 5
    lines = loc_count(path)
    if lines: score += min(log2(lines + 1) / 5, 3)
    return score

def collect_files(root: Path, max_single_mb: int, progress: gr.Progress) -> List[Path]:
    progress(0.05, desc=f"フォルダをスキャン中... ({root.name})")
    export_root = root / EXPORT_DIR_NAME
    patterns = load_gitignore(root)
    cap_single = max_single_mb * 1024 * 1024
    cand: List[Path] = []
    try:
        entries = list(root.rglob("*"))
    except (PermissionError, FileNotFoundError): return []
    total_entries = len(entries)
    for i, p in enumerate(entries):
        if stop_event.is_set(): break
        include_by_keep = p.is_file() and (p.name in KEEP_FILES)
        if not include_by_keep:
            if not path_is_ignored(p, root, patterns, export_root):
                if p.is_file() and (p.suffix.lower() in FILE_TYPES) and (p.stat().st_size <= cap_single):
                    if os.name == "nt":
                        try:
                            if len(str(export_root / p.relative_to(root))) > WIN_PATH_CAP: p = None
                        except ValueError: p = None
                    if p is not None: cand.append(p)
        else:
            cand.append(p)
        if i % 100 == 0 and total_entries:
            progress(0.1 + (0.15 * i / total_entries), desc=f"ファイル収集中... ({len(cand)}件)")
    if not cand: return []
    progress(0.3, desc="重要度を計算中...")
    py = [p for p in cand if p.suffix == ".py"]
    cent = degree_centrality(build_import_map(root, py, progress)) if py and nx else {}
    progress(0.5, desc="ファイルを重要度順にソート中...")
    cand.sort(key=lambda p: file_score(p, root, cent), reverse=True)
    return cand

def make_tree_and_list(pairs: List[Tuple[Path, Path]]) -> Tuple[str, str]:
    by_root: Dict[Path, List[Path]] = defaultdict(list)
    for rt, p in pairs: by_root[rt].append(p)
    sections, flat_list = [], []
    for rt, files in by_root.items():
        tree_dict: Dict[str, Dict] = {}
        for f in files:
            try: rel = f.relative_to(rt)
            except ValueError: rel = Path(f.name)
            node = tree_dict
            for part in rel.parts: node = node.setdefault(part, {})
            flat_list.append(str(rel).replace("\\", "/"))
        lines = [f"./ ({rt.name})"]
        def dfs(d: Dict[str, Dict], pref=""):
            items = sorted(d.keys())
            for i, k in enumerate(items):
                conn = "└── " if i == len(items) - 1 else "├── "
                lines.append(f"{pref}{conn}{k}")
                if d[k]: dfs(d[k], pref + ("    " if i == len(items)-1 else "│   "))
        dfs(tree_dict)
        sections.append("\n".join(lines))
    return "\n\n".join(sections), "\n".join(sorted(flat_list))


# 
```


## tools\code_export_gui_fixed.py

```python
"""code_export_gui_fixed.py — importance-aware export with folder-named outputs (ERROR FIXED)

エラー修正版 - 2025-08-03 rev-9 (sub_progress parameter conflict fixed)

────────────────────────────────────────────────────

* Layer-① ルールベース（拡張子・パス・サイズ）
* Layer-② 静的メタ解析（import 結合度 + LOC）
* **複数フォルダ選択** OK
* **進行度表示機能** - 各処理段階を視覚化
* **フォルダ名識別** - 出力ファイル名に分析対象フォルダ名を含める
* **引数競合エラー修正** NEW - sub_progress関数の引数処理を修正

使用方法:
1. (venv) 環境で実行: python code_export_gui_fixed.py
2. ブラウザで http://127.0.0.1:7860 にアクセス
3. プロジェクトフォルダに C:/Users/USER/tools/NexusCore を指定
4. エクスポート開始で進行度を確認しながら処理実行

"""

from __future__ import annotations

import ast
import datetime
import fnmatch
import os
import re
import time
import traceback
import zipfile
from collections import defaultdict
from math import log2
from pathlib import Path
from threading import Event
from typing import List, Tuple, Dict, Set

import gradio as gr

try:
    import networkx as nx  # optional – centrality calc
except ImportError:
    nx = None

# === CONFIG ===
FILE_TYPES: Tuple[str, ...] = (
    ".py", ".ipynb", ".md", ".txt", "package.json", ".json", ".yml", ".yaml", ".toml",
)

DEFAULT_IGNORED_DIRS = {
    ".git", "__pycache__", "node_modules", "venv", ".venv", "dist", "build", ".idea", ".vscode",
}

MAX_LINES_PER_FILE = 10_000
TOTAL_SIZE_CAP_MB = 99
WIN_PATH_CAP = 250  # safe margin under MAX_PATH 260
EXPORT_ROOT = Path("./exports").resolve()
EXPORT_ROOT.mkdir(exist_ok=True)
DEFAULT_IGNORED_DIRS.add(EXPORT_ROOT.name)

EXT_WEIGHT = {".py": 3, ".ipynb": 2, ".md": 1}
PATH_WEIGHT = {"src": 2, "app": 2, "lib": 1, "tests": -1, "docs": -1}

stop_event = Event()

# ───────────────────────────────────────── naming helpers
def sanitize_name(name: str) -> str:
    """ファイル名として安全な文字列に変換"""
    invalid_chars = r'[<>:"/\\|?*\x00-\x1f]'
    sanitized = re.sub(invalid_chars, '_', name)
    sanitized = re.sub(r'_+', '_', sanitized)
    sanitized = sanitized.strip('_')
    if not sanitized:
        sanitized = "Unknown"
    if len(sanitized) > 50:
        sanitized = sanitized[:50]
    return sanitized

def generate_project_prefix(roots: List[Path]) -> str:
    """分析対象フォルダ名から出力ファイル名のプレフィックスを生成"""
    if not roots:
        return "Export"
    folder_names = [sanitize_name(root.name) for root in roots]
    if len(folder_names) == 1:
        return folder_names[0]
    if len(folder_names) <= 3:
        return "-".join(folder_names)
    else:
        return f"{'-'.join(folder_names[:2])}-etc{len(folder_names)-2}"

# ───────────────────────────────────────── gitignore
def load_gitignore(root: Path) -> Set[str]:
    gi = root / ".gitignore"
    if not gi.exists():
        return set()
    return {
        line.strip()
        for line in gi.read_text("utf-8", errors="ignore").splitlines()
        if line.strip() and not line.lstrip().startswith("#")
    }

def path_is_ignored(path: Path, root: Path, patterns: Set[str]) -> bool:
    try:
        rel = path.relative_to(root)
    except ValueError:
        return True
    for pat in patterns:
        if pat.endswith("/") and fnmatch.fnmatch(f"{rel}/", pat):
            return True
        if fnmatch.fnmatch(str(rel), pat) or fnmatch.fnmatch(path.name, pat):
            return True
    return False

# ───────────────────────────────────────── static analysis
def build_import_map(root: Path, py_files: List[Path], progress: gr.Progress) -> Dict[Path, Set[Path]]:
    progress(0.35, desc="import依存関係を解析中...")
    module_of = {".".join(p.relative_to(root).with_suffix("").parts): p for p in py_files}
    mapping: Dict[Path, Set[Path]] = defaultdict(set)
    for i, pf in enumerate(py_files):
        if stop_event.is_set():
            break
        try:
            tree = ast.parse(pf.read_text("utf-8", errors="ignore"))
        except (SyntaxError, UnicodeDecodeError):
            continue
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for a in node.names:
                    tgt = module_of.get(a.name.split(".")[0])
                    if tgt:
                        mapping[pf].add(tgt)
            elif isinstance(node, ast.ImportFrom) and node.module:
                tgt = module_of.get(node.module.split(".")[0])
                if tgt:
                    mapping[pf].add(tgt)
        if i % 10 == 0:
            progress(0.35 + (0.1 * i / len(py_files)), desc=f"import解析中... ({i+1}/{len(py_files)})")
    return mapping

def degree_centrality(mapping: Dict[Path, Set[Path]]) -> Dict[Path, float]:
    if not nx:
        return {k: len(v) for k, v in mapping.items()}
    g = nx.DiGraph()
    for s, tgts in mapping.items():
        for t in tgts:
            g.add_edge(s, t)
    return nx.degree_centrality(g)

# ───────────────────────────────────────── scoring helpers
def loc_count(path: Path) -> int:
    try:
        return sum(1 for _ in path.open("r", encoding="utf-8", errors="ignore"))
    except Exception:
        return 0

def file_score(path: Path, root: Path, cent: Dict[Path, float]) -> float:
    score = EXT_WEIGHT.get(path.suffix.lower(), 0)
    score += next((PATH_WEIGHT[p] for p in path.parts if p in PATH_WEIGHT), 0)
    score += cent.get(path, 0) * 5
    lines = loc_count(path)
    if lines:
        score += min(log2(lines + 1) / 5, 3)
    return score

# ───────────────────────────────────────── file collection
def collect_files(root: Path, max_single_mb: int, progress: gr.Progress) -> List[Path]:
    progress(0.05, desc=f"フォルダをスキャン中... ({root.name})")
    patterns = load_gitignore(root)
    cap_total = TOTAL_SIZE_CAP_MB * 1024 * 1024
    cap_single = max_single_mb * 1024 * 1024
    cand: List[Path] = []

    progress(0.1, desc="ファイル一覧を取得中...")
    try:
        entries = list(root.rglob("*"))
    except (PermissionError, FileNotFoundError):
        return []
    total_entries = len(entries)
    for i, p in enumerate(entries):
        if stop_event.is_set():
            break
        if any(p.is_relative_to(root / ig) for ig in DEFAULT_IGNORED_DIRS if (root / ig).exists()):
            continue
        if path_is_ignored(p, root, patterns):
            continue
        if (p.is_file() and 
            p.suffix.lower() in FILE_TYPES and 
            p.stat().st_size <= cap_single):
            if os.name == "nt" and len(str(EXPORT_ROOT / p.relative_to(root))) > WIN_PATH_CAP:
                continue
            cand.append(p)
        if i % 100 == 0:
            progress(0.1 + (0.15 * i / total_entries), desc=f"ファイル収集中... ({len(cand)}件)")
    if not cand:
        return []
    progress(0.3, desc="重要度を計算中...")
    py = [p for p in cand if p.suffix == ".py"]
    if py:
        cent = degree_centrality(build_import_map(root, py, progress))
    else:
        cent = {}
    progress(0.5, desc="ファイルを重要度順にソート中...")
    cand.sort(key=lambda p: file_score(p, root, cent), reverse=True)
    progress(0.6, desc="サイズ制限内でファイルを選択中...")
    sel: List[Path] = []
    total = 0
    for i, p in enumerate(cand):
        if stop_event.is_set():
            break
        size = p.stat().st_size
        if total + size > cap_total:
            continue
        sel.append(p)
        total += size
        if i % 50 == 0:
            progress(0.6 + (0.2 * i / len(cand)), desc=f"ファイル選択中... ({len(sel)}件)")
    progress(0.8, desc=f"ファイル収集完了: {len(sel)}件")
    return sel

# ───────────────────────────────────────── helpers for export
def make_tree(root: Path, files: List[Path]) -> str:
    tree_dict: Dict[str, Dict] = {}
    for f in files:
        try:
            rel_path = f.relative_to(root)
        except ValueError:
            continue
        node = tree_dict
        for part in rel_path.parts:
            node = node.setdefault(part, {})
    lines = [f"./ ({root.name})"]
    def dfs(d: Dict[str, Dict], pref: str = ""):
        items = sorted(d.keys())
        for i, k in enumerate(items):
            conn = "└── " if i == len(items) - 1 else "├── "
            lines.append(f"{pref}{conn}{k}")
            if d[k]:
                extension = "    " if i == len(items) - 1 else "│   "
                dfs(d[k], pref + extension)
    dfs(tree_dict)
    return "\n".join(lines)

def def_class_only(path: Path) -> List[str]:
    try:
        lines = path.r
```


## tools\code_export_gui_SaaS.py

```python
# ======================================================================
# code_export_gui_SaaS.py — SaaS向けプロファイル切替 + .env.redacted 生成
# プロファイル: Safe Share / Repro Build / Audit Pack
# 2025-08-09 v1
# ======================================================================

from __future__ import annotations

import ast
import datetime
import fnmatch
import os
import re
import time
import traceback
import zipfile
from collections import defaultdict
from math import log2
from pathlib import Path
from threading import Event
from typing import List, Tuple, Dict, Set

import gradio as gr

try:
    import networkx as nx
except ImportError:
    nx = None

# --- ベースの除外（ユーザ最終リスト） ---
BASE_IGNORED_DIRS = {
    ".git", "__pycache__", "node_modules", "dist", "build", ".venv", "venv",
    ".idea", ".vscode", ".mypy_cache", ".pytest_cache", "htmlcov", ".gradio", "exports",
    "openenv", "myenv", "old_tool",
    "quality_loop_test_sandbox", "result_images", "sandbox_repo", "scripts", "output",
    "patch_history", "policy_test_sandbox", "project_structure_export", "quality_gate_test_sandbox",
    "test_cache",
}
BASE_IGNORED_FILES = {
    ".coverage", ".env", ".env.template", ".gitattributes", ".gitignore", ".nexus_context.json",
    ".python-version", "nexus_api_server.log", "nexus_core_run.log", "orchestrator_test.log",
    "quality_gate_test_run.log", "OpenCodeInterpreter.code-workspace", "launch.bat", "launch_all.ps1",
    "launch_dev.ps1", "LICENSE", "project_chronicle.jsonl", "project_structure.json",
    "fix_imports.py", "gradio_app.py", "main_cli.py", "project_structure_and_code_export.py",
    "pytest.ini", "vscode-extension.zip",
}

# --- プロファイル定義 ---
PROFILES = {
    "Safe Share": {
        "keep": {
            "requirements.txt", "pyproject.toml", "project_structure.json",
            ".env.template", "README.md", "ARCHITECTURE.md",
            "openapi.yaml", "openapi.json",
        },
        "include_dirs": set(),  # 追加取り込み無し
    },
    "Repro Build": {
        "keep": {
            "requirements.txt", "pyproject.toml", ".env.template", "README.md",
            "poetry.lock", "Pipfile.lock", "uv.lock",
            "Dockerfile", "docker-compose.yml",
            "Makefile", "Justfile",
            "alembic.ini", "project_structure.json",
        },
        "include_dirs": {"migrations", "infra", "deploy", "k8s", "helm"},
    },
    "Audit Pack": {
        "keep": {
            "requirements.txt", "pyproject.toml", ".env.template", "README.md",
            "poetry.lock", "Pipfile.lock", "uv.lock",
            "Dockerfile", "docker-compose.yml",
            "Makefile", "Justfile",
            "openapi.yaml", "openapi.json", "THIRD_PARTY_NOTICES.md",
            "project_structure.json",
        },
        "include_dirs": {"migrations", "infra", "deploy", "k8s", "helm", ".github/workflows"},
    },
}
DEFAULT_PROFILE = "Safe Share"  # 起動デフォルト

FILE_TYPES: Tuple[str, ...] = (
    ".py", ".ipynb", ".md", ".txt", "package.json", ".json", ".yml", ".yaml", ".toml",
)

MAX_LINES_PER_FILE = 10_000
TOTAL_SIZE_CAP_MB = 99
WIN_PATH_CAP = 250
EXPORT_ROOT = Path("./exports").resolve()
EXPORT_ROOT.mkdir(exist_ok=True)

EXT_WEIGHT = {".py": 3, ".ipynb": 2, ".md": 1}
PATH_WEIGHT = {"src": 2, "app": 2, "lib": 1, "tests": -1, "docs": -1}

stop_event = Event()

def sanitize_name(name: str) -> str:
    invalid_chars = r'[<>:"/\\|?*\x00-\x1f]'
    s = re.sub(invalid_chars, '_', name)
    s = re.sub(r'_+', '_', s).strip('_') or "Unknown"
    return s[:50]

def generate_project_prefix(roots: List[Path]) -> str:
    if not roots: return "Export"
    names = [sanitize_name(r.name) for r in roots]
    if len(names) == 1: return names[0]
    return "-".join(names) if len(names) <= 3 else f"{'-'.join(names[:2])}-etc{len(names)-2}"

def load_gitignore(root: Path) -> Set[str]:
    gi = root / ".gitignore"
    if not gi.exists(): return set()
    return {
        line.strip()
        for line in gi.read_text("utf-8", errors="ignore").splitlines()
        if line.strip() and not line.lstrip().startswith("#")
    }

def should_force_include(path: Path, keep_set: Set[str]) -> bool:
    return path.is_file() and (path.name in keep_set)

def path_is_ignored(path: Path, root: Path, patterns: Set[str], include_dirs: Set[str]) -> bool:
    if EXPORT_ROOT in path.parents or path == EXPORT_ROOT:
        return True
    # include_dirs は除外を打ち消す（優先許可）
    for inc in include_dirs:
        try:
            if (root / inc) in path.parents:
                return False
        except Exception:
            pass
    # ユーザの除外
    for d in BASE_IGNORED_DIRS:
        try:
            if (root / d) in path.parents:
                return True
        except Exception:
            pass
    try:
        rel = path.relative_to(root)
    except ValueError:
        return True
    for pat in patterns:
        if pat.endswith("/") and fnmatch.fnmatch(f"{rel}/", pat):
            return True
        if fnmatch.fnmatch(str(rel), pat) or fnmatch.fnmatch(path.name, pat):
            return True
    if path.is_file() and path.name in BASE_IGNORED_FILES:
        return True
    return False

def build_import_map(root: Path, py_files: List[Path], progress: gr.Progress) -> Dict[Path, Set[Path]]:
    progress(0.35, desc="import依存解析中...")
    module_of = {".".join(p.relative_to(root).with_suffix("").parts): p for p in py_files}
    mapping: Dict[Path, Set[Path]] = defaultdict(set)
    for i, pf in enumerate(py_files):
        if stop_event.is_set(): break
        try:
            tree = ast.parse(pf.read_text("utf-8", errors="ignore"))
        except (SyntaxError, UnicodeDecodeError):
            continue
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for a in node.names:
                    tgt = module_of.get(a.name.split(".")[0])
                    if tgt: mapping[pf].add(tgt)
            elif isinstance(node, ast.ImportFrom) and node.module:
                tgt = module_of.get(node.module.split(".")[0])
                if tgt: mapping[pf].add(tgt)
        if i % 10 == 0 and py_files:
            progress(0.35 + (0.1 * i / len(py_files)), desc=f"import解析中... ({i+1}/{len(py_files)})")
    return mapping

def degree_centrality(mapping: Dict[Path, Set[Path]]) -> Dict[Path, float]:
    if not nx: return {k: float(len(v)) for k, v in mapping.items()}
    g = nx.DiGraph()
    for s, tgts in mapping.items():
        for t in tgts: g.add_edge(s, t)
    return nx.degree_centrality(g)

def loc_count(path: Path) -> int:
    try: return sum(1 for _ in path.open("r", encoding="utf-8", errors="ignore"))
    except Exception: return 0

def file_score(path: Path, root: Path, cent: Dict[Path, float]) -> float:
    score = EXT_WEIGHT.get(path.suffix.lower(), 0)
    score += next((PATH_WEIGHT[p] for p in path.parts if p in PATH_WEIGHT), 0)
    score += cent.get(path, 0) * 5
    lines = loc_count(path)
    if lines: score += min(log2(lines + 1) / 5, 3)
    return score

def write_redacted_env(src_env: Path, out_dir: Path):
    """値を '****' にマスクした .env.redacted を出力"""
    try:
        lines = src_env.read_text("utf-8", errors="ignore").splitlines()
        out = []
        for ln in lines:
            if not ln or ln.strip().startswith("#") or "=" not in ln:
                out.append(ln); continue
            k, v = ln.split("=", 1)
            out.append(f"{k}=****")
        (out_dir / ".env.redacted").write_text("\n".join(out), "utf-8")
    except Exception:
        pass

def collect_files(root: Path, max_single_mb: int, progress: gr.Progress, keep_set: Set[str], include_dirs: Set[str]) -> List[Path]:
    progress(0.05, desc=f"スキャン中... ({root.name})")
    patterns = load_gitignore(root)
    cap_total = TOTAL_SIZE_CAP_MB * 1024 * 1024
    cap_single = max_single_mb * 1024 * 1024
    cand: List[Path] = []

    progress(0.1, desc="一覧取得...")
    try:
        entries = list(root.rglob("*"))
    except (PermissionError, FileNotFoundError):
        return []

    total_entries = len(entries)
    for i, p in enumerate(entries):
        if stop_event.is_set(): break

        if should_force_include(p, keep_set):
            cand.append(p)
        else:
            if not path_is_
```


## app\extensions.py

```python
from celery import Celery, Task

def celery_init_app(app):
    class ContextTask(Task):
        def __call__(self, *args, **kwargs):
            with app.app_context():
                return self.run(*args, **kwargs)

    celery = Celery(app.import_name)
    celery.config_from_object(app.config["CELERY"])
    celery.Task = ContextTask
    app.celery = celery            # ← 外部から参照できるよう保持
    return celery

```


## tools\context_bundle_prime.py

```python
# ==============================================================================
# 操作するソフト: VSCode（または任意のテキストエディタ）
# フォルダ      : tools/
# ファイル名    : context_bundle_prime.py
# バージョン    : 1.3 (2025-08-20)
#
# 変更点（重要）:
#  - exports/**, openenv/**, site-packages/** 等をデフォルト除外（自己再帰と巨大化の防止）
#  - ダイジェスト保存を「フラット保存（SHA1ファイル名）」に変更し MAX_PATH 問題を回避
#  - digests/_index.json に元パス→ハッシュ名の対応表を出力（逆引き用）
#  - すべてのファイル書込/作成で \\?\ プレフィックス対応と親ディレクトリ強制作成
#
# 目的:
#   LLM 前提の「軽量コンテキスト・バンドル」を生成（要約/依存/索引/差分/ZIP分割）
#   - repo_summary.md        : リポジトリ要約（規模、エントリ候補、注意点）
#   - tree.txt               : 除外規則反映のツリーテキスト
#   - imports_graph.json     : Python import 依存グラフ
#   - files_index.json       : 各ファイルのメタ（サイズ、行数、sha256、拡張子）
#   - top_files.md           : サイズTOP 50
#   - digests/_index.json    : ダイジェスト逆引きインデックス（元パス→ハッシュ名）
#   - digests/*.md           : 各ファイルのダイジェスト（フラット保存）
#   - diff/*                 : 旧バンドルとの差分（--prev-bundle 指定時）
#   - context_bundle_*.zip   : 一式のZIP（大きければ *.part*** に自動分割）
#
# 使い方（標準フロー）:
#   1) 初回生成:
#      python tools/context_bundle_prime.py .
#      -> exports/context_bundle_YYYYMMDD_hhmmss/ に一式、ZIPも出力
#
#   2) ChatGPTへの投入順:
#      (a) repo_summary.md
#      (b) tree.txt
#      (c) imports_graph.json
#      (d) files_index.json
#      以後、必要に応じて digests/_index.json を見て該当ダイジェスト（*.md）を追加投入。
#
#   3) 差分運用（更新時の再解析を最小化）:
#      python tools/context_bundle_prime.py . --prev-bundle exports/context_bundle_YYYYMMDD_hhmmss.zip
#      -> exports/.../diff/diff.json の added / changed を優先して再投入
#
# 任意設定（上書き可能）: tools/context_bundle_prime.config.json
#   {
#     "include_exts": [".py", ".md", ".toml", ".yaml", ".yml", ".json", ".ini", ".cfg", ".txt"],
#     "exclude_globs": ["**/.git/**", "**/exports/**", "**/.venv/**", "**/venv/**", ...],
#     "head_tail_lines": 120,
#     "zip_part_size_mb": 48,
#     "repo_name": "NexusCore"
#   }
# ==============================================================================

from __future__ import annotations

import os
import re
import ast
import json
import glob
import zipfile
import hashlib
import argparse
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Any, Optional, Tuple

# ---------------- Config（必要に応じて config で上書き） --------------------------
DEFAULT = {
    "include_exts": [".py", ".md", ".toml", ".yaml", ".yml", ".json", ".ini", ".cfg", ".txt"],
    "exclude_globs": [
        # 再帰取り込み・巨大化を防ぐ標準除外
        "**/.git/**", "**/exports/**",
        "**/__pycache__/**", "**/.mypy_cache/**", "**/.pytest_cache/**",
        "**/.venv/**", "**/venv/**", "**/openenv/**",
        "**/node_modules/**", "**/dist/**", "**/build/**",
        # site-packages 系（仮想環境内など）
        "**/Lib/site-packages/**", "**/lib/site-packages/**",
        # 大型・不要ファイル群
        "**/*.min.js", "**/*.min.css", "**/*.log", "**/*.zip", "**/*.7z", "**/*.tar*",
        "**/*.png", "**/*.jpg", "**/*.jpeg", "**/*.gif", "**/*.webp", "**/*.pdf"
    ],
    "follow_gitignore": True,
    "max_file_size_bytes": 2 * 1024 * 1024,  # 2MB を超える本文はダイジェスト生成をスキップ（メタのみ）
    "head_tail_lines": 120,
    "max_digest_chars": 80_000,
    "zip_part_size_mb": 48,
    "repo_name": None
}

# ---------------- Utils（長いパス & ディレクトリ作成） ---------------------------

def _win_longpath(s: str) -> str:
    if os.name == "nt" and not s.startswith("\\\\?\\") and len(s) >= 240:
        return "\\\\?\\" + s
    return s

def _ensure_parent_dir(p: Path) -> None:
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
    except Exception:
        os.makedirs(_win_longpath(str(p.parent)), exist_ok=True)

def save_text(p: Path, s: str) -> None:
    _ensure_parent_dir(p)
    with open(_win_longpath(str(p)), "w", encoding="utf-8", newline="\n", errors="replace") as f:
        f.write(s)

def save_json(p: Path, o: Any) -> None:
    _ensure_parent_dir(p)
    with open(_win_longpath(str(p)), "w", encoding="utf-8", newline="\n", errors="replace") as f:
        f.write(json.dumps(o, ensure_ascii=False, indent=2))

def human(n: int) -> str:
    u = ["B","KB","MB","GB","TB"]; i=0; x=float(n)
    while x >= 1024 and i < len(u)-1: x/=1024; i+=1
    return f"{x:.1f}{u[i]}" if i else f"{int(x)}B"

def sha256_file(p: Path) -> str:
    import hashlib
    h = hashlib.sha256()
    with open(_win_longpath(str(p)), "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()

def load_json(p: Path) -> Any:
    with open(_win_longpath(str(p)), "r", encoding="utf-8") as f:
        return json.load(f)

# ---------------- .gitignore & パターンマッチ ------------------------------------

def load_gitignore(root: Path) -> List[str]:
    gi = root / ".gitignore"
    if not gi.exists(): return []
    try:
        return [ln.strip() for ln in gi.read_text("utf-8", errors="ignore").splitlines()
                if ln.strip() and not ln.strip().startswith("#")]
    except Exception:
        return []

def match_any(rel: str, patterns: List[str]) -> bool:
    import fnmatch
    return any(fnmatch.fnmatch(rel, pat) or fnmatch.fnmatch(Path(rel).name, pat) for pat in patterns)

# ---------------- AST 抽出（.py のみ） -------------------------------------------

def ast_index(py_text: str) -> Dict[str, Any]:
    out = {"functions": [], "classes": [], "imports": []}
    try:
        tree = ast.parse(py_text)
    except Exception:
        return out
    for n in ast.walk(tree):
        if isinstance(n, ast.FunctionDef):
            out["functions"].append({"name": n.name, "lineno": n.lineno, "args": [a.arg for a in n.args.args]})
        elif isinstance(n, ast.AsyncFunctionDef):
            out["functions"].append({"name": f"async {n.name}", "lineno": n.lineno, "args": [a.arg for a in n.args.args]})
        elif isinstance(n, ast.ClassDef):
            out["classes"].append({"name": n.name, "lineno": n.lineno})
        elif isinstance(n, ast.Import):
            for a in n.names: out["imports"].append({"type":"import", "name": a.name})
        elif isinstance(n, ast.ImportFrom):
            mod = n.module or ""
            for a in n.names: out["imports"].append({"type":"from", "module": mod, "name": a.name})
    return out

def extract_docstrings(py_text: str) -> List[str]:
    try:
        tree = ast.parse(py_text)
    except Exception:
        return []
    docs = []
    md = ast.get_docstring(tree)
    if md: docs.append(md)
    for b in getattr(tree, "body", []):
        if isinstance(b, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            d = ast.get_docstring(b)
            if d: docs.append(d)
    return docs[:10]

# ---------------- 対象走査 ------------------------------------------------------

def iter_files(root: Path, cfg: Dict[str, Any]) -> List[Path]:
    ex = list(cfg["exclude_globs"])
    if cfg.get("follow_gitignore"): ex += load_gitignore(root)
    inc = set([e.lower() for e in cfg["include_exts"]])
    out: List[Path] = []
    for p in root.rglob("*"):
        if not p.is_file(): continue
        rel = p.relative_to(root).as_posix()
        if match_any(rel, ex): continue
        if inc and p.suffix.lower() not in inc: continue
        out.append(p)
    return out

# ---------------- ダイジェスト生成（フラット保存） -------------------------------

def make_digest(p: Path, root: Path, cfg: Dict[str, Any]) -> Tuple[Dict[str, Any], Optional[str]]:
    rel = p.relative_to(root).as_posix()
    b = p.read_bytes()
    sha = sha256_file(p)
    try:
        txt = b.decode("utf-8", errors="replace")
    except Exception:
        txt = None

    meta = {
        "path": rel, "sha256": sha, "size_bytes": len(b), "size_h": human(len(b)),
        "ext": p.suffix.lower(), "lines": (txt.count("\n")+1) if txt is not None else None
    }

    if txt is None or len(b) > cfg["max_file_size_bytes"]:
        return meta, None

    lines = txt.splitlines()
    n = int(cfg["head_tail_lines"])
    head = "\n".join(lines[:n])
    tail = "\n".join(lines[-n:]) if len(lines) > n else ""

    idx = ast_index(txt) if p.suffix.lower() == ".py" else {}
    docs = extract_docstrings(txt) if p.suffix.lower() == ".py" else []

    parts = [f"# File: {rel}\n- size: {meta['size_h']}  lines: {meta['lines']}  sha256: {sha}\n"]
    if idx.get("functions"):
        parts.appen
```


## tools\genesis_analyzer.py

```python
# ==============================================================================
# フォルダ: tools/
# ファイル名: genesis_analyzer.py
# 目的: プロジェクト全容の「スナップショット」と「差分イベント」を Chronicle(JSONL) に記録
# 対応: ①差分検出(Git or ハッシュ) ②Chronicleに event_type/files_changed/folders_changed/diff_digest 追記
#       ③解析対象の設定化(includes/excludes) ④既存Chronicleとの後方互換（従来の integrated_summary も維持）
# 依存: 標準ライブラリのみ（Git差分は git CLI が存在する場合のみ利用）
# 使い方:
#   python tools/genesis_analyzer.py <PROJECT_ROOT> [--mode snapshot|diff] [--config tools/genesis_analyzer.config.json]
# 例:
#   python tools/genesis_analyzer.py . --mode snapshot
#   python tools/genesis_analyzer.py . --mode diff
# 備考:
#  - 既存の LLMRouter 等には触れず、integrated_summary は optional 生成（失敗しても続行）
#  - 既存 project_chronicle.jsonl に後方互換で追記
# ==============================================================================

from __future__ import annotations
import os
import re
import ast
import sys
import json
import time
import hashlib
import logging
import subprocess
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Any, Optional, Iterable, Tuple, Set

# ========= ログ設定 =========
def _setup_logger(project_root: Path) -> logging.Logger:
    log_dir = project_root / ".logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / "genesis_analyzer.log"
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(levelname)s - %(message)s",
        handlers=[logging.StreamHandler(), logging.FileHandler(log_file, encoding="utf-8")]
    )
    return logging.getLogger("genesis_analyzer")

# ========= 設定 =========
DEFAULT_CONFIG = {
    # 解析対象の上位ディレクトリ（相対パス）
    "includes": ["src", "tests", "app", "tools", "evaluation", "exports", "dev_tools"],
    # 除外ディレクトリ/ファイルのグロブ（先勝ち）
    "excludes": [
        ".git", ".venv", "__pycache__", "node_modules", "build", "dist",
        ".logs", ".gradio", "exports/_imports", "exported_projects", "sandbox_output",
        "deploy_output", "output", "*.zip", "*.7z", "*.log", "*.png", "*.jpg", "*.gif"
    ],
    # ファイルサイズ上限（MB）: 大型バイナリ等は無視
    "max_file_size_mb": 2,
    # 差分モード時: git CLI を使うか（なければ自動でハッシュ差分にフォールバック）
    "use_git_if_available": True,
    # Chronicle 出力先
    "chronicle_path": "project_chronicle.jsonl",
    # ステート（前回ハッシュスナップショット）保存先
    "state_path": ".nexus_state.json",
    # LLM要約（integrated_summary）を試行するか
    "try_integrated_summary": True
}

@dataclass
class AnalyzerConfig:
    includes: List[str] = field(default_factory=lambda: DEFAULT_CONFIG["includes"])
    excludes: List[str] = field(default_factory=lambda: DEFAULT_CONFIG["excludes"])
    max_file_size_mb: int = DEFAULT_CONFIG["max_file_size_mb"]
    use_git_if_available: bool = DEFAULT_CONFIG["use_git_if_available"]
    chronicle_path: str = DEFAULT_CONFIG["chronicle_path"]
    state_path: str = DEFAULT_CONFIG["state_path"]
    try_integrated_summary: bool = DEFAULT_CONFIG["try_integrated_summary"]

    @staticmethod
    def load(project_root: Path, config_path: Optional[str]) -> "AnalyzerConfig":
        cfg = dict(DEFAULT_CONFIG)
        if config_path:
            p = Path(config_path)
            if not p.is_absolute():
                p = project_root / p
            if p.is_file():
                with open(p, "r", encoding="utf-8") as f:
                    user = json.load(f)
                cfg.update(user or {})
        return AnalyzerConfig(
            includes=cfg["includes"],
            excludes=cfg["excludes"],
            max_file_size_mb=cfg["max_file_size_mb"],
            use_git_if_available=cfg["use_git_if_available"],
            chronicle_path=cfg["chronicle_path"],
            state_path=cfg["state_path"],
            try_integrated_summary=cfg["try_integrated_summary"]
        )

# ========= 共通ユーティリティ =========
def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()

def is_binary(path: Path) -> bool:
    # シンプル判定: 拡張子 + 部分ヘッダチェック
    BIN_EXT = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".pdf", ".onnx", ".pb", ".pbtxt", ".tar", ".gz"}
    if path.suffix.lower() in BIN_EXT:
        return True
    try:
        with open(path, "rb") as f:
            chunk = f.read(8000)
        return b"\0" in chunk
    except Exception:
        return True

def file_sha1(path: Path) -> str:
    h = hashlib.sha1()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()

def to_posix(project_root: Path, path: Path) -> str:
    return str(path.relative_to(project_root)).replace("\\", "/")

def match_excluded(rel: str, excludes: List[str]) -> bool:
    import fnmatch
    # 先勝ち: パス全体と末尾名の双方に対して照合
    name = Path(rel).name
    for pat in excludes:
        if fnmatch.fnmatch(rel, pat) or fnmatch.fnmatch(name, pat):
            return True
    return False

# ========= 対象ファイルの列挙 =========
def iter_target_files(project_root: Path, cfg: AnalyzerConfig) -> List[Path]:
    targets: List[Path] = []
    max_bytes = cfg.max_file_size_mb * 1024 * 1024
    for top in cfg.includes:
        base = (project_root / top)
        if not base.exists():
            continue
        for p in base.rglob("*"):
            if not p.is_file():
                continue
            rel = to_posix(project_root, p)
            if match_excluded(rel, cfg.excludes):
                continue
            try:
                if p.stat().st_size > max_bytes:
                    continue
            except Exception:
                continue
            if is_binary(p):
                continue
            targets.append(p)
    return targets

# ========= Git差分 or ハッシュ差分 =========
def is_git_repo(project_root: Path) -> bool:
    return (project_root / ".git").exists()

def git_changed_files(project_root: Path, since_ref: str) -> List[Tuple[str, str]]:
    """
    return: list of (status, posix_path)
      status: 'A'|'M'|'D' etc.
    """
    cmd = ["git", "-C", str(project_root), "diff", "--name-status", since_ref, "HEAD"]
    proc = subprocess.run(cmd, capture_output=True, text=True, check=False)
    if proc.returncode != 0:
        return []
    changed: List[Tuple[str, str]] = []
    for line in proc.stdout.splitlines():
        parts = line.split("\t")
        if len(parts) >= 2:
            status = parts[0].strip()
            path = parts[1].strip().replace("\\", "/")
            changed.append((status, path))
    return changed

def load_state(project_root: Path, cfg: AnalyzerConfig) -> Dict[str, Any]:
    p = project_root / cfg.state_path
    if p.is_file():
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            return {}
    return {}

def save_state(project_root: Path, cfg: AnalyzerConfig, data: Dict[str, Any]) -> None:
    (project_root / cfg.state_path).write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

def hash_diff(project_root: Path, cfg: AnalyzerConfig) -> Tuple[Set[str], Set[str], Set[str]]:
    """
    return: (created, modified, deleted) in posix path strings
    """
    prev = load_state(project_root, cfg).get("file_hashes", {})
    current: Dict[str, str] = {}
    for p in iter_target_files(project_root, cfg):
        rel = to_posix(project_root, p)
        current[rel] = file_sha1(p)
    prev_keys = set(prev.keys())
    curr_keys = set(current.keys())
    created = curr_keys - prev_keys
    deleted = prev_keys - curr_keys
    modified = {k for k in (prev_keys & curr_keys) if prev[k] != current[k]}
    # 次回用保存
    save_state(project_root, cfg, {"file_hashes": current, "saved_at": utc_now_iso()})
    return created, modified, deleted

# ========= AST 概略解析（integrated_summary 用の素材） =========
def ast_outline_for_py(path: Path) -> Dict[str, Any]:
    try:
        src = path.read_text(encoding="utf-8", errors="replace")
        tree = ast.parse(src)
    except Exception as e:
        return {"file": str(path), "error": str(e)}
    classes, functions, imports = [], [], []
    for node in ast.walk(tree):
        if isinstance(node, ast.ClassDef):
            classes.append(node.name)
        elif isinstance(node, ast.FunctionDef):
            f
```


## app\celery_worker.py

```python
from app import create_app
from app.extensions import celery_init_app

flask_app = create_app()
celery = celery_init_app(flask_app)     # celery インスタンス

# 例：タスク定義
@celery.task
def ping():
    print("pong")

```


## tools\code_export_gui.py

```python
# ファイル名: code_export_gui.py / code_export_gui_fixed.py (共通)
# 目的: プロジェクト分析とエクスポートを行うための高機能なGradioベースGUIツール。
# 修正内容:
# - `_fixed`版の機能（進行度表示、命名規則プレビュー、エラー修正）を統合。
# - LLMが誤解しないよう、PROJECT_INFO.mdの生成ロジックを改善。
# - 「解析対象の概要」と「このパッケージの作成方法」を明確に分離。
# - GeminiモードとStandardモードでレポート内容が動的に変わるように修正。

from __future__ import annotations
import ast
import datetime
import fnmatch
import os
import re
import time
import traceback
import zipfile
from collections import defaultdict
from math import log2
from pathlib import Path
from threading import Event
from typing import List, Tuple, Dict, Set, Any
import gradio as gr

try:
    import networkx as nx
except ImportError:
    nx = None

# === CONFIG ===
FILE_TYPES: Tuple[str, ...] = (
    ".py", ".ipynb", ".md", ".txt", "package.json", ".json", ".yml", ".yaml", ".toml",
)
DEFAULT_IGNORED_DIRS = {
    ".git", "__pycache__", "node_modules", "dist", "build", ".venv", "myenv", "openenv",
    "exports", "htmlcov", "test_cache", ".pytest_cache", ".gradio"
}
DEFAULT_IGNORED_FILES = {
    '.env', 'secrets.json', 'config.local.json', '.DS_Store', '*.log',
    '*.exe', '*.dll', '*.so', '*.dylib', '*.lib'
}
EXPORT_DIR_NAME = "exports"

# === HELPER FUNCTIONS ===
def analyze_dependencies(directory: str, ignore_dirs: Set[str]) -> Dict[str, int]:
    dependencies: Dict[str, int] = defaultdict(int)
    py_files: List[str] = []
    for root, dirs, files in os.walk(directory):
        dirs[:] = [d for d in dirs if d not in ignore_dirs]
        for file in files:
            if file.endswith(".py"):
                py_files.append(os.path.join(root, file))
    
    for file_path in py_files:
        try:
            with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
                content = f.read()
            tree = ast.parse(content)
            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    for alias in node.names:
                        for path_to_check in py_files:
                            if alias.name in path_to_check.replace(os.sep, "."):
                                dependencies[path_to_check] += 1
                elif isinstance(node, ast.ImportFrom):
                    if node.module:
                        for path_to_check in py_files:
                            if node.module in path_to_check.replace(os.sep, "."):
                                dependencies[path_to_check] += 1
        except Exception:
            continue
    return dependencies

def calculate_score(file_path: str, line_count: int, dependency_count: int) -> float:
    score = 0.0
    ext = os.path.splitext(file_path)[1]
    score += EXTENSION_WEIGHTS.get(ext, 0)
    normalized_path = file_path.replace(os.sep, "/")
    for path, weight in PATH_WEIGHTS.items():
        if path in normalized_path:
            score += weight
    if line_count >= MIN_LINES_FOR_DEPENDENCY:
        score += log2(1 + dependency_count)
    score += line_count * LINE_COUNT_WEIGHT
    return score

# --- 新しいPROJECT_INFO生成関数 (GUI版) ---
def generate_project_info_content(
    total_files: int,
    total_lines: int,
    stats: Dict[str, Dict[str, int]],
    export_type: str,
    max_size_mb: int,
    project_name: str
) -> str:
    """
    プロジェクト情報と解析パッケージに関するマークダウンコンテンツを生成する。
    """
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    # --- セクション1: 解析対象プロジェクトの概要 ---
    project_summary = f"""# 📦 {project_name} プロジェクト解析パッケージ ({export_type})

## 1. 解析対象プロジェクトの概要 (`{project_name}`)

このパッケージは、「自己進化するAI開発エコシステム」である **NexusCore** プロジェクトの核心部分を抽出したものです。

- **プロジェクトの目的:** 専門的な役割を持つAIエージェント群が協調し、失敗から学び、その教訓を組織全体の知識として蓄積・進化させていく自己進化する開発エコシステム。
- **総ファイル数:** {total_files}
- **総コード行数:** {total_lines:,}行
- **エクスポート日時:** {timestamp}
"""

    # --- ファイル統計テーブルの生成 ---
    stats_table = "| 拡張子 | ファイル数 | コード行数 |\n|---|---|---|\n"
    sorted_stats = sorted(stats.items(), key=lambda item: item[1]['files'], reverse=True)
    for ext, data in sorted_stats:
        stats_table += f"| `{ext}` | {data['files']:,} | {data['lines']:,} |\n"
    stats_table += f"| **合計** | **{total_files:,}** | **{total_lines:,}** |\n"
    
    # --- セクション2: この解析パッケージの作成方法 ---
    size_info = f"**{export_type}のファイルサイズ上限 (~{max_size_mb}MB) を考慮**しつつ、" if export_type == "Gemini" else ""
    tool_name = "code_export_gui.py"
    package_info = f"""
---

## 2. この解析パッケージの作成方法について

このパッケージ（特に `COMBINED_CODE.py`）は、`{tool_name}` ツールによって、{size_info}以下の基準で重要と判断されたファイルを自動的に抽出し、結合したものです。

### 🎯 重要度判定基準
#### 拡張子重み
- `.py` ファイル: 3点（最重要）
- `.ipynb` ノートブック: 2点
- `.md` ドキュメント: 1点

#### パス重み
- `src/`, `app/`, `nexuscore/` フォルダ: +2点（重要）
- `tests/`, `docs/` フォルダ: -1点（補助）

#### 依存関係解析
- import結合度による中心性計算
- ファイル間の依存関係を重要度に反映

#### コード行数
- 空白やコメントを除いたコード行数が多いほど高評価
"""

    return f"{project_summary}\n## 📊 ファイル統計\n{stats_table}{package_info}"

# --- Core Logic for GUI ---
def export_project(project_dir_str: str, export_type: str, max_size_mb: int, progress=gr.Progress(track_tqdm=True)):
    project_dirs = [p.strip() for p in project_dir_str.splitlines() if p.strip()]
    if not project_dirs:
        return "Error: プロジェクトディレクトリが指定されていません。", "", None

    first_project_name = os.path.basename(project_dirs[0])
    output_dir = os.path.join(project_dirs[0], EXPORT_DIR_NAME)
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    ignore_dirs = DEFAULT_IGNORED_DIRS
    max_size_bytes = max_size_mb * 1024 * 1024

    all_files_to_score = []
    total_files, total_lines, stats = 0, 0, defaultdict(lambda: {"files": 0, "lines": 0})

    for directory in progress.tqdm(project_dirs, desc="📊 Analyzing structure"):
        for root, dirs, files in os.walk(directory):
            dirs[:] = [d for d in dirs if d not in ignore_dirs]
            for file in files:
                file_path = os.path.join(root, file)
                total_files += 1
                ext = os.path.splitext(file)[1] or "No Ext"
                stats[ext]["files"] += 1
                try:
                    with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
                        line_count = len(f.readlines())
                    stats[ext]["lines"] += line_count
                    total_lines += line_count
                    if file.endswith(FILE_TYPES):
                        all_files_to_score.append(file_path)
                except Exception:
                    continue
    
    progress(0.4, desc="🔗 Analyzing dependencies...")
    dependencies = analyze_dependencies(project_dirs[0], ignore_dirs) # NOTE: Assuming main project is first

    progress(0.6, desc="🏆 Scoring files...")
    scores = {}
    for file_path in progress.tqdm(all_files_to_score, desc="Scoring"):
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                lines = f.readlines()
                line_count = len([line for line in lines if line.strip()])
            dep_count = dependencies.get(file_path, 0)
            scores[file_path] = calculate_score(file_path, line_count, dep_count)
        except Exception:
            continue
            
    sorted_files = sorted(scores.items(), key=lambda item: item[1], reverse=True)
    
    progress(0.7, desc="Selecting top files based on size...")
    top_files = []
    current_size = 0
    for file_path, score in sorted_files:
        try:
            file_size = os.path.getsize(file_path)
            if current_size + file_size < max_size_bytes:
                top_files.append((file_path, score))
                current_size += file_size
        except OSError:
            continue

    progress(0.8, desc="📝 Generating project info...")
    project_info_content = generate_project_info_content(
        total_files, total_lines, stats, export_type, max_size_mb, first_project_name
    )

    progress(0.9, desc="📦 Creating ZIP file...")
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    zip_filename_base = f"{first_project_name}_{export_type.lower()}_{timestamp}"
    zip_filepath = os.path.join(output_dir, f"{zip_filename_base}.zip")

    combined_code = ""
    with zipfile.ZipFile(zip_filepath, 'w', zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("PROJECT
```


## src\file_creator.py

```python
# src/file_creator.py
import os

def create_code_file(filename: str, code: str, folder: str = "src/generated") -> str:
    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, filename)
    with open(path, "w", encoding="utf-8") as f:
        f.write(code)
    return path

```


## tools\dashboard.py

```python
# ==============================================================================
# フォルダ: tools/
# ファイル名: dashboard.py
# メモ: 【JSONL形式対応・ダッシュボード】
#      - project_chronicle.jsonl を1行ずつ安全に読み込み、
#        プロジェクトの状態をダッシュボード形式で表示する。
#      - 正規表現を使わない堅牢な実装。
# ==============================================================================
import os
import json
import sys
import logging
from datetime import datetime, timezone
from typing import Dict, List, Optional, Any
from pathlib import Path
import argparse

# --- ロギング設定 ---
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class ProjectDashboard:
    """プロジェクトダッシュボードクラス"""
    
    def __init__(self, project_path: str):
        self.project_path = Path(project_path)
        self.chronicle_path = self.project_path / "project_chronicle.jsonl"
        self.chronicle_data: List[Dict[str, Any]] = []
        
    def read_chronicle_jsonl(self) -> List[Dict[str, Any]]:
        """JSONL形式のクロニクルファイルを安全に読み込む
        
        Returns:
            解析済みのJSONオブジェクトのリスト
        """
        chronicle_data = []
        
        if not self.chronicle_path.exists():
            logger.warning(f"クロニクルファイルが見つかりません: {self.chronicle_path}")
            return chronicle_data
        
        try:
            with open(self.chronicle_path, 'r', encoding='utf-8') as f:
                for line_num, line in enumerate(f, 1):
                    line = line.strip()
                    if not line:  # 空行をスキップ
                        continue
                        
                    try:
                        # 各行を個別のJSONオブジェクトとしてパース
                        json_obj = json.loads(line)
                        chronicle_data.append(json_obj)
                    except json.JSONDecodeError as e:
                        logger.error(f"Line {line_num}: JSON parse error - {e}")
                        logger.debug(f"Problematic line: {line[:100]}...")
                        continue
                        
        except Exception as e:
            logger.error(f"クロニクルファイル読み込みエラー: {e}")
        
        logger.info(f"✅ {len(chronicle_data)} 件のレコードを読み込みました")
        return chronicle_data
    
    def load_project_data(self) -> Dict[str, Any]:
        """プロジェクトデータを読み込む"""
        self.chronicle_data = self.read_chronicle_jsonl()
        
        # 最新のGENESISレコードを取得
        genesis_record = None
        for record in reversed(self.chronicle_data):
            if record.get("event") == "GENESIS":
                genesis_record = record
                break
        
        # 分析スナップショットを時系列順に取得
        snapshots = [
            record for record in self.chronicle_data 
            if record.get("event") == "ANALYSIS_SNAPSHOT"
        ]
        
        return {
            "genesis": genesis_record,
            "snapshots": snapshots,
            "total_records": len(self.chronicle_data),
            "last_updated": self.chronicle_data[-1].get("timestamp") if self.chronicle_data else None
        }
    
    def format_timestamp(self, timestamp_str: str) -> str:
        """タイムスタンプを読みやすい形式にフォーマット"""
        try:
            dt = datetime.fromisoformat(timestamp_str.replace('Z', '+00:00'))
            return dt.strftime('%Y-%m-%d %H:%M:%S UTC')
        except:
            return timestamp_str
    
    def display_project_overview(self, project_data: Dict[str, Any]) -> None:
        """プロジェクト概要を表示"""
        print("=" * 80)
        print("🚀 NexusCore Project Dashboard")
        print("=" * 80)
        print()
        
        # 基本情報
        print("📊 **基本情報**")
        print(f"   プロジェクトパス: {self.project_path}")
        print(f"   総レコード数: {project_data['total_records']}")
        if project_data['last_updated']:
            print(f"   最終更新: {self.format_timestamp(project_data['last_updated'])}")
        print()
        
        # Genesis情報
        if project_data['genesis']:
            genesis = project_data['genesis']
            print("🌟 **Genesis Block**")
            print(f"   作成日時: {self.format_timestamp(genesis.get('timestamp', 'N/A'))}")
            print(f"   エージェント: {genesis.get('agent', 'N/A')}")
            print(f"   バージョン: {genesis.get('version', 'N/A')}")
            
            # 統合サマリーを表示
            summary = genesis.get('data', {}).get('integrated_summary', {})
            if summary and isinstance(summary, dict):
                print("\n   📝 **プロジェクトサマリー**")
                for key, value in summary.items():
                    if isinstance(value, str) and len(value) > 100:
                        display_value = value[:97] + "..."
                    else:
                        display_value = str(value)
                    print(f"   • {key.replace('_', ' ').title()}: {display_value}")
            print()
        
        # スナップショット情報
        snapshots = project_data['snapshots']
        print(f"📈 **分析スナップショット** ({len(snapshots)} 件)")
        if snapshots:
            for i, snapshot in enumerate(snapshots[-5:], 1):  # 最新5件を表示
                timestamp = self.format_timestamp(snapshot.get('timestamp', 'N/A'))
                agent = snapshot.get('agent', 'N/A')
                print(f"   {i}. {timestamp} - {agent}")
        else:
            print("   まだスナップショットはありません。")
        print()
    
    def display_detailed_analysis(self, project_data: Dict[str, Any]) -> None:
        """詳細分析を表示"""
        print("🔍 **詳細分析**")
        print("-" * 60)
        
        if not project_data['genesis']:
            print("Genesis ブロックが見つかりません。")
            return
        
        genesis_data = project_data['genesis'].get('data', {})
        summary = genesis_data.get('integrated_summary', {})
        
        if not summary or 'error' in summary:
            print("統合サマリーにエラーがあります:")
            if 'error' in summary:
                print(f"   エラー: {summary.get('error')}")
                print(f"   詳細: {summary.get('details', 'N/A')}")
            return
        
        # 各セクションを詳細表示
        sections = [
            ("mission_and_purpose", "🎯 ミッション・目的"),
            ("architecture_and_agents", "🏗️ アーキテクチャ・エージェント"),
            ("policies_and_rules", "📋 ポリシー・ルール"),
            ("knowledge_and_experience", "🧠 知識・経験"),
            ("dependencies_and_stack", "📦 依存関係・スタック"),
            ("testing_philosophy", "🧪 テスト哲学"),
            ("ui_ux_philosophy", "🎨 UI/UX哲学"),
            ("meta_capabilities", "🔮 メタ機能")
        ]
        
        for key, title in sections:
            if key in summary:
                print(f"\n{title}")
                content = summary[key]
                if isinstance(content, str):
                    # 長いテキストを適切に改行
                    lines = content.split('\n')
                    for line in lines:
                        if len(line) > 70:
                            words = line.split()
                            current_line = ""
                            for word in words:
                                if len(current_line + word) > 70:
                                    print(f"   {current_line}")
                                    current_line = word + " "
                                else:
                                    current_line += word + " "
                            if current_line:
                                print(f"   {current_line}")
                        else:
                            print(f"   {line}")
                elif isinstance(content, (dict, list)):
                    print(f"   {json.dumps(content, ensure_ascii=False, indent=2)}")
                else:
                    print(f"   {content}")
        print()
    
    def display_statistics(self, project_data: Dict[str, Any]) -> None:
        """統計情報を表示"""
        print("📊 **統計情報**")
        print("-" * 60)
        
        # イベント種別ごとの統計
        event_counts = {}
        agent_counts = {}
        
        for record in self.chronicle_data:
            event = record.get('event', 'UNKNOWN')
            agent = record.get('agent', 'UNKNOWN')
            
            event_counts[event] = event_counts.get(event, 0) + 1
            agent_counts[agent] = agent_counts.get(agent, 0) + 1
        
 
```


## tools\price_sync.py

```python
# ==============================================================================
# ファイル: tools/price_sync.py
# 目的  : 主要ベンダの料金表を取得し、統一スキーマJSONを出力。
# 使い方:
#   python tools/price_sync.py --out data/cost_table.json
#   （.env に NEXUS_COST_TABLE_JSON=data/cost_table.json を設定）
# 依存  : pip install requests beautifulsoup4 python-dotenv
# 注意  : 各社のページ構造は変化しやすい。失敗時は fallback 値を使用。
# スキーマ:
# {
#   "<model_name>": {"in": <USD_per_1M>, "out": <USD_per_1M>},
#   ...
# }
# ==============================================================================

from __future__ import annotations
import os
import re
import json
import argparse
import logging
from typing import Dict, Any, Optional

import requests
from bs4 import BeautifulSoup
from dotenv import load_dotenv

load_dotenv(override=False)
logging.basicConfig(level=logging.INFO)
log = logging.getLogger("price_sync")

# ----------------------- Fallback（最低限の初期値） ----------------------- #
FALLBACK = {
    "gpt-4o": {"in": 2.50, "out": 10.00},
    "gemini-1.5-flash-latest": {"in": 0.0375, "out": 0.15},
    "gemini-1.5-pro-latest": {"in": 3.50, "out": 10.50},
    "claude-3-sonnet": {"in": 3.00, "out": 15.00},  # Console無料枠は別扱い
    "claude-3-haiku": {"in": 0.80, "out": 4.00},
    "deepseek-r1": {"in": 0.55, "out": 2.19},
    "command-r-plus": {"in": 2.50, "out": 10.00},
    "mistral-small": {"in": 0.25, "out": 0.60},
    "mistral-medium": {"in": 2.70, "out": 8.10},
    "kimi-k2": {"in": 0.15, "out": 2.50},
    "qwen-1_5-7b": {"in": 0.10, "out": 0.20},
    "yi-1_5-9b": {"in": 0.20, "out": 0.40},
}

# ----------------------- ユーティリティ ----------------------- #
def _usd_per_m_from_text(text: str) -> Optional[float]:
    """
    ' $0.15 / 1M tokens ' のような文字列から数値を抽出。
    小数 or 整数を許容。カンマは削除。
    """
    if not text:
        return None
    t = text.replace(",", "")
    m = re.search(r"\$?\s*([0-9]+(?:\.[0-9]+)?)\s*/\s*1\s*M", t, re.I)
    if not m:
        m = re.search(r"\$?\s*([0-9]+(?:\.[0-9]+)?)\s*(?:per|/)\s*M", t, re.I)
    return float(m.group(1)) if m else None

def _get(url: str) -> Optional[str]:
    try:
        r = requests.get(url, timeout=20)
        r.raise_for_status()
        return r.text
    except Exception as e:
        log.warning(f"fetch failed: {url} ({e})")
        return None

# ----------------------- 各社アダプタ（簡易スクレイプ） ----------------------- #
def sync_openai() -> Dict[str, Any]:
    # 参考: OpenAI pricing ページ（構造変動に注意）
    url = os.getenv("PRICE_URL_OPENAI", "https://openai.com/api/pricing/")
    html = _get(url)
    data = {}
    if html:
        soup = BeautifulSoup(html, "html.parser")
        # 例: gpt-4o in/out をそれぞれ拾う（簡易；構造変更時は正規表現で保険）
        text = soup.get_text(" ", strip=True)
        # ざっくり検索
        gpt4o_in = _usd_per_m_from_text(re.search(r"GPT-4o.*?Input.*?\$?\s*([0-9\.\,]+)\s*/\s*1M", text, re.I|re.S).group(0)) if re.search(r"GPT-4o.*?Input", text, re.I|re.S) else None
        gpt4o_out = _usd_per_m_from_text(re.search(r"GPT-4o.*?(Output|Completion).*?\$?\s*([0-9\.\,]+)\s*/\s*1M", text, re.I|re.S).group(0)) if re.search(r"GPT-4o.*?(Output|Completion)", text, re.I|re.S) else None
        if gpt4o_in and gpt4o_out:
            data["gpt-4o"] = {"in": gpt4o_in, "out": gpt4o_out}
    return data

def sync_gemini() -> Dict[str, Any]:
    url = os.getenv("PRICE_URL_GEMINI", "https://ai.google.dev/pricing")
    html = _get(url)
    data = {}
    if html:
        soup = BeautifulSoup(html, "html.parser")
        text = soup.get_text(" ", strip=True)
        # Flash の単価を粗く抽出（価格体系は階層的なため、最低水準の例を拾う）
        flash_in = _usd_per_m_from_text(re.search(r"Gemini 1\.5 Flash.*?Input.*?\$?[0-9\.\,]+/?\s*1M", text, re.I|re.S).group(0)) if re.search(r"Gemini 1\.5 Flash.*?Input", text, re.I|re.S) else None
        flash_out = _usd_per_m_from_text(re.search(r"Gemini 1\.5 Flash.*?(Output|Generate).*?\$?[0-9\.\,]+/?\s*1M", text, re.I|re.S).group(0)) if re.search(r"Gemini 1\.5 Flash.*?(Output|Generate)", text, re.I|re.S) else None
        if flash_in and flash_out:
            data["gemini-1.5-flash-latest"] = {"in": flash_in, "out": flash_out}
        # Pro も同様に（必要に応じて）
        pro_in = _usd_per_m_from_text(re.search(r"Gemini 1\.5 Pro.*?Input.*?\$?[0-9\.\,]+/?\s*1M", text, re.I|re.S).group(0)) if re.search(r"Gemini 1\.5 Pro.*?Input", text, re.I|re.S) else None
        pro_out = _usd_per_m_from_text(re.search(r"Gemini 1\.5 Pro.*?(Output|Generate).*?\$?[0-9\.\,]+/?\s*1M", text, re.I|re.S).group(0)) if re.search(r"Gemini 1\.5 Pro.*?(Output|Generate)", text, re.I|re.S) else None
        if pro_in and pro_out:
            data["gemini-1.5-pro-latest"] = {"in": pro_in, "out": pro_out}
    return data

def sync_anthropic() -> Dict[str, Any]:
    url = os.getenv("PRICE_URL_ANTHROPIC", "https://www.anthropic.com/pricing")
    html = _get(url)
    data = {}
    if html:
        soup = BeautifulSoup(html, "html.parser")
        text = soup.get_text(" ", strip=True)
        # Sonnet/Haiku 抽出（3.x/3.5 等の表記差あり→名称で広めに拾う）
        sonnet_in = _usd_per_m_from_text(re.search(r"Sonnet.*?Input.*?\$?[0-9\.\,]+/?\s*1M", text, re.I|re.S).group(0)) if re.search(r"Sonnet.*?Input", text, re.I|re.S) else None
        sonnet_out = _usd_per_m_from_text(re.search(r"Sonnet.*?(Output|Generate).*?\$?[0-9\.\,]+/?\s*1M", text, re.I|re.S).group(0)) if re.search(r"Sonnet.*?(Output|Generate)", text, re.I|re.S) else None
        haiku_in = _usd_per_m_from_text(re.search(r"Haiku.*?Input.*?\$?[0-9\.\,]+/?\s*1M", text, re.I|re.S).group(0)) if re.search(r"Haiku.*?Input", text, re.I|re.S) else None
        haiku_out = _usd_per_m_from_text(re.search(r"Haiku.*?(Output|Generate).*?\$?[0-9\.\,]+/?\s*1M", text, re.I|re.S).group(0)) if re.search(r"Haiku.*?(Output|Generate)", text, re.I|re.S) else None
        if sonnet_in and sonnet_out:
            data["claude-3-sonnet"] = {"in": sonnet_in, "out": sonnet_out}
        if haiku_in and haiku_out:
            data["claude-3-haiku"] = {"in": haiku_in, "out": haiku_out}
    return data

def sync_deepseek() -> Dict[str, Any]:
    url = os.getenv("PRICE_URL_DEEPSEEK", "https://api-docs.deepseek.com/")  # 公式ドキュメントTOP等
    html = _get(url)
    data = {}
    if html:
        text = BeautifulSoup(html, "html.parser").get_text(" ", strip=True)
        r1_in = _usd_per_m_from_text(re.search(r"(Reasoner|R1).*?Input.*?\$?[0-9\.\,]+/?\s*1M", text, re.I|re.S).group(0)) if re.search(r"(Reasoner|R1).*?Input", text, re.I|re.S) else None
        r1_out = _usd_per_m_from_text(re.search(r"(Reasoner|R1).*?(Output|Generate).*?\$?[0-9\.\,]+/?\s*1M", text, re.I|re.S).group(0)) if re.search(r"(Reasoner|R1).*?(Output|Generate)", text, re.I|re.S) else None
        if r1_in and r1_out:
            data["deepseek-r1"] = {"in": r1_in, "out": r1_out}
    return data

def sync_cohere() -> Dict[str, Any]:
    url = os.getenv("PRICE_URL_COHERE", "https://cohere.com/pricing")
    html = _get(url)
    data = {}
    if html:
        text = BeautifulSoup(html, "html.parser").get_text(" ", strip=True)
        cmdr_in = _usd_per_m_from_text(re.search(r"Command R\+.*?Input.*?\$?[0-9\.\,]+/?\s*1M", text, re.I|re.S).group(0)) if re.search(r"Command R\+.*?Input", text, re.I|re.S) else None
        cmdr_out = _usd_per_m_from_text(re.search(r"Command R\+.*?(Output|Generate).*?\$?[0-9\.\,]+/?\s*1M", text, re.I|re.S).group(0)) if re.search(r"Command R\+.*?(Output|Generate)", text, re.I|re.S) else None
        if cmdr_in and cmdr_out:
            data["command-r-plus"] = {"in": cmdr_in, "out": cmdr_out}
    return data

def sync_mistral() -> Dict[str, Any]:
    url = os.getenv("PRICE_URL_MISTRAL", "https://mistral.ai/technology/#pricing")
    html = _get(url)
    data = {}
    if html:
        text = BeautifulSoup(html, "html.parser").get_text(" ", strip=True)
        small_in = _usd_per_m_from_text(re.search(r"Mistral (Small|sm).*?Input.*?\$?[0-9\.\,]+/?\s*1M", text, re.I|re.S).group(0)) if re.search(r"Mistral (Small|sm).*?Input", text, re.I|re.S) else None
        small_out = _usd_per_m_from_text(re.search(r"Mistral (Small|sm).*?(Output|Generate).*?\$?[0-9\.\,]+/?\s*1M", text, re.I|re.S).group(0)) if re.search(r"Mistral (Small|sm).*?(Output|Generate)", text, re.I|re.S) else None
        if small_in and small_out:
            data["mistral-small"] = {
```


## tools\gradio_project_export_ui.py

```python
# ファイル名: gradio_project_export_ui.py
# メモ:
# - 出力フォルダは「exported_projects」配下にまとめて管理
# - サブフォルダ名は「プロジェクト名_YYYYMMDD_HHMMSS」で分かりやすく自動生成
# - ダウンロードボタンは常に有効化、出力完了時に明確な通知
# - 出力ボタンはvariant="primary"で青色に強調
# - 古いエクスポートフォルダは自動クリーンアップ（1時間）
# - ファイルコピーは自動削除されるのでHDD圧迫を防止

import gradio as gr
import os
import json
import zipfile
import tempfile
import shutil
import time
import logging
from datetime import datetime

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

EXPORT_PARENT_DIR = "exported_projects"
os.makedirs(EXPORT_PARENT_DIR, exist_ok=True)
CLEANUP_SECONDS = 60 * 60  # 1時間

def cleanup_exported_projects():
    now = time.time()
    for folder in os.listdir(EXPORT_PARENT_DIR):
        folder_path = os.path.join(EXPORT_PARENT_DIR, folder)
        if os.path.isdir(folder_path):
            try:
                mtime = os.path.getmtime(folder_path)
                if now - mtime > CLEANUP_SECONDS:
                    shutil.rmtree(folder_path)
                    logging.info(f"Cleaned up old export folder: {folder_path}")
            except Exception as e:
                logging.warning(f"Failed to cleanup {folder_path}: {e}")

def export_structure_and_code(uploaded_file, extensions, prefix, suffix):
    cleanup_exported_projects()

    # ファイル名取得
    if hasattr(uploaded_file, "name") and isinstance(uploaded_file.name, str):
        filename = os.path.basename(uploaded_file.name)
        input_path = uploaded_file.name
    elif isinstance(uploaded_file, str):
        filename = os.path.basename(uploaded_file)
        input_path = uploaded_file
    else:
        filename = "uploaded_file"
        input_path = os.path.join(EXPORT_PARENT_DIR, filename)
        with open(input_path, "wb") as f:
            f.write(uploaded_file.read())

    # プロジェクト名・時刻でサブフォルダ名生成
    base_name = os.path.splitext(filename)[0]
    nowstr = datetime.now().strftime("%Y%m%d_%H%M%S")
    export_dir = os.path.join(EXPORT_PARENT_DIR, f"{base_name}_{nowstr}")
    os.makedirs(export_dir, exist_ok=True)

    _, ext = os.path.splitext(filename)
    ext = ext.lower()

    if ext == ".zip":
        try:
            with zipfile.ZipFile(input_path, 'r') as zip_ref:
                zip_ref.extractall(export_dir)
            logging.info(f"Extracted zip to {export_dir}")
        except Exception as e:
            shutil.rmtree(export_dir)
            logging.error(f"ZIP extraction failed: {e}")
            raise gr.Error(f"ZIPファイルの解凍に失敗しました: {e}")
        extracted_items = os.listdir(export_dir)
        if len(extracted_items) == 1 and os.path.isdir(os.path.join(export_dir, extracted_items[0])):
            project_root = os.path.join(export_dir, extracted_items[0])
            folder_name = os.path.basename(project_root)
        else:
            project_root = export_dir
            folder_name = base_name
    else:
        try:
            project_root = os.path.join(export_dir, "single_file_project")
            os.makedirs(project_root, exist_ok=True)
            dest_path = os.path.join(project_root, filename)
            shutil.copy(input_path, dest_path)
            folder_name = base_name
            logging.info(f"Copied file to {dest_path}")
        except Exception as e:
            shutil.rmtree(export_dir)
            logging.error(f"File copy failed: {e}")
            raise gr.Error(f"ファイルのコピーに失敗しました: {e}")

    def create_folder_structure_json(path):
        result = {'name': os.path.basename(path), 'type': 'folder', 'children': []}
        if not os.path.isdir(path):
            return result
        try:
            entries = sorted(os.listdir(path))
        except Exception as e:
            logging.error(f"Failed to listdir {path}: {e}")
            return {'name': os.path.basename(path), 'type': 'folder', 'children': [], 'error': str(e)}
        for entry in entries:
            full_path = os.path.join(path, entry)
            if os.path.isdir(full_path):
                result['children'].append(create_folder_structure_json(full_path))
            else:
                result['children'].append({'name': entry, 'type': 'file'})
        return result

    structure = create_folder_structure_json(project_root)
    structure_json = os.path.join(export_dir, f"{prefix}{folder_name}{suffix}_structure_{nowstr}.json")
    combined_code = os.path.join(export_dir, f"{prefix}{folder_name}{suffix}_combined_code_{nowstr}.txt")

    try:
        with open(structure_json, "w", encoding="utf-8") as f:
            json.dump(structure, f, indent=4, ensure_ascii=False)
        logging.info(f"Saved structure JSON: {structure_json}")
    except Exception as e:
        logging.error(f"Failed to save structure JSON: {e}")
        raise gr.Error(f"構造JSONの保存に失敗: {e}")

    exts = [e.strip() for e in extensions.split(",") if e.strip()]
    files_found = 0
    try:
        with open(combined_code, "w", encoding="utf-8") as outfile:
            for dirpath, _, filenames in os.walk(project_root):
                for filename in sorted(filenames):
                    if any(filename.endswith(ext) for ext in exts):
                        file_path = os.path.join(dirpath, filename)
                        rel_path = os.path.relpath(file_path, project_root)
                        outfile.write(f"\n\n# === File: {rel_path} ===\n\n")
                        try:
                            with open(file_path, "r", encoding="utf-8") as infile:
                                outfile.write(infile.read())
                            files_found += 1
                        except Exception as e:
                            outfile.write(f"[読み込みエラー: {e}]\n")
                            logging.warning(f"Failed to read file {file_path}: {e}")
        logging.info(f"Saved combined code: {combined_code} (files found: {files_found})")
    except Exception as e:
        logging.error(f"Failed to save combined code: {e}")
        raise gr.Error(f"統合コードファイルの保存に失敗: {e}")

    if files_found == 0:
        logging.warning("No files found for the specified extensions.")
        raise gr.Warning("指定した拡張子のファイルが見つかりませんでした。")

    notify_msg = f"出力が完了しました！\n{os.path.basename(export_dir)}\n構造JSON: {os.path.basename(structure_json)}\n統合コード: {os.path.basename(combined_code)}"
    return structure_json, combined_code, notify_msg

with gr.Blocks() as demo:
    gr.Markdown("""
    # プロジェクト構造＆コード統合ファイル 出力ツール
    1. プロジェクトフォルダ(zip)または個別ファイル（.py, .txt, .md, .jsonなど）をアップロード
    2. 統合したい拡張子をカンマ区切りで入力（例: .py,.txt,.md）
    3. 出力ファイル名のプレフィックス・サフィックスを指定（任意）
    4. 「出力」ボタンを押すと、ダウンロードボタンと通知が表示されます
    """)

    file_input = gr.File(
        label="プロジェクトフォルダ（zip）または個別ファイルをアップロード",
        file_types=[".zip", ".py", ".txt", ".md", ".json"]
    )
    ext_input = gr.Textbox(label="統合する拡張子（カンマ区切り）", value=".py,.txt,.md", placeholder=".py,.txt,.md など")
    prefix_input = gr.Textbox(label="出力ファイル名のプレフィックス", value="", placeholder="例: my_")
    suffix_input = gr.Textbox(label="出力ファイル名のサフィックス", value="", placeholder="例: _v1")
    out1 = gr.DownloadButton(label="Download 構造JSON", visible=True)
    out2 = gr.DownloadButton(label="Download 統合コード", visible=True)
    notify = gr.Textbox(label="通知", visible=True)
    btn = gr.Button("出力", interactive=True, variant="primary")  # ここで青色ボタンに

    def enable_btn(file):
        return gr.update(interactive=True)

    file_input.change(enable_btn, inputs=file_input, outputs=btn)

    def on_click(uploaded_file, extensions, prefix, suffix):
        if uploaded_file is None:
            raise gr.Error("zipまたはファイルをアップロードしてください。")
        return export_structure_and_code(uploaded_file, extensions, prefix, suffix)

    btn.click(on_click, inputs=[file_input, ext_input, prefix_input, suffix_input], outputs=[out1, out2, notify])

demo.launch(inbrowser=True)

```


## tools\backup_tool.py

```python
# ==============================================================================
# フォルダ: scripts
# ファイル名: backup_tool.py
# メモ: Gitリポジトリを効率的にバックアップし、世代管理も行うツール。【バグ修正版 v3】
# ==============================================================================

import os
import re
import subprocess
import logging
from datetime import datetime, timedelta

# ==============================================================================
# 設定項目
# ==============================================================================

# バックアップ対象のプロジェクト（Gitリポジトリ）のフルパスを指定
# raw文字列(r"...")を使うことで、パス区切り文字(\)を気にせず記述できます
SOURCE_DIRECTORIES = [
    r"C:\Users\USER\tools\NexusCore",
]

# バックアップファイルの保存先ディレクトリのフルパスを指定
# フォルダ名にスペースを含めないことで、予期せぬエラーを防ぎます
BACKUP_DESTINATION = r"C:\Users\USER\tools\BackupNexusCore"

# バックアップファイルを保持する日数（この日数を超えた古いファイルは自動で削除されます）
RETENTION_DAYS = 30

# ログファイルの保存先ディレクトリ
LOG_DIRECTORY = os.path.join(BACKUP_DESTINATION, "logs")

# ==============================================================================
# スクリプト本体
# ==============================================================================

def setup_logging():
    """ロギング機能のセットアップ"""
    os.makedirs(LOG_DIRECTORY, exist_ok=True)
    log_file = os.path.join(LOG_DIRECTORY, f"backup_{datetime.now():%Y-%m-%d}.log")
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
        handlers=[
            logging.FileHandler(log_file, encoding='utf-8'),
            logging.StreamHandler()
        ]
    )

def sanitize_filename(name: str) -> str:
    """ファイル名に使用できない文字を除去・置換する"""
    # Windows/Linuxなどでファイル名として使えない文字をアンダースコアに置換
    invalid_chars = r'[<>:"/\\|?*\s]'
    return re.sub(invalid_chars, '_', name)

def create_git_bundle(repo_path: str, dest_dir: str) -> bool:
    """
    指定されたGitリポジトリのバンドルファイルを作成する。
    """
    repo_name = sanitize_filename(os.path.basename(repo_path))
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    bundle_filename = f"{repo_name}_{timestamp}.bundle"
    bundle_filepath = os.path.join(dest_dir, bundle_filename)

    logging.info(f"リポジトリ '{repo_name}' のバックアップを開始します...")

    # .gitディレクトリの存在確認を強化
    git_dir = os.path.join(repo_path, ".git")
    if not (os.path.isdir(git_dir) or os.path.isfile(git_dir)):
        logging.error(f"'{repo_path}' はGitリポジトリではありません。スキップします。")
        return False

    try:
        # git bundleコマンド実行
        cmd = ["git", "bundle", "create", bundle_filepath, "--all"]
        result = subprocess.run(
            cmd,
            cwd=repo_path,
            capture_output=True,
            text=True,
            check=True,
            encoding='utf-8',
            timeout=300  # 5分のタイムアウトを追加。巨大なリポジトリでもハングしないようにする
        )
        
        # バンドルファイルのサイズ確認
        if os.path.exists(bundle_filepath):
            file_size = os.path.getsize(bundle_filepath)
            if file_size == 0:
                logging.error(f"生成されたバンドルファイルが空です。削除します: {bundle_filepath}")
                os.remove(bundle_filepath)
                return False
            
            logging.info(f"バンドルファイルを作成しました: {bundle_filepath} ({file_size:,} bytes)")
        
        return True
        
    except subprocess.TimeoutExpired:
        logging.error(f"バンドル作成がタイムアウトしました（5分以上経過）: {repo_name}")
        return False
    except FileNotFoundError:
        logging.error("'git' コマンドが見つかりません。Gitがインストールされ、PATHが通っているか確認してください。")
        return False
    except subprocess.CalledProcessError as e:
        logging.error(f"バンドルファイルの作成に失敗しました: {repo_name}")
        logging.error(f"リターンコード: {e.returncode}")
        logging.error(f"エラー出力:\n{e.stderr}")
        return False
    except Exception as e:
        logging.error(f"予期せぬエラーが発生しました: {e}", exc_info=True)
        return False

def rotate_backups(dest_dir: str):
    """指定されたディレクトリ内の古いバックアップファイルを削除する"""
    logging.info(f"バックアップの世代管理を開始します (保持期間: {RETENTION_DAYS}日)...")
    cutoff_date = datetime.now() - timedelta(days=RETENTION_DAYS)
    
    try:
        bundle_files = [f for f in os.listdir(dest_dir) if f.endswith(".bundle")]
        
        for filename in bundle_files:
            filepath = os.path.join(dest_dir, filename)
            
            # より厳密な正規表現による日付抽出
            match = re.search(r'_(\d{8})_\d{6}\.bundle$', filename)
            
            if not match:
                logging.warning(f"ファイル名の形式が不正です。スキップします: {filename}")
                continue
            
            try:
                date_str = match.group(1)
                file_date = datetime.strptime(date_str, "%Y%m%d")
                
                if file_date < cutoff_date:
                    logging.info(f"古いバックアップファイルを削除します: {filename}")
                    os.remove(filepath)
                else:
                    logging.debug(f"保持対象のファイルです: {filename}")

            except ValueError as e:
                logging.error(f"ファイル名に含まれる日付の解析に失敗しました ({filename}): {e}")
            except Exception as e:
                logging.error(f"ファイル処理中に予期せぬエラーが発生しました ({filename}): {e}")

    except FileNotFoundError:
        logging.warning(f"バックアップディレクトリが見つかりません: {dest_dir}")
    except Exception as e:
        logging.error(f"世代管理中に予期せぬエラーが発生しました: {e}", exc_info=True)

def main():
    """メイン処理"""
    setup_logging()
    logging.info("================ バックアップ処理開始 ================")

    # バックアップ先ディレクトリの作成
    try:
        os.makedirs(BACKUP_DESTINATION, exist_ok=True)
        logging.info(f"バックアップ先ディレクトリ: {BACKUP_DESTINATION}")
    except Exception as e:
        logging.critical(f"バックアップ先ディレクトリの作成に失敗しました: {e}")
        return

    # 各リポジトリのバックアップ実行
    success_count = 0
    for src_dir in SOURCE_DIRECTORIES:
        if not os.path.isdir(src_dir):
            logging.warning(f"指定されたソースディレクトリが見つかりません: {src_dir}")
            continue
            
        if create_git_bundle(src_dir, BACKUP_DESTINATION):
            success_count += 1

    logging.info(f"バックアップ作成完了 ({success_count}/{len(SOURCE_DIRECTORIES)}件 成功)")

    # 古いバックアップの削除
    rotate_backups(BACKUP_DESTINATION)

    logging.info("================ バックアップ処理終了 ================")

if __name__ == "__main__":
    main()

```


## tools\chatgpt_whisper_chatbot.py

```python
# ファイル名: chatgpt_whisper_chatbot.py
# メモ:
# - OpenAIのChatGPT APIとWhisper APIを使った日本語対応チャットボット
# - テキスト入力も音声入力（Whisperで文字起こし）もOK
# - GradioでWeb UI
# - チャット履歴はGradio形式で管理
# - .envファイルに OPENAI_API_KEY=sk-... を記載しておくこと

import gradio as gr
from openai import OpenAI
import os
from dotenv import load_dotenv
import logging
import tempfile
import sounddevice as sd
import numpy as np
from scipy.io.wavfile import write
import threading
import time

# --- 環境変数・APIキー読み込み ---
load_dotenv()
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
if not OPENAI_API_KEY:
    raise RuntimeError("OPENAI_API_KEYが設定されていません。.envファイルを確認してください。")

client = OpenAI(api_key=OPENAI_API_KEY)

logging.basicConfig(level=logging.INFO)

# --- Whisper APIで音声ファイルを文字起こし ---
def transcribe_with_whisper(audio_path):
    try:
        with open(audio_path, "rb") as f:
            transcript = client.audio.transcriptions.create(
                model="whisper-1",
                file=f,
                language="ja"
            )
        return transcript.text
    except Exception as e:
        raise gr.Error(f"Whisper APIエラー: {e}")

# --- ChatGPTでAIチャット応答（Gradio履歴形式に対応） ---
def chatgpt_respond(history, message):
    # history: [[user, ai], ...] 形式
    # OpenAI API用の履歴に変換
    api_history = []
    for pair in history:
        if pair[0] is not None:
            api_history.append({"role": "user", "content": pair[0]})
        if pair[1] is not None:
            api_history.append({"role": "assistant", "content": pair[1]})
    if message:
        api_history.append({"role": "user", "content": message})
        try:
            response = client.chat.completions.create(
                model="gpt-3.5-turbo",
                messages=api_history,
                max_tokens=512,
                temperature=0.7
            )
            ai_reply = response.choices[0].message.content.strip()
        except Exception as e:
            raise gr.Error(f"ChatGPT APIエラー: {e}")
        # Gradio用履歴に追加
        history.append([message, ai_reply])
    return history, ""

# --- 音声録音（エンターで終了） ---
def record_until_keypress(max_duration=60, sample_rate=16000):
    logging.info(f"録音中... 最大{max_duration}秒、エンターキーで終了")
    recording = []
    event = threading.Event()
    start_time = time.time()

    def callback(indata, frames, t, status):
        if time.time() - start_time > max_duration:
            event.set()
            raise sd.CallbackAbort
        recording.append(indata.copy())

    def record_thread():
        with sd.InputStream(samplerate=sample_rate, channels=1, callback=callback):
            event.wait()

    def key_thread():
        input()  # エンターキー入力待ち
        event.set()

    t1 = threading.Thread(target=record_thread)
    t2 = threading.Thread(target=key_thread)
    t1.start()
    t2.start()
    t2.join(timeout=max_duration)
    t1.join(timeout=1)
    if recording:
        return np.concatenate(recording, axis=0), sample_rate
    return None, sample_rate

def process_audio():
    """音声を録音→Whisperで文字起こし→テキスト返却"""
    try:
        audio_data, fs = record_until_keypress(max_duration=60)
        if audio_data is None:
            raise gr.Warning("録音がキャンセルされました。")
        temp_file = tempfile.NamedTemporaryFile(suffix=".wav", delete=False)
        write(temp_file.name, fs, audio_data)
        text = transcribe_with_whisper(temp_file.name)
        os.unlink(temp_file.name)
        return text
    except gr.Warning as w:
        raise w
    except Exception as e:
        logging.error(f"音声処理エラー: {str(e)}")
        raise gr.Error(f"音声処理エラー: {e}")

# --- Gradio UI（日本語化） ---
with gr.Blocks(title="ChatGPT＋Whisperチャットボット", theme=gr.themes.Soft(primary_hue="blue")) as demo:
    gr.Markdown(
        """
        # ChatGPT＋Whisper チャットボット
        - テキストまたは音声でメッセージを入力できます
        - Whisper（音声認識API）＋ChatGPT（AI応答API）両対応
        """
    )
    chatbot = gr.Chatbot(height=600, label="チャット履歴", show_copy_button=True)
    with gr.Group():
        with gr.Row():
            msg = gr.Textbox(
                container=False,
                show_label=False,
                label="メッセージを入力",
                placeholder="テキストを入力、または音声を録音...",
                scale=7,
                autofocus=True
            )
            sub = gr.Button("送信", variant="primary", scale=1, min_width=100)
            record_btn = gr.Button("🎤 録音", variant="secondary", scale=1, min_width=100)
    with gr.Row():
        clear = gr.Button("🗑️ 履歴クリア", variant="secondary")

    session_state = gr.State([])

    # 音声録音ボタン
    record_btn.click(
        process_audio,
        [],
        [msg]
    )

    # チャット送信（AI応答）
    sub.click(
        chatgpt_respond,
        inputs=[session_state, msg],
        outputs=[chatbot, msg]
    )

    # クリアボタン
    def clear_all():
        return [], ""
    clear.click(clear_all, inputs=[], outputs=[chatbot, msg])

demo.launch()

```


## tools\watcher.py

```python
# ==============================================================================
# フォルダ: tools/
# ファイル名: watcher.py
# メモ: v3.0 - 変更差分をLLMに送り、開発内容の要約を自動生成・記録する完全自動版。
#
# 使い方:
# python tools/watcher.py
# ==============================================================================
import time
import logging
from collections import deque
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
import os
import threading
import pathspec
import git # GitPythonをインポート

# Chronicle Scribeの記録機能をインポート
from scribe import log_manual_event

# --- 設定 ---
PROMPT_DELAY_SECONDS = 600 # 10分
RECENT_FILES_LIMIT = 20

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')

# ==============================================================================
# ★★★★★ 要実装 ★★★★★
# ==============================================================================
def summarize_changes_with_llm(diff_text: str, file_list: list) -> str:
    """
    LLMを呼び出して、コードの差分から作業内容の要約を生成する。
    """
    logging.info("LLMに作業内容の要約を問い合わせ中...")
    
    prompt = f"""
    あなたは、チームの開発状況を常に把握している、優秀なテックリードです。
    以下のファイル変更の差分（diff）を分析し、開発者がどのような作業をしていたかを、
    gitのコミットメッセージのように簡潔な一行で要約してください。

    # 変更されたファイルリスト
    {', '.join(file_list)}

    # 変更内容の差分
    ```diff
    {diff_text}
    ```

    # 出力指示
    - 要約のみを、一行のテキストで出力してください。
    - 例: feat(agent): Watcher Agentに自己要約機能を追加
    - 例: fix(scribe): ファイルパスの解決ロジックを修正
    """
    
    # 【要実装】ここに、お客様の環境に合わせたLLM呼び出しコードを記述してください。
    # 例:
    # from your_llm_client import call_gemini
    # return call_gemini(prompt)

    logging.warning("現在、LLM呼び出しはモックアップです。`summarize_changes_with_llm`を実装してください。")
    mock_summary = f"feat(auto-summary): {', '.join(file_list)} を自動的に要約しました。"
    return mock_summary
# ==============================================================================

def load_gitignore_patterns(project_root: str):
    # (v2.0から変更なし)
    gitignore_path = os.path.join(project_root, ".gitignore")
    patterns = []
    if os.path.exists(gitignore_path):
        with open(gitignore_path, "r", encoding="utf-8") as f:
            patterns = f.read().splitlines()
    patterns.extend([".git/", "__pycache__/", "*.pyc", "project_chronicle.jsonl", ".idea/", ".vscode/"])
    return pathspec.PathSpec.from_lines('gitwildmatch', patterns)

class DevelopmentEventHandler(FileSystemEventHandler):
    def __init__(self, project_root: str, ignore_spec: pathspec.PathSpec, repo: git.Repo):
        self.project_root = project_root
        self.ignore_spec = ignore_spec
        self.repo = repo
        self.prompt_timer = None
        self.recently_modified_files = deque(maxlen=RECENT_FILES_LIMIT)
        self.lock = threading.Lock()

    def on_modified(self, event):
        # (v2.0から変更なし)
        if event.is_directory: return
        rel_path = os.path.relpath(event.src_path, self.project_root)
        if self.ignore_spec.match_file(rel_path): return

        with self.lock:
            logging.info(f"ファイル変更を検知: {rel_path}")
            if rel_path not in self.recently_modified_files:
                self.recently_modified_files.append(rel_path)
            if self.prompt_timer: self.prompt_timer.cancel()
            self.prompt_timer = threading.Timer(PROMPT_DELAY_SECONDS, self._trigger_auto_summary)
            self.prompt_timer.start()

    def _trigger_auto_summary(self):
        with self.lock:
            if not self.recently_modified_files: return

            logging.info("開発活動の停止を検知。作業内容の自動要約を開始します。")
            
            # 差分を取得
            try:
                # HEAD (最新コミット) との差分を取得
                diff_text = self.repo.git.diff('HEAD', *self.recently_modified_files)
                if not diff_text:
                    logging.info("差分がありませんでした。記録をスキップします。")
                    self.recently_modified_files.clear()
                    return
            except git.exc.GitCommandError as e:
                logging.error(f"Git差分の取得に失敗しました: {e}")
                self.recently_modified_files.clear()
                return

            # LLMで要約を生成
            summary = summarize_changes_with_llm(diff_text, list(self.recently_modified_files))

            # クロニクルに記録
            if summary:
                log_manual_event(self.project_root, summary)
            
            self.recently_modified_files.clear()

def main():
    current_dir = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.dirname(current_dir)
    
    try:
        repo = git.Repo(project_root)
    except git.InvalidGitRepositoryError:
        logging.error(f"Gitリポジトリが見つかりません: {project_root}")
        logging.error("Watcher Agent v3.0は、差分を検知するためにGit管理下にある必要があります。")
        return

    logging.info(f"🤖 Watcher Agent v3.0 (自己要約モード) を起動します。")
    ignore_spec = load_gitignore_patterns(project_root)
    
    event_handler = DevelopmentEventHandler(project_root, ignore_spec, repo)
    observer = Observer()
    observer.schedule(event_handler, project_root, recursive=True)
    observer.start()

    try:
        while True: time.sleep(1)
    except KeyboardInterrupt:
        observer.stop()
        logging.info("\n👋 Watcher Agentを停止します。")
    observer.join()

if __name__ == "__main__":
    main()

```


## tools\prompt_batcher.py

```python
# ==============================================================================
# ファイル: tools/prompt_batcher.py
# 目的  : 類似エラーや複数ファイルの指摘を "1プロンプト" に安全圧縮。
# 改良点:
#   - 重複除去（path+内容ハッシュ）
#   - シークレット簡易マスキング
#   - 全体サイズ上限（max_total_chars）
#   - 出力言語制御 (locale)
#   - 追加ask_style: "consensus_ready"（後段集約向けJSON）
# ==============================================================================

from __future__ import annotations
from typing import List, Dict
import hashlib
import re

_SECRET_PATTERNS = [
    r"sk-[A-Za-z0-9]{20,}",            # OpenAI風
    r"(?i)api[_-]?key\s*[:=]\s*[A-Za-z0-9\-\._]{16,}",
    r"(?i)secret\s*[:=]\s*[A-Za-z0-9\-\._]{16,}",
    r"(?i)token\s*[:=]\s*[A-Za-z0-9\-\._]{16,}",
]

def _shorten(s: str, lim: int) -> str:
    if len(s) <= lim:
        return s
    return s[: max(0, lim - 100)] + "\n...<truncated>..."

def _mask_secrets(s: str) -> str:
    out = s
    for pat in _SECRET_PATTERNS:
        out = re.sub(pat, "[REDACTED]", out)
    return out

def _dedup(snippets: List[Dict[str, str]]) -> List[Dict[str, str]]:
    seen = set()
    uniq = []
    for it in snippets:
        key_src = f"{it.get('path','')}::{it.get('content','')[:500]}"
        h = hashlib.sha1(key_src.encode("utf-8")).hexdigest()
        if h in seen:
            continue
        seen.add(h)
        uniq.append(it)
    return uniq

def build_batch_prompt(
    task_title: str,
    code_snippets: List[Dict[str, str]],
    max_items: int = 10,
    max_chars_per_snippet: int = 1200,
    ask_style: str = "bullet_critical",  # "bullet_critical" | "yes_no" | "patch_suggestion" | "consensus_ready"
    max_total_chars: int = 18000,
    locale: str = "ja",  # "ja" or "en"
) -> str:
    """
    Args:
      task_title: 例) "pytest失敗の共通原因レビュー"
      code_snippets: [{"path": "src/x.py", "content": "...", "error": "Traceback..."}]
      max_items: バッチ化する最大件数
      max_chars_per_snippet: 各スニペットの最大文字数（超過時は省略）
      ask_style: 出力フォーマットの誘導
      max_total_chars: 生成プロンプト全体の最大文字数（超過時は末尾カット）
      locale: 出力言語のヒント（"ja" / "en"）
    """
    # 1) 事前整形：重複除去 & シークレットマスク
    items = _dedup(code_snippets)[:max_items]

    blocks = []
    for i, it in enumerate(items, 1):
        code = _mask_secrets(it.get("content", ""))
        err = _mask_secrets(it.get("error", ""))
        blocks.append(
            f"### [{i}] {it.get('path','')}\n"
            f"--- code ---\n{_shorten(code, max_chars_per_snippet)}\n"
            f"--- error ---\n{_shorten(err, 800)}\n"
        )

    if ask_style == "bullet_critical":
        ask = (
            "出力は以下のJSONのみ:\n"
            "{ \"global_root_cause\": string,\n"
            "  \"common_fixes\": [string],\n"
            "  \"file_specific\": [{\"path\": string, \"fix\": string}]\n"
            "}\n"
            "冗長説明、序文、コードフェンスは禁止。"
        )
    elif ask_style == "yes_no":
        ask = "各項目に対し Yes/No と1行根拠のみを出力せよ。"
    elif ask_style == "patch_suggestion":
        ask = "各ファイルの修正案を最小差分で提案せよ（Unified Diff禁止、要点のみ）。"
    elif ask_style == "consensus_ready":
        # 後段のコンセンサス統合用に、モデル間で整合しやすい最小JSONを指定
        ask = (
            "Return ONLY JSON with schema:\n"
            "{ \"issues\":[{\"title\":string,\"evidence\":string}],"
            "  \"severity\":\"low|medium|high\","
            "  \"confidence\":0.0-1.0 }\n"
            "No preface. No code fences. Keep output minimal (≤300 chars)."
        )
    else:
        ask = "Answer concisely."

    header_ja = (
        f"# タスク: {task_title}\n"
        f"以下の複数エラー/コード断片を一括レビューし、共通原因と修正方針を抽出してください。\n"
        f"**短く・論点のみ** で回答すること。\n\n"
    )
    header_en = (
        f"# Task: {task_title}\n"
        f"Review multiple error/code snippets together and extract common root causes and fixes.\n"
        f"Respond **briefly and to the point**.\n\n"
    )
    header = header_ja if locale.lower().startswith("ja") else header_en

    prompt = header + "\n".join(blocks) + "\n\n" + ask

    # 2) 全体サイズ上限
    if len(prompt) > max_total_chars:
        prompt = prompt[: max_total_chars - 40] + "\n...<prompt_truncated>"

    return prompt

```


## tools\logicbridge_chatbot.py

```python
# ファイル名: logicbridge_chatbot.py
# 必要ライブラリ: gradio, openai, python-dotenv, json
# .envファイルに OPENAI_API_KEY=sk-... を記載
# 機能: OpenAI Whisperで音声認識＋ChatGPTでAIチャット応答＋FAQ＋履歴保存

import gradio as gr
import json
import os
import openai
from dotenv import load_dotenv

# --- 設定 ---
HISTORY_FILE = "history.json"

# --- APIキーの読み込み ---
load_dotenv()
openai.api_key = os.getenv("OPENAI_API_KEY")

# --- FAQ例 ---
faq_examples = [
    "このサービスの使い方を教えて",
    "音声認識がうまくいかない場合は？",
    "料金体系を教えてください"
]

# --- 履歴の保存・読み込み ---
def save_history(history):
    with open(HISTORY_FILE, "w", encoding="utf-8") as f:
        json.dump(history, f, ensure_ascii=False)

def load_history():
    try:
        with open(HISTORY_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        return []

# --- 入力バリデーション ---
def validate_input(msg):
    if not msg or len(msg) < 3:
        return gr.update(value="", placeholder="3文字以上入力してください")
    return msg

# --- ChatGPTによるAIチャット応答 ---
def ai_respond(history, message):
    history = history or []
    if message:
        history.append({"role": "user", "content": message})
        # OpenAI Chat API呼び出し
        try:
            response = openai.ChatCompletion.create(
                model="gpt-3.5-turbo", # 必要に応じてgpt-4等に変更
                messages=history,
                max_tokens=512,
                temperature=0.7
            )
            ai_reply = response.choices[0].message["content"].strip()
        except Exception as e:
            ai_reply = f"エラー: {e}"
        history.append({"role": "assistant", "content": ai_reply})
        save_history(history)
    return history, ""

# --- Whisper APIで音声認識 ---
def transcribe_with_whisper(audio_path):
    if audio_path is None:
        return ""
    try:
        with open(audio_path, "rb") as audio_file:
            transcript = openai.Audio.transcribe(
                "whisper-1",
                audio_file,
                language="ja"
            )
        return transcript["text"]
    except Exception as e:
        return f"音声認識エラー: {e}"

# --- Gradio UI ---
with gr.Blocks(
    theme=gr.themes.Soft(primary_hue="#0D1B2A"),
    title="LogicBridge",
    description="LogicBridge - コードと実行の橋渡しAIチャットボット。OpenAI Whisperで音声認識、ChatGPTでAI応答。"
) as demo:
    # ロゴ画像（logo.pngをルートに置いてください）
    gr.Image("logo.png", elem_id="logo", show_label=False)
    # FAQテンプレート
    faq_dropdown = gr.Dropdown(choices=faq_examples, label="FAQテンプレ", interactive=True)
    # 入力欄
    msg = gr.Textbox(label="メッセージを入力", placeholder="ここに入力...", scale=7, examples=faq_examples)
    send_btn = gr.Button("送信", variant="primary")
    clear_btn = gr.Button("クリア", variant="secondary")
    state = gr.State(load_history())
    # チャットボット表示
    chatbot = gr.Chatbot(
        height=600,
        label="LogicBridge",
        show_copy_button=True,
        type="messages"
    )
    # FAQ選択でテキストボックスに挿入
    faq_dropdown.change(lambda x: x, inputs=faq_dropdown, outputs=msg)
    # 入力バリデーション
    send_btn.click(validate_input, inputs=msg, outputs=msg)
    # チャット送信（AI応答）
    send_btn.click(
        ai_respond,
        inputs=[state, msg],
        outputs=[chatbot, msg]
    )
    # クリアボタン
    def clear_all():
        if os.path.exists(HISTORY_FILE):
            os.remove(HISTORY_FILE)
        return [], ""
    clear_btn.click(clear_all, inputs=[], outputs=[chatbot, msg])
    # Whisper音声認識
    audio_input = gr.Audio(source="microphone", type="filepath", label="音声入力")
    audio_input.change(transcribe_with_whisper, inputs=audio_input, outputs=msg)

demo.launch()

```


## tools\chronicle_visualizer.py

```python
# ==============================================================================
# フォルダ: tools/
# ファイル名: chronicle_visualizer.py
# 目的: project_chronicle.jsonl を可視化（進化マップ / ヒートマップ / LLMモデル利用推移）
# 実行例:
#   python tools/chronicle_visualizer.py .  # デフォルト: project_chronicle.jsonl を読み込む
# ==============================================================================
from __future__ import annotations
import json
from collections import defaultdict, Counter
from datetime import datetime
from pathlib import Path
import argparse

import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates

def load_chronicle(chronicle: Path):
    rows = []
    with open(chronicle, "r", encoding="utf-8") as f:
        for line in f:
            try:
                r = json.loads(line)
                rows.append(r)
            except Exception:
                continue
    return rows

def normalize_event_type(row: dict) -> str:
    # 後方互換: event_type が無い場合は event を簡易マッピング
    et = row.get("event_type")
    if et:
        return et
    ev = (row.get("event") or "").lower()
    if "genesis" in ev: return "genesis"
    if "snapshot" in ev: return "snapshot"
    if "export" in ev: return "export_generated"
    if "file_change" in ev: return "file_modified"  # 厳密には不明だが視覚上の便宜
    return "unknown"

def to_dt(ts: str):
    try:
        # 2025-08-09T02:34:56+00:00
        return datetime.fromisoformat(ts.replace("Z", "+00:00"))
    except Exception:
        return None

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("project_root")
    ap.add_argument("--chronicle", default="project_chronicle.jsonl")
    args = ap.parse_args()
    project_root = Path(args.project_root).absolute()
    chronicle = project_root / args.chronicle
    rows = load_chronicle(chronicle)

    # ---- 進化マップ（フォルダ×時系列） ----
    folder_events = defaultdict(list)
    for r in rows:
        dt = to_dt(r.get("timestamp", ""))
        if not dt: continue
        et = normalize_event_type(r)
        files = r.get("files_changed") or []
        if not files:
            # スナップショット系はフォルダ粒度の情報がない場合があるのでスキップ
            continue
        top_folders = {p.split("/", 1)[0] if "/" in p else p for p in files}
        for tf in top_folders:
            folder_events[tf].append((dt, et))

    plt.figure(figsize=(12, 6))
    color_map = {
        "file_created": "tab:green",
        "file_modified": "tab:blue",
        "file_deleted": "tab:red",
        "export_generated": "tab:orange",
        "diff_summary": "tab:purple",
        "snapshot": "tab:gray",
        "genesis": "tab:gray",
        "unknown": "tab:brown"
    }
    for idx, (folder, evs) in enumerate(sorted(folder_events.items())):
        evs = sorted(evs, key=lambda x: x[0])
        dates = [e[0] for e in evs]
        types = [e[1] for e in evs]
        plt.scatter(dates, [idx]*len(dates),
                    c=[color_map.get(t, "tab:brown") for t in types], alpha=0.8, edgecolors="k", linewidths=0.3)
    plt.gca().xaxis.set_major_locator(mdates.MonthLocator())
    plt.gca().xaxis.set_major_formatter(mdates.DateFormatter("%Y-%m"))
    plt.yticks(range(len(folder_events)), [k for k,_ in sorted(folder_events.items())])
    plt.title("フォルダ進化マップ")
    plt.grid(axis="x", linestyle="--", alpha=0.4)
    plt.tight_layout()
    plt.show()

    # ---- フォルダ別活動ヒートマップ（月次件数） ----
    from collections import Counter
    folder_month = defaultdict(Counter)
    for r in rows:
        dt = to_dt(r.get("timestamp", ""))
        if not dt: continue
        files = r.get("files_changed") or []
        month = dt.strftime("%Y-%m")
        for p in files:
            top = p.split("/", 1)[0] if "/" in p else p
            folder_month[top][month] += 1
    if folder_month:
        df = pd.DataFrame(folder_month).T.fillna(0).astype(int)
        plt.figure(figsize=(12, max(4, 0.3*len(df))))
        plt.imshow(df, aspect="auto")
        plt.title("フォルダ別活動ヒートマップ（イベント数/月）")
        plt.yticks(range(len(df.index)), df.index)
        plt.xticks(range(len(df.columns)), df.columns, rotation=90)
        plt.colorbar(label="件数")
        plt.tight_layout()
        plt.show()

if __name__ == "__main__":
    main()

```


## tools\streamlit_dashboard.py

```python
# ==============================================================================
# フォルダ: tools/
# ファイル名: streamlit_dashboard.py
# メモ: 【エンジン・コックピット分離版】
#      - あなたが作成した `dashboard.py` をデータ処理の「エンジン」としてインポート。
#      - このファイルは、そのエンジンから受け取ったデータを表示することに特化した
#        「コックピTピット」の役割を担う。
#      - これにより、ロジックとUIが完全に分離され、保守性が劇的に向上する。
#
# 使い方:
# 1. ターミナルでプロジェクトルートに移動する。
#    cd C:\Users\USER\tools\NexusCore
# 2. 以下のコマンドを実行する。
#    streamlit run tools/streamlit_dashboard.py
# ==============================================================================
import streamlit as st
import pandas as pd
import plotly.express as px
import json
from pathlib import Path

# --- あなたが作成したエンジン（dashboard.py）をインポート ---
try:
    # toolsフォルダをPythonの検索パスに追加
    import sys
    tools_path = str(Path(__file__).parent.absolute())
    if tools_path not in sys.path:
        sys.path.insert(0, tools_path)
    
    from dashboard import ProjectDashboard
except ImportError as e:
    st.error(f"エラー: `dashboard.py` のインポートに失敗しました。同じフォルダに存在することを確認してください。: {e}")
    st.stop()

# --- 定数 ---
# このスクリプトから見たプロジェクトルートのパス
PROJECT_ROOT_PATH = str(Path(__file__).parent.parent.absolute())

def main_dashboard():
    """
    StreamlitのUIを構築するメイン関数
    """
    st.set_page_config(page_title="NexusCore Evolution Cockpit", layout="wide")
    st.title("🚀 NexusCore Evolution Cockpit")
    st.caption("プロジェクトの進化の軌跡を可視化・分析します。")

    # --- エンジンを初期化し、データをロード ---
    engine = ProjectDashboard(PROJECT_ROOT_PATH)
    project_data = engine.load_project_data()

    if not project_data or not project_data.get("total_records"):
        st.warning("年代記ファイルに分析可能なデータがありません。")
        st.info("先に `tools/genesis_analyzer.py` を実行してデータを生成してください。")
        st.stop()

    # --- KPIメトリクスの表示 ---
    st.header("最新の状態 (KPIs)")
    col1, col2, col3 = st.columns(3)
    last_updated = project_data.get('last_updated', 'N/A')
    if last_updated != 'N/A':
        last_updated = engine.format_timestamp(last_updated)
    
    col1.metric("最終更新日時", last_updated.replace(" UTC", ""))
    col2.metric("総レコード数", project_data.get('total_records', 0))
    col3.metric("スナップショット数", len(project_data.get('snapshots', [])))

    # --- データフレームの作成 ---
    # ここでは可視化のために簡易的なデータフレームを作成
    snapshot_df = pd.DataFrame(project_data.get('snapshots', []))
    if not snapshot_df.empty:
        snapshot_df['timestamp_dt'] = pd.to_datetime(snapshot_df['timestamp'])
        
        # 仮のメトリクス（将来的に構造化データに置き換える）
        snapshot_df['agent_count'] = snapshot_df['data'].apply(
            lambda d: len(d.get('integrated_summary', {}).get('architecture_and_agents', '').split('*')) - 1
        )

        # --- メインチャートの表示 ---
        st.header("進化の軌跡")
        fig = px.line(snapshot_df, x='timestamp_dt', y=['agent_count'],
                      title='エージェント数の推移（仮）', markers=True,
                      labels={'timestamp_dt': '日時', 'value': 'エージェント数', 'variable': '指標'})
        st.plotly_chart(fig, use_container_width=True)

    # --- Genesis Block の詳細表示 ---
    st.header("🌟 Genesis Block Summary")
    genesis_record = project_data.get('genesis')
    if genesis_record:
        summary = genesis_record.get('data', {}).get('integrated_summary', {})
        with st.expander("プロジェクトの創世記（サマリー）を表示"):
            st.json(summary)
    else:
        st.info("Genesis Blockが見つかりません。")

if __name__ == "__main__":
    main_dashboard()

```


## tools\loosen_requirements.py

```python
#!/usr/bin/env python
"""
loosen_requirements.py
  requirements.txt 内の「パッケージ==x.y.z」表記を
  「パッケージ>=x.y.z,<next_major」へ自動変換するツール
使い方:
  python loosen_requirements.py requirements.txt > requirements_soft.txt
"""

import re
import sys
import subprocess
from pathlib import Path
from typing import List

# -- packaging.version が無ければ自動インストール ------------------------
try:
    from packaging.version import Version
except ImportError:  # pragma: no cover
    subprocess.check_call([sys.executable, "-m", "pip", "install", "packaging>=23"])
    from packaging.version import Version  # type: ignore
# ---------------------------------------------------------------------------


def loosen_line(line: str) -> str:
    line = line.strip()
    # 空行・コメント行はそのまま返す
    if not line or line.startswith("#"):
        return line

    # 既に >= / < などが入っている行はそのまま
    if ">" in line or "<" in line:
        return line

    # "pkg==1.2.3" を分解
    if "==" not in line:
        return line
    pkg, ver_str = line.split("==", 1)

    # バージョンが PEP440 互換でない場合は触らない
    try:
        ver = Version(ver_str)
    except Exception:
        return line

    # 次のメジャーバージョンを計算
    next_major = ver.major + 1
    upper_bound = f"<{next_major}"

    # 結果を返す
    return f"{pkg}>={ver},<{next_major}"


def main(args: List[str]) -> None:
    if not args:
        print("Usage: python loosen_requirements.py requirements.txt > requirements_soft.txt", file=sys.stderr)
        sys.exit(1)

    in_path = Path(args[0])
    if not in_path.exists():
        print(f"File not found: {in_path}", file=sys.stderr)
        sys.exit(1)

    for line in in_path.read_text(encoding="utf-8").splitlines():
        print(loosen_line(line))


if __name__ == "__main__":
    main(sys.argv[1:])

```


## tools\weather_gpt.py

```python
from openai import OpenAI
import requests, os, json, sys

API_KEY = os.getenv("OPENAI_API_KEY")
if not API_KEY:
    sys.exit("OPENAI_API_KEY が設定されていません")

client = OpenAI(api_key=API_KEY)

# ----------------------------------------------------------
# 外部関数：Open-Meteo で現在気温を取得
# ----------------------------------------------------------
def get_weather(city="Kyoto"):
    lat, lon = 35.0116, 135.7680  # Kyoto
    url = (
        "https://api.open-meteo.com/v1/forecast"
        f"?latitude={lat}&longitude={lon}&current=temperature_2m,weathercode"
    )
    data = requests.get(url, timeout=10).json()["current"]
    return {"city": city, "temperature": data["temperature_2m"]}

# OpenAI に渡す関数仕様
tools = [{
    "type": "function",
    "name": "get_weather",
    "description": "指定都市の現在の天気・気温を取得",
    "parameters": {
        "type": "object",
        "properties": {
            "city": {"type": "string", "description": "都市名。例: Kyoto"}
        },
        "required": ["city"],
        "additionalProperties": False
    }
}]

messages = [{"role": "user", "content": "京都の今の天気は？"}]

# ----------------- 1st 呼び出し（関数を提案させる） -----------------
resp1 = client.chat.completions.create(
    model="gpt-4o",
    messages=messages,
    tools=tools
)
msg1 = resp1.choices[0].message

if msg1.tool_call:  # モデルが関数を呼びたいと提案
    args = json.loads(msg1.tool_call.arguments)
    result = get_weather(**args)

    messages += [
        msg1,  # function_call メッセージ
        {
            "role": "tool",
            "tool_call_id": msg1.tool_call.call_id,
            "content": json.dumps(result, ensure_ascii=False),
        },
    ]

    # -------------- 2nd 呼び出し（結果を踏まえて回答） --------------
    resp2 = client.chat.completions.create(
        model="gpt-4o",
        messages=messages
    )
    print(resp2.choices[0].message.content)
else:
    print("Function was not called")

```


## tools\balance_watch.py

```python
import os, json
from pathlib import Path
from datetime import datetime
import requests

USAGE_DIR = Path(os.getenv("NEXUS_USAGE_DIR","./data/usage"))
SLACK_WEBHOOK = os.getenv("SLACK_WEBHOOK_URL","")
DEEPSEEK_PREPAID = float(os.getenv("DEEPSEEK_PREPAID_USD","0") or 0)
DEEPSEEK_ALERT = float(os.getenv("DEEPSEEK_ALERT_USD","5") or 5)
MOONSHOT_BUDGET = float(os.getenv("MOONSHOT_BUDGET_USD","0") or 0)
MOONSHOT_ALERT_RATIO = float(os.getenv("MOONSHOT_ALERT_RATIO","0.8") or 0.8)

def load_this_month():
    ym = datetime.utcnow().strftime("%Y%m")
    fp = USAGE_DIR / f"usage_{ym}.jsonl"
    rows=[]
    if fp.exists():
        for line in fp.read_text(encoding="utf-8").splitlines():
            try: rows.append(json.loads(line))
            except: pass
    return rows

def aggregate(rows):
    total = 0.0; per = {}
    for r in rows:
        amt = float(r.get("total_usd") or 0)
        prov = r.get("provider","unknown")
        total += amt
        per[prov] = per.get(prov,0.0) + amt
    return total, per

def usd(v): return f"${v:,.2f}"

def slack(msg):
    if not SLACK_WEBHOOK: 
        print("[DRYRUN]\n"+msg); return
    try:
        requests.post(SLACK_WEBHOOK, json={"text": msg}, timeout=10)
    except Exception as e:
        print("Slack post failed:", e)

def main():
    rows = load_this_month()
    total, byp = aggregate(rows)
    lines = [f":bar_chart: This month total {usd(total)}",
             "・by provider: " + ", ".join(f"{k} {usd(v)}" for k,v in byp.items())]

    if DEEPSEEK_PREPAID > 0:
        used = byp.get("deepseek", 0.0)
        left = max(DEEPSEEK_PREPAID - used, 0.0)
        lines.append(f"DeepSeek: used {usd(used)} / prepaid {usd(DEEPSEEK_PREPAID)} -> left {usd(left)}")
        if left <= DEEPSEEK_ALERT:
            slack(f":warning: DeepSeek 残高が閾値を下回りました。残り {usd(left)}")

    if MOONSHOT_BUDGET > 0:
        used = byp.get("moonshot", 0.0)
        ratio = used / MOONSHOT_BUDGET if MOONSHOT_BUDGET else 0
        lines.append(f"Moonshot: used {usd(used)} / budget {usd(MOONSHOT_BUDGET)} ({ratio*100:.1f}%)")
        if ratio >= MOONSHOT_ALERT_RATIO:
            slack(f":warning: Moonshot 月次使用が {ratio*100:.1f}%（{usd(used)} / {usd(MOONSHOT_BUDGET)}）")

    msg = "\n".join(lines)
    slack(msg); print(msg)

if __name__ == "__main__":
    main()

```


## tools\scribe.py

```python
# ==============================================================================
# フォルダ: tools/
# ファイル名: scribe.py
# メモ: 手動での開発活動をプロジェクト・クロニクルに記録するためのツール。
#      "git commit"のように、開発の意図を一行で記録する。
#      Watcher Agentからインポートして利用できるように改良。
#
# 使い方 (手動実行):
# python tools/scribe.py "DebuggerAgentのリファクタリングとKnowledgeManagerの導入作業"
# ==============================================================================
import os
import json
import sys
from datetime import datetime, timezone
import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def log_manual_event(project_path: str, summary: str):
    """
    手動での開発イベントをプロジェクト・クロニクルに追記する。
    """
    if not summary:
        logging.error("記録する内容が指定されていません。")
        return

    chronicle_path = os.path.join(project_path, "project_chronicle.jsonl")
    
    log_entry = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "event": "MANUAL_DEV_LOG",
        "agent": "HumanDeveloper",
        "data": {
            "summary": summary
        }
    }

    try:
        # "a" (append)モードでファイルを開き、追記する
        with open(chronicle_path, "a", encoding="utf-8") as f:
            f.write(json.dumps(log_entry, ensure_ascii=False) + "\n")
        logging.info(f"✅ 開発活動をクロニクルに記録しました: {summary}")
    except FileNotFoundError:
        logging.error(f"エラー: クロニクルファイルが見つかりません: {chronicle_path}")
        logging.error("先に 'genesis_analyzer.py' を実行して、最初の記憶を生成してください。")
    except Exception as e:
        logging.error(f"クロニクルへの書き込み中にエラーが発生しました: {e}")

# このファイルが直接実行された時のみ、コマンドライン引数を処理する
if __name__ == "__main__":
    # コマンドライン引数から記録内容を取得
    if len(sys.argv) < 2:
        print("Usage: python tools/scribe.py \"<記録したい開発内容の要約>\"")
        sys.exit(1)
    
    # プロジェクトのルートパスをスクリプトからの相対パスで解決
    # このスクリプトが tools/ にあることを想定
    current_dir = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.dirname(current_dir)
    
    log_summary = sys.argv[1]
    log_manual_event(project_root, log_summary)

```


## tools\cost_dashboard.py

```python
# ==============================================================================
# ファイル: tools/cost_dashboard.py
# 目的  : 1K in + 2K out の単価テーブルをもとに、件数/日→月額を即時計算。
# 実行  : streamlit run tools/cost_dashboard.py
# 依存  : pip install streamlit pandas
# 備考  : 実運用では COST_TABLE を .env or JSON 読み込みに変更推奨。
# ==============================================================================

import os
import json
import pandas as pd
import streamlit as st

DEFAULT_COST = {
    "gpt-4o":               {"in": 2.50,  "out": 10.00},
    "gemini-1.5-flash-latest": {"in": 0.0375, "out": 0.15},
    "claude-3.5-sonnet":    {"in": 3.00,  "out": 15.00},
    "claude-3.5-haiku":     {"in": 0.80,  "out": 1.00},
    "deepseek-reasoner":    {"in": 0.55,  "out": 2.19},
    "command-r-plus-08-2024":{"in": 2.50,  "out": 10.00},
    "kimi-k2":              {"in": 0.15,  "out": 2.50},
}

st.set_page_config(page_title="NexusCore LLM Cost Dashboard", layout="wide")

st.title("📊 NexusCore LLM コスト見積ダッシュボード")
st.caption("※ 価格は参考値。必ず最新の公式価格で上書きしてください。")

# コストテーブルの読み込み（任意 JSON パス）
json_path = st.text_input("コスト表JSONパス（任意）", value="")
cost_table = DEFAULT_COST.copy()
if json_path and os.path.exists(json_path):
    with open(json_path, "r", encoding="utf-8") as f:
        cost_table = json.load(f)

in_tok = st.number_input("1件あたり入力トークン", min_value=0, value=1000, step=100)
out_tok = st.number_input("1件あたり出力トークン", min_value=0, value=2000, step=100)
tasks_per_month = st.number_input("月間タスク件数", min_value=0, value=1000, step=100)
jpy_rate = st.number_input("USD→JPY 換算レート", min_value=1.0, value=155.0, step=0.5)

rows = []
for name, p in cost_table.items():
    usd = (p["in"] * (in_tok/1_000_000)) + (p["out"] * (out_tok/1_000_000))
    monthly_usd = usd * tasks_per_month
    rows.append({
        "モデル": name,
        "1件USD": round(usd, 6),
        "月額USD": round(monthly_usd, 2),
        "月額JPY(参考)": round(monthly_usd * jpy_rate),
        "備考": ""
    })

df = pd.DataFrame(rows).sort_values("月額USD")
st.dataframe(df, use_container_width=True)

st.bar_chart(df.set_index("モデル")["月額USD"])

```


## project_structure_and_code_export.py

```python
# ファイル名: project_structure_and_code_export.py
# 目的: プロジェクトの構造と主要なコードを分析し、基本的なエクスポートを行うためのコアツール。
# 修正内容:
# - LLMが誤解しないよう、PROJECT_INFO.mdの生成ロジックを改善。
# - 「解析対象の概要」と「このパッケージの作成方法」を明確に分離。
# - 元々のシンプルな分析ロジックは維持。

import os
import json
import zipfile
import fnmatch
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Tuple, Set, Any

# ===== チューニング設定 =====
MAX_FILE_SIZE_MB = 1
MAX_DEPTH = 10  # 階層の深さ制限を少し緩和
FILE_TYPES = ('.py', '.md', '.txt', 'package.json', '.json', '.yml', '.yaml', '.toml')
GITIGNORE_PATH = ".gitignore"

# ===== 除外対象（固定値） =====
DEFAULT_IGNORED_DIRS = {
    '.git', '.venv', '__pycache__', 'node_modules',
    'output', 'dist', 'build', 'sandbox_output', 'deploy_output',
    'myenv', 'openenv', 'exports', 'htmlcov', 'test_cache'
}
DEFAULT_IGNORED_FILES = {
    '.env', 'secrets.json', 'config.local.json', '.DS_Store', '*.log'
}

# ===== ユーティリティ関数 =====
def get_depth(path: str, base: str) -> int:
    return len(os.path.relpath(path, base).split(os.sep))

def load_gitignore(path: str = GITIGNORE_PATH) -> Tuple[Set[str], Set[str]]:
    ignored_dirs, ignored_files = set(), set()
    if not os.path.exists(path):
        return ignored_dirs, ignored_files
    with open(path, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if line.endswith('/'):
                ignored_dirs.add(line.rstrip('/'))
            else:
                ignored_files.add(line)
    return ignored_dirs, ignored_files

def is_ignored(path: str, base_path: str, ignored_dirs: Set[str], ignored_files: Set[str]) -> bool:
    rel_path = os.path.relpath(path, base_path)
    parts = rel_path.split(os.sep)
    # ディレクトリのチェック
    for i in range(len(parts)):
        sub_path = os.path.join(*parts[:i+1])
        if sub_path in ignored_dirs:
            return True
    # ファイルのチェック
    for pattern in ignored_files:
        if fnmatch.fnmatch(parts[-1], pattern):
            return True
    return False

def create_folder_structure_json(
    directory: str,
    base_path: str,
    ignored_dirs: Set[str],
    ignored_files: Set[str]
) -> Dict[str, Any]:
    name = os.path.basename(directory)
    if is_ignored(directory, base_path, ignored_dirs, set()):
        return None
    
    structure = {"name": name, "type": "folder", "children": []}
    if get_depth(directory, base_path) > MAX_DEPTH:
        return structure

    try:
        for item in sorted(os.listdir(directory)):
            item_path = os.path.join(directory, item)
            if is_ignored(item_path, base_path, ignored_dirs, ignored_files):
                continue

            if os.path.isdir(item_path):
                child_structure = create_folder_structure_json(item_path, base_path, ignored_dirs, ignored_files)
                if child_structure:
                    structure["children"].append(child_structure)
            else:
                structure["children"].append({"name": item, "type": "file"})
    except OSError:
        pass
    return structure

def create_folder_structure_md(
    directory: str,
    prefix: str,
    base_path: str,
    ignored_dirs: Set[str],
    ignored_files: Set[str]
) -> List[str]:
    lines = []
    if get_depth(directory, base_path) > MAX_DEPTH:
        return lines
        
    items = sorted(os.listdir(directory))
    for i, item in enumerate(items):
        item_path = os.path.join(directory, item)
        if is_ignored(item_path, base_path, ignored_dirs, ignored_files):
            continue

        is_last = i == (len(items) - 1)
        lines.append(prefix + ("└── " if is_last else "├── ") + item)
        
        if os.path.isdir(item_path):
            new_prefix = prefix + ("    " if is_last else "│   ")
            lines.extend(create_folder_structure_md(item_path, new_prefix, base_path, ignored_dirs, ignored_files))
    return lines

def combine_files(
    directory: str,
    ignored_dirs: Set[str],
    ignored_files: Set[str]
) -> str:
    combined_content = ""
    max_size = MAX_FILE_SIZE_MB * 1024 * 1024
    for root, dirs, files in os.walk(directory):
        dirs[:] = [d for d in dirs if d not in ignored_dirs and not is_ignored(os.path.join(root, d), directory, ignored_dirs, set())]
        for file in files:
            file_path = os.path.join(root, file)
            if file.endswith(FILE_TYPES) and not is_ignored(file_path, directory, ignored_dirs, ignored_files):
                try:
                    if os.path.getsize(file_path) > max_size:
                        continue
                    with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                        content = f.read()
                    relative_path = os.path.relpath(file_path, directory)
                    combined_content += f"# === {relative_path.replace(os.sep, '/')} ===\n"
                    combined_content += content + "\n\n"
                except Exception:
                    pass
    return combined_content

# --- 新しいPROJECT_INFO生成関数 ---
def generate_project_info_content(project_path: str, ignored_dirs: Set[str], ignored_files: Set[str]) -> str:
    """
    プロジェクトの統計情報を収集し、LLM向けのレポートを生成する。
    """
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    total_files, total_lines, stats = 0, 0, {}

    for root, dirs, files in os.walk(project_path):
        dirs[:] = [d for d in dirs if d not in ignored_dirs]
        for file in files:
            if is_ignored(os.path.join(root, file), project_path, ignored_dirs, ignored_files):
                continue
            
            total_files += 1
            ext = os.path.splitext(file)[1] or "No Ext"
            stats.setdefault(ext, {"files": 0, "lines": 0})
            stats[ext]["files"] += 1
            try:
                with open(os.path.join(root, file), "r", encoding="utf-8", errors="ignore") as f:
                    lines = len(f.readlines())
                    stats[ext]["lines"] += lines
                    total_lines += lines
            except Exception:
                pass

    # --- セクション1: 解析対象プロジェクトの概要 ---
    project_summary = f"""# 📦 NexusCore プロジェクト解析パッケージ

## 1. 解析対象プロジェクトの概要 (`{os.path.basename(project_path)}`)

このパッケージは、「自己進化するAI開発エコシステム」である **NexusCore** プロジェクトの核心部分を抽出したものです。

- **プロジェクトの目的:** 専門的な役割を持つAIエージェント群が協調し、失敗から学び、その教訓を組織全体の知識として蓄積・進化させていく自己進化する開発エコシステム。
- **総ファイル数:** {total_files}
- **総コード行数:** {total_lines:,}行
- **エクスポート日時:** {timestamp}
"""

    # --- ファイル統計テーブルの生成 ---
    stats_table = "| 拡張子 | ファイル数 | コード行数 |\n|---|---|---|\n"
    sorted_stats = sorted(stats.items(), key=lambda item: item[1]['files'], reverse=True)
    for ext, data in sorted_stats:
        stats_table += f"| `{ext}` | {data['files']:,} | {data['lines']:,} |\n"
    stats_table += f"| **合計** | **{total_files:,}** | **{total_lines:,}** |\n"
    
    # --- セクション2: この解析パッケージの作成方法 ---
    package_info = f"""
---

## 2. この解析パッケージの作成方法について

このパッケージは、`project_structure_and_code_export.py` ツールによって生成されました。
このツールは、`.gitignore` と事前定義されたルールに基づき、プロジェクト内の関連ファイルを抽出し、単一のコードファイルに結合します。
"""

    return f"{project_summary}\n## 📊 ファイル統計\n{stats_table}{package_info}"


def main():
    PROJECT_PATH = "."
    OUTPUT_DIR = "exports"
    if not os.path.exists(OUTPUT_DIR):
        os.makedirs(OUTPUT_DIR)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    project_name = os.path.basename(os.getcwd())

    STRUCTURE_JSON = os.path.join(OUTPUT_DIR, f"{project_name}_structure_{timestamp}.json")
    STRUCTURE_MD = os.path.join(OUTPUT_DIR, f"{project_name}_structure_{timestamp}.md")
    COMBINED_CODE = os.path.join(OUTPUT_DIR, f"{project_name}_combined_code_{timestamp}.py")
    PROJECT_INFO = os.path.join(OUTPUT_DIR, f"{project_name}_PROJECT_INFO_{timestamp}.md")
    ARCHIVE_ZIP = os.path.join(OUTPUT_DIR, f"{project_name}_bundle_{timestamp}.zip")

    print("🚀 .gitignoreを読み込み中...")
    gitignore_dirs, gitignore_files = load_gitignore()
    IGNORED_DIRS = DEFAULT_IGNORED_DIRS.union(gitignore_dirs)
    IGNORED_FILES = DEFAULT_IGNORED_FILES.union(gitignore_files)

    print("📁 ディレクトリ構造の解析を開始します...")
    structure = create_folder_structure_json(PROJECT_PATH, 
```


## tools\create_init_files.py

```python
# C:\Users\USER\tools\OpenCodeInterpreter\create_init_files.py

import os

# Pythonパッケージとして扱うべきディレクトリのリスト
# 今後、新しいモジュールフォルダを追加した場合は、このリストに追加してください。
PACKAGE_DIRS = [
    "src",
    "src/core",
    "agents",
    "utils"
]

def initialize_project_structure():
    """
    プロジェクト内の指定されたディレクトリに__init__.pyファイルを作成し、
    Pythonパッケージとして認識できるようにします。
    """
    project_root = os.path.dirname(os.path.abspath(__file__))
    print(f"プロジェクトルート: {project_root}")
    print("プロジェクトのパッケージ構造を初期化します...")
    print("-" * 30)

    for dir_path in PACKAGE_DIRS:
        full_path = os.path.join(project_root, dir_path)
        init_file = os.path.join(full_path, "__init__.py")

        # ディレクトリが存在するかチェック
        if not os.path.isdir(full_path):
            print(f"⚠️  警告: ディレクトリ '{dir_path}' が見つかりません。スキップします。")
            continue

        # __init__.pyファイルが存在しない場合に作成
        if not os.path.exists(init_file):
            print(f"✅  '{init_file}' を作成しました。")
            with open(init_file, "w") as f:
                # このファイルは空で問題ありません。
                # パッケージであることを示すマーカーとして機能します。
                pass
        else:
            print(f"ℹ️   '{init_file}' は既に存在します。")

    print("-" * 30)
    print("\n初期化が完了しました。")
    print("再度 `python main_cli.py execute ...` を実行してみてください。")


if __name__ == "__main__":
    initialize_project_structure()

```


## fix_imports.py

```python
# ==============================================================================
# ファイル名: fix_imports.py
# メモ: NexusCore インポートパス修正・プロジェクト構造検証ツール
#
# 機能:
# 1. プロジェクト内のPythonファイルのインポートパスを絶対パスに修正
# 2. 不足している __init__.py ファイルを自動生成
# 3. プロジェクトの基本構造を検証
#
# 使い方:
# プロジェクトのルートディレクトリで以下のコマンドを実行
# python fix_imports.py
#
# 特定のディレクトリを対象にする場合:
# python fix_imports.py --directory src
#
# 変更を実際に行わずに、修正対象のファイルを確認する場合 (Dry Run):
# python fix_imports.py --dry-run
# ==============================================================================

import os
import re
import argparse
from pathlib import Path

def fix_import_paths(root_dir: str, dry_run: bool = False):
    """
    指定されたディレクトリ内のPythonファイルのインポートパスを修正します。

    Args:
        root_dir (str): 修正対象のルートディレクトリ。
        dry_run (bool): Trueの場合、ファイルの変更は行わず、修正対象を表示するだけ。
    """
    print(f"🔍 '{root_dir}' ディレクトリのインポートパスをスキャン中...")
    if dry_run:
        print("⚠️ ドライランモード: ファイルの変更は行われません。")

    # 単語境界(\b)を追加し、より正確なマッチングを行うように正規表現を改善
    # これにより、'my_agents' のような類似名を持つ無関係なモジュールへの誤マッチを防ぎます。
    patterns = [
        (r'from \bagents\b', 'from nexuscore.agents'),
        (r'from \bcore\b', 'from nexuscore.core'),
        (r'from \butils\b', 'from nexuscore.utils'),
        (r'from \bmodules\b', 'from nexuscore.modules'),
        (r'from \bapi\b', 'from nexuscore.api'),
        (r'from \baudio\b', 'from nexuscore.audio'),
        (r'from \bcode_interpreter\b', 'from nexuscore.code_interpreter'),
        (r'from \bgradio_app\b', 'from nexuscore.gradio_app'),
        # 相対インポートの修正 (例: from .agents -> from nexuscore.agents)
        (r'from \.(agents|core|utils|modules|api|audio|code_interpreter|gradio_app)', r'from nexuscore.\1')
    ]

    fixed_count = 0
    changed_files = []
    root_path = Path(root_dir)

    if not root_path.is_dir():
        print(f"❌ エラー: ディレクトリ '{root_dir}' が見つかりません。")
        print(f"現在の作業ディレクトリ: {Path.cwd()}")
        return

    for py_file in root_path.rglob("*.py"):
        try:
            content = py_file.read_text(encoding='utf-8', errors='ignore')
            original_content = content
            
            for old_pattern, new_pattern in patterns:
                content = re.sub(old_pattern, new_pattern, content)

            if content != original_content:
                changed_files.append(py_file)
                if not dry_run:
                    py_file.write_text(content, encoding='utf-8')
                fixed_count += 1
                
        except Exception as e:
            print(f"❌ '{py_file}' の処理中にエラーが発生しました: {e}")

    if changed_files:
        print("\n--- 修正対象ファイル ---")
        current_dir = Path.cwd()
        for f in changed_files:
            # ★★★ エラー修正: 安全な相対パス計算 ★★★
            # relative_to() が失敗するエッジケース (例: ドライブが異なる) を考慮し、
            # 例外処理を追加して堅牢性を高める。
            try:
                display_path = f.relative_to(current_dir)
            except ValueError:
                # パス計算に失敗した場合は、ファイルパスをそのまま表示する
                display_path = f
            print(f"  - {display_path}")
        print("--------------------")

    if dry_run:
        print(f"\n✅ スキャン完了: {fixed_count} 個のファイルが修正対象です。")
    else:
        print(f"\n✅ 修正完了: {fixed_count} 個のファイルのインポートパスを修正しました。")


def create_missing_init_files(dry_run: bool = False):
    """
    プロジェクト内の重要なディレクトリに不足している__init__.pyファイルを作成します。
    """
    print("\n🔍 __init__.py ファイルをチェック中...")
    if dry_run:
        print("⚠️ ドライランモード: ファイルの作成は行われません。")

    # プロジェクトのパッケージとして認識させるべき重要なディレクトリ
    important_dirs = [
        "src/nexuscore",
        "src/nexuscore/agents",
        "src/nexuscore/core",
        "src/nexuscore/utils",
        "src/nexuscore/modules",
        "src/nexuscore/api",
        "src/nexuscore/audio",
        "src/nexuscore/code_interpreter",
        "src/nexuscore/gradio_app",
        "tests",
        "tests/unit",
        "tests/integration",
    ]
    
    # srcディレクトリ自体もパッケージルートとしてマーク
    if Path("src").is_dir():
        important_dirs.insert(0, "src")

    created_count = 0
    for dir_path_str in important_dirs:
        dir_path = Path(dir_path_str)
        if not dir_path.is_dir():
            continue

        init_file = dir_path / "__init__.py"
        if not init_file.exists():
            print(f"📄 作成対象: {init_file}")
            if not dry_run:
                init_file.write_text("# This file makes this a Python package\n", encoding='utf-8')
            created_count += 1
        else:
            # 既存のファイルはスキップ
            pass
            
    if created_count > 0:
        if dry_run:
            print(f"\n✅ チェック完了: {created_count} 個の __init__.py ファイルが作成対象です。")
        else:
            print(f"\n✅ 作成完了: {created_count} 個の __init__.py ファイルを新規作成しました。")
    else:
        print("✅ すべての重要ディレクトリに __init__.py は存在します。")


def verify_structure():
    """
    プロジェクトの基本的なファイル構造が期待通りかを確認します。
    """
    print("\n📊 プロジェクト構造の検証:")
    print("="*50)

    key_elements = [
        "src/nexuscore",
        "src/nexuscore/__init__.py",
        "pyproject.toml",
        "tests",
    ]

    for element_path in key_elements:
        path = Path(element_path)
        status = "✅ 存在します" if path.exists() else "❌ 見つかりません"
        print(f"  - {element_path:<30} -> {status}")

    print("="*50)


def main():
    """
    メインの実行関数。コマンドライン引数を処理し、各機能を呼び出します。
    """
    parser = argparse.ArgumentParser(
        description="NexusCore プロジェクトのインポートパス修正と構造検証を行うツール",
        formatter_class=argparse.RawTextHelpFormatter
    )
    parser.add_argument(
        "-d", "--directory",
        default="src",
        help="スキャン対象のルートディレクトリ (デフォルト: 'src')"
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="実際の変更を行わず、修正・作成されるファイルの一覧を表示します。"
    )
    parser.add_argument(
        "--no-interactive",
        action="store_true",
        help="実行前の確認プロンプトをスキップします。"
    )
    args = parser.parse_args()

    print("🚀 NexusCore メンテナンスツール 🚀")
    print("="*60)
    print(f"作業ディレクトリ: {Path.cwd()}")
    print(f"対象ディレクトリ: {args.directory}")
    if args.dry_run:
        print("モード: ⚠️ ドライラン (変更は行われません)")
    print("="*60)

    if not args.dry_run and not args.no_interactive:
        response = input("上記のディレクトリに対して変更処理を実行しますか？ (y/N): ").lower()
        if response != 'y':
            print("🚫 処理を中断しました。")
            return

    # Step 1: 構造の検証
    verify_structure()

    # Step 2: __init__.py ファイルの作成
    create_missing_init_files(dry_run=args.dry_run)

    # Step 3: インポートパスの修正
    fix_import_paths(root_dir=args.directory, dry_run=args.dry_run)

    print("\n🎉 全ての処理が完了しました。")
    if args.dry_run:
        print("ドライランモードだったため、実際のファイル変更はありません。")
        print("変更を実行するには、--dry-run オプションを外して再実行してください。")
    else:
        print("\n🎯 次のコマンドでテストを実行し、変更内容に問題がないか確認してください：")
        print("pytest --cov=src --cov-report=term-missing tests/")


if __name__ == "__main__":
    main()

```


## tools\export_structure.py

```python
# ファイル名: export_structure.py
# メモ:
# - 指定フォルダのディレクトリ構造をツリー形式でテキスト出力
# - 出力先フォルダ「project_structure_export」を自動作成し、
#   解析したフォルダ名を使ったファイル名「<foldername>_folder_structure.txt」で保存
# - 除外ディレクトリもカスタマイズ可能
# - 使い方: python export_structure.py [対象ディレクトリ（省略時はカレント）]

import os
import sys

EXCLUDE_DIRS = {'.git', '__pycache__', '.venv', 'venv', '.idea', '.mypy_cache', '.pytest_cache', '.DS_Store'}

def print_tree(root, prefix="", file=sys.stdout):
    entries = sorted([e for e in os.listdir(root) if e not in EXCLUDE_DIRS])
    for i, entry in enumerate(entries):
        path = os.path.join(root, entry)
        connector = "└── " if i == len(entries) - 1 else "├── "
        print(prefix + connector + entry, file=file)
        if os.path.isdir(path):
            extension = "    " if i == len(entries) - 1 else "│   "
            print_tree(path, prefix + extension, file=file)

if __name__ == "__main__":
    if len(sys.argv) > 1:
        target_dir = os.path.abspath(sys.argv[1])
    else:
        target_dir = os.getcwd()

    # 解析したフォルダ名を取得
    folder_name = os.path.basename(os.path.normpath(target_dir))

    # 出力用フォルダを作成
    export_dir = "project_structure_export"
    os.makedirs(export_dir, exist_ok=True)

    # 出力ファイル名（例: myproject_folder_structure.txt）
    output_file = os.path.join(export_dir, f"{folder_name}_folder_structure.txt")

    with open(output_file, "w", encoding="utf-8") as f:
        print(f"{folder_name}/", file=f)
        print_tree(target_dir, file=f)

    print(f"フォルダ構造を {output_file} に出力しました。")

```


## tools\gradio_code_initializer.py

```python
# src/gradio_code_initializer.py
import gradio as gr
import openai
import os
from dotenv import load_dotenv
from file_creator import create_code_file

# .env から APIキーを読み込む
load_dotenv()
openai.api_key = os.getenv("OPENAI_API_KEY")

def generate_code_from_prompt(prompt: str, filename: str):
    if not filename.endswith(".py"):
        filename += ".py"
    try:
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "あなたはPythonコードの専門家です。正確で読みやすいコードを出力してください。"},
                {"role": "user", "content": prompt}
            ]
        )
        code = response["choices"][0]["message"]["content"]
        file_path = create_code_file(filename, code)
        return f"✅ ファイル作成完了: {file_path}\n\n---\n{code}"
    except Exception as e:
        return f"❌ エラー: {str(e)}"

# Gradio UI の定義
demo = gr.Interface(
    fn=generate_code_from_prompt,
    inputs=[
        gr.Textbox(label="📝 作ってほしいコードの内容（自然言語でOK）", placeholder="例：PythonでFizzBuzzを書く", lines=4),
        gr.Textbox(label="💾 保存するファイル名（.pyは不要）", placeholder="例：fizzbuzz")
    ],
    outputs=gr.Textbox(label="📄 結果とコード", lines=20),
    title="✨ コード初期化自動生成ツール",
    description="指示を入力すると、コードをGPTで生成し、自動的にファイルとして保存します。"
)

if __name__ == "__main__":
    demo.launch()

```


## run_quality_gate_test.py

```python
# ==============================================================================
# フォルダ: (プロジェクトルート)
# ファイル名: run_quality_gate_test.py
# メモ: Orchestratorに実装された「品質ゲート」が正しく機能するかを
#      検証するためのE2Eテストスクリプト。【ImportError修正版】
# ==============================================================================

import os
import shutil
import logging
from pathlib import Path
from dotenv import load_dotenv
import re

# .envファイルから環境変数を読み込む
load_dotenv()

# --- プロジェクトのコアコンポーネントをインポート ---
# スクリプトがルートにあるため、パス設定は不要
from src.core.orchestrator import Orchestrator
# ▼▼▼▼▼ ここからが最重要修正点 ▼▼▼▼▼
# 各エージェントを、それぞれのファイル(モジュール)から直接インポートするように修正
from src.agents.architect_agent import ArchitectAgent
from src.agents.planner_agent import PlannerAgent
from src.agents.coder_agent import CoderAgent
from src.agents.tester_agent import TesterAgent
from src.agents.debugger_agent import DebuggerAgent
from src.agents.guardian_agent import GuardianAgent
from src.agents.policy_agent import PolicyAgent
from src.agents.postmortem_agent import PostmortemAgent
from src.agents.knowledge_curator_agent import KnowledgeCuratorAgent
# ▲▲▲▲▲ ここまでが最重要修正点 ▲▲▲▲▲
from src.utils.config import config

# --- テスト用の設定 ---
# 環境変数からAPIキーとモデルを取得、なければデフォルト値を使用
API_KEY = config.GEMINI_API_KEY_AGENT_A
MODEL = "gemini-1.5-pro-latest"
TEST_PROJECT_PATH = "quality_gate_test_sandbox"

# --- ロギング設定 ---
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler("quality_gate_test_run.log", mode='w', encoding='utf-8')
    ]
)
logger = logging.getLogger(__name__)

def setup_test_environment():
    """テスト用のサンドボックス環境を準備する"""
    logger.info(f"Setting up test environment at: ./{TEST_PROJECT_PATH}")
    if os.path.exists(TEST_PROJECT_PATH):
        shutil.rmtree(TEST_PROJECT_PATH)
    os.makedirs(TEST_PROJECT_PATH)
    
    # ダミーのfkb_local.jsonを作成
    Path(TEST_PROJECT_PATH, "fkb_local.json").write_text("[]", encoding='utf-8')
    
    # ダミーのpolicy_rules.jsonを作成
    config_dir = Path(TEST_PROJECT_PATH, "config")
    config_dir.mkdir()
    Path(config_dir, "policy_rules.json").write_text("[]", encoding='utf-8')

    # pytest-covのための設定ファイルを作成
    pyproject_toml_content = """
[tool.pytest.ini_options]
pythonpath = ["."]
addopts = "--cov=app --cov-report=term-missing"

[tool.coverage.run]
source = ["app"]

[tool.coverage.report]
fail_under = 0  # テスト自体はカバレッジで失敗させない
show_missing = true
"""
    Path(TEST_PROJECT_PATH, "pyproject.toml").write_text(pyproject_toml_content, encoding='utf-8')

def main():
    """品質ゲートのテストを実行するメイン関数"""
    if not API_KEY:
        logger.error("GEMINI_API_KEY_AGENT_A is not set in the .env file. Aborting test.")
        return

    setup_test_environment()

    try:
        # --- 憲法 (品質基準を含む) ---
        constitution = {
            "description": "This is a test constitution for the quality gate.",
            "quality_gate": {
                "MIN_COVERAGE": 90,
                "MIN_PYLINT_SCORE": 8.0
            }
        }

        # --- AIエージェントの初期化 ---
        project_abs_path = os.path.abspath(TEST_PROJECT_PATH)
        architect = ArchitectAgent(api_key=API_KEY, model=MODEL)
        planner = PlannerAgent(api_key=API_KEY, model=MODEL)
        coder = CoderAgent(api_key=API_KEY, model=MODEL)
        tester = TesterAgent(api_key=API_KEY, model=MODEL)
        debugger = DebuggerAgent(api_key=API_KEY, model=MODEL, project_path=project_abs_path)
        guardian = GuardianAgent(api_key=API_KEY, model=MODEL)
        policy_agent = PolicyAgent(api_key=API_KEY, model=MODEL, policy_rules_path=f"{TEST_PROJECT_PATH}/config/policy_rules.json")
        postmortem_agent = PostmortemAgent(api_key=API_KEY, model=MODEL)
        knowledge_curator_agent = KnowledgeCuratorAgent(api_key=API_KEY, model=MODEL)

        # --- Orchestratorの初期化 ---
        orchestrator = Orchestrator(
            project_path=project_abs_path,
            constitution=constitution,
            architect=architect,
            planner=planner,
            coder=coder,
            tester=tester,
            debugger=debugger,
            guardian=guardian,
            policy_agent=policy_agent,
            postmortem_agent=postmortem_agent,
            knowledge_curator_agent=knowledge_curator_agent
        )

        # --- テストシナリオの定義 ---
        # このタスクはシンプルなので、AIは最初ドキュメントなしのコードを生成しやすい
        task_to_execute = {
            "name": "add_two_numbers",
            "module": "calculator",
            "description": "Create a function 'add' that takes two integers 'a' and 'b' and returns their sum."
        }
        
        logger.info("\n" + "="*50)
        logger.info("🚀 STARTING TEST: QUALITY GATE FEEDBACK LOOP")
        logger.info("="*50 + "\n")

        # 設計フェーズをスキップし、開発サイクルのみを実行
        orchestrator.execute_task(task_to_execute)

        # --- 結果の検証 ---
        logger.info("\n" + "="*50)
        logger.info("🔬 FINAL VERIFICATION")
        logger.info("="*50)
        
        final_code_path = Path(TEST_PROJECT_PATH) / "app" / "calculator.py"
        log_file_path = Path("quality_gate_test_run.log")
        
        test_passed = True
        
        # 1. 最終的なコードが存在するか
        if final_code_path.exists():
            final_code = final_code_path.read_text(encoding='utf-8')
            logger.info(f"Final generated code in {final_code_path}:\n---\n{final_code}\n---")
            # 2. 最終コードにdocstringが含まれているか（品質改善の結果）
            if '"""' not in final_code and "'''" not in final_code:
                logger.error("VERIFICATION FAILED: Final code does not contain a docstring.")
                test_passed = False
            else:
                logger.info("✅ VERIFICATION PASSED: Final code contains a docstring.")
        else:
            logger.error(f"VERIFICATION FAILED: Final code file '{final_code_path}' was not generated.")
            test_passed = False

        # 3. ログに品質ゲート違反の記録があるか
        if log_file_path.exists():
            log_content = log_file_path.read_text(encoding='utf-8')
            if "QUALITY GATE VIOLATION" in log_content:
                logger.info("✅ VERIFICATION PASSED: 'QUALITY GATE VIOLATION' found in logs, indicating the gate was triggered.")
            else:
                logger.error("VERIFICATION FAILED: 'QUALITY GATE VIOLATION' not found in logs. The quality gate may not have been triggered.")
                test_passed = False
        else:
            logger.error("VERIFICATION FAILED: Log file not found.")
            test_passed = False
            
        logger.info("\n" + "-"*20)
        if test_passed:
            logger.info("🎉🎉🎉 OVERALL TEST RESULT: PASSED 🎉🎉🎉")
        else:
            logger.error("😭😭😭 OVERALL TEST RESULT: FAILED 😭😭😭")
        logger.info("-"*20)

    except Exception as e:
        logger.critical(f"An unexpected error occurred during the test run: {e}", exc_info=True)
    finally:
        # クリーンアップ
        # logger.info("Cleaning up test environment...")
        # if os.path.exists(TEST_PROJECT_PATH):
        #     shutil.rmtree(TEST_PROJECT_PATH)
        pass # ログを確認できるよう、サンドボックスは残す

if __name__ == "__main__":
    main()

```


## nexus_os_kernel.py

```python
# ==============================================================================
# ファイル名: nexus_os_kernel.py
# 配置フォルダ: C:\Users\USER\tools\NexusCore\src\
#
# メモ:
# これは、自律型イノベーションOS「NexusOS」の中核をなす、信頼された
# 「カーネル」です。OS上で動作する全てのアプリケーションやエージェント
# (システムサービス)は、このカーネルが提供する標準化された安全な
# 「システムコール」を通じてのみ、リソースへのアクセスや重要な操作を
# 行うことができます。
#
# このカーネルは、以下の重要な責務を担います。
# 1. ガバナンス: NPEを通じて、全ての操作が予算とポリシーに準拠しているか検証する。
# 2. プロセス完全性: VCSとAIピアレビューを通じて、全てのコード変更の品質と
#    追跡可能性を保証する。
# 3. セキュリティ: サンドボックスを通じて、安全でないコードの実行を隔離・防止する。
# 4. サービス提供: 認証済みのLLMクライアントや外部ツールといった、信頼できる
#    共有サービスをアプリケーションに提供する。
# ==============================================================================

import logging

# --- Layer 0: Kernel Module Imports ---
# あなたが実装した、信頼できる低レベル・モジュールをインポートします。
# パスが通っていることを前提としています。
from nexuscore.npe.engine import NPEEngine
from nexuscore.utils.vcs import GitController
from nexuscore.workflows.multi_llm_review import MultiLLMReviewer
from nexuscore.code_interpreter.sandbox_runner import SandboxRunner
from nexuscore.utils.test_generator import TestGenerator
from nexuscore.utils.logger import logger  # あなたのカスタムロガーを使用

class NexusOSKernel:
    """
    The central, trusted kernel for NexusOS.
    It exposes a set of "system calls" that higher-level agents can use,
    and provides access to trusted "services".
    """
    def __init__(self):
        """
        カーネルの起動時に、全てのコアモジュールをシングルトンとして初期化します。
        """
        logger.info("NexusOS Kernel v1.1 is booting...")
        
        # --- コア・カーネルモジュールの初期化 ---
        self.npe = NPEEngine()
        self.vcs = GitController()
        self.reviewer = MultiLLMReviewer()
        self.sandbox = SandboxRunner()
        self.testgen = TestGenerator()

        # --- サービス・レジストリ ---
        # OSが管理する、信頼できる共有サービスをここに登録します。
        # アプリケーションは、get_service()を通じてこれらのサービスを利用します。
        self._services = {
            "Google Search_tool": self._initialize_Google Search(),
            "default_llm_client": self._initialize_default_llm(),
            # 将来的にデータベース接続などもここに追加できます。
            # "database_connection": self._initialize_database()
        }
        
        logger.info("NexusOS Kernel v1.1 has been initialized and is now running.")

    # --------------------------------------------------------------------------
    # Service Provider Methods
    # --------------------------------------------------------------------------
    
    def get_service(self, service_name: str):
        """
        [Kernel Service] Returns a trusted, pre-configured service instance.
        アプリケーションは、このメソッドを通じてOSの共有機能を利用します。
        """
        service = self._services.get(service_name)
        if not service:
            logger.error(f"Service '{service_name}' not found in Kernel registry.")
            raise ValueError(f"Service '{service_name}' not found.")
        
        logger.info(f"Kernel is providing service '{service_name}' to an application.")
        return service

    def _initialize_Google Search(self):
        """（プレースホルダー）本物のGoogle Search APIクライアントを初期化します。"""
        logger.debug("Initializing Google Search service...")
        # from your_actual_Google Search_library import GoogleSearchClient
        # return GoogleSearchClient(api_key=os.getenv("GOOGLE_API_KEY"))
        class DummySearchTool:
            def search(self, queries):
                logger.info(f"KERNEL_STUB (Search): Searching for: {queries}")
                return [{"title": "AI in Healthcare", "snippet": "A growing market.", "url": "http://example.com"}]
        return DummySearchTool()

    def _initialize_default_llm(self):
        """（プレースホルダー）本物のLLMクライアントを初期化します。"""
        logger.debug("Initializing Default LLM Client service...")
        # from your_actual_llm_library import LLMClient
        # return LLMClient(api_key=os.getenv("OPENAI_API_KEY"))
        class DummyLLMClient:
            def invoke(self, prompt, **kwargs):
                logger.info("KERNEL_STUB (LLM): Invoking LLM...")
                return """
                {
                    "ventureName": "HealthAI Diagnostics",
                    "marketAnalysis": "The market for AI-driven diagnostic tools is rapidly expanding.",
                    "productThesis": "An AI platform that analyzes medical images to provide preliminary diagnoses.",
                    "strategicFit": "Leverages NexusCore's data processing and UI generation capabilities.",
                    "resourceRequest": "1 CEO Agent, 5 Dev Agents, 4-week sprint for MVP.",
                    "projectedROI": "5-year 20x return potential."
                }
                """
        return DummyLLMClient()

    # --------------------------------------------------------------------------
    # System Call Methods
    # --------------------------------------------------------------------------

    def syscall_execute_code(self, agent_id: str, code: str, estimated_cost: float) -> dict:
        """
        [System Call] 全てのチェックを通過した後、コードを安全な環境で実行します。
        """
        logger.debug(f"Received 'execute_code' syscall from agent '{agent_id}'.")
        
        # 1. NPEによる予算・ポリシーチェック (関所)
        permission = self.npe.request_permission(
            agent_id=agent_id, 
            action="execute_code",
            estimated_cost=estimated_cost
        )
        if not permission.is_granted:
            logger.warning(f"Syscall denied for {agent_id} by NPE: {permission.reason}")
            raise PermissionError(f"NPE denied request: {permission.reason}")
        
        # 2. サンドボックスでの実行
        result = self.sandbox.run(code)
        
        # 3. 監査ログの記録
        self.npe.log_transaction(agent_id, "execute_code", result)
        
        return result

    def syscall_commit_file(self, agent_id: str, file_path: str, file_content: str, commit_message: str) -> dict:
        """
        [System Call] AIピアレビューと自動テストの後、ファイルを書き込み、VCSにコミットします。
        """
        logger.debug(f"Received 'commit_file' syscall from agent '{agent_id}' for path '{file_path}'.")
        
        # 1. NPEによるチェック
        permission = self.npe.request_permission(agent_id=agent_id, action="commit_file")
        if not permission.is_granted:
            logger.warning(f"Syscall denied for {agent_id} by NPE: {permission.reason}")
            raise PermissionError(f"NPE denied request: {permission.reason}")

        # 2. AIピアレビュー (必須プロセス)
        logger.info(f"Submitting code for file '{file_path}' to AI Peer Review...")
        review_result = self.reviewer.review(file_content)
        if not review_result.is_approved:
            logger.warning(f"Code for '{file_path}' was rejected by AI Peer Review.")
            raise ValueError(f"AI Peer Review rejected the code: {review_result.feedback}")
        logger.info(f"AI Peer Review approved code for '{file_path}'.")
        
        # 3. 自動テスト生成と実行
        logger.info(f"Generating and running tests for file '{file_path}'...")
        tests = self.testgen.generate(file_content)
        test_result = self.sandbox.run(tests)
        if not test_result.passed:
            logger.warning(f"Automated tests failed for '{file_path}'.")
            raise ValueError(f"Automated tests failed: {test_result.output}")
        logger.info(f"Automated tests passed for '{file_path}'.")
        
        # 4. VCSによるファイル書き込みとコミット
        logger.info(f"Committing file '{file_path}' to version control...")
        self.vcs.write_and_commit(
            path=file_path, 
            content=review_result.approved_code, # レビュー済みの承認されたコードを使用
            message=f"[{agent_id}] {commit_message}"
        )
        
        logger.info(f"File '{file_path}' committed successfully by '{agent_id}'.")
        return {"status": "success", "commit_hash": self.vcs.get_last_commit_hash()}


# --- シングルトンインスタンス ---
# OS全体で、カーネルはただ一つだけ存在し、どこからでも同じインスタンスが
# 参照されるようにします。
_kernel_instance = None

def get_kernel() -> NexusOSKernel:
    """
    Returns the singleton instance of the NexusOS Kernel.
    Initializes it on the first call.
    """
    global _kernel_instance
    if _kernel_instance is None:
        _kernel_instance = NexusOSKernel()
    return _kernel_instance
```


## src\__init__.py

```python

```


## main_cli.py

```python
# ==============================================================================
# ファイル: main_cli.py
# メモ: 【統合・最終版】
#      - RequirementAgentを統合し、全自動開発フローの起点とする。
#      - ユーザー実装の堅牢なCLI引数、ロギング、品質ゲート設定を完全に継承。
#      - これがNexusCoreの新しい中核エントリーポイントとなる。
# ==============================================================================
import sys
import os
import argparse
import logging

# ------------------------------------------------------------------------------
# パス設定
# ------------------------------------------------------------------------------
project_root = os.path.abspath(os.path.dirname(__file__))
src_path = os.path.join(project_root, 'src')
if src_path not in sys.path:
    sys.path.insert(0, src_path)
if project_root not in sys.path:
    sys.path.insert(0, project_root)

# ------------------------------------------------------------------------------
# 必要なモジュールとエージェントのインポート
# ------------------------------------------------------------------------------
# ▼▼▼▼▼ 統合点 (1/4): RequirementAgentをインポートリストに追加 ▼▼▼▼▼
from nexuscore.agents.requirement_agent import RequirementAgent
# ▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲
from nexuscore.core.orchestrator import Orchestrator
from nexuscore.agents.architect_agent import ArchitectAgent
from nexuscore.agents.planner_agent import PlannerAgent
from nexuscore.agents.coder_agent import CoderAgent
from nexuscore.agents.tester_agent import TesterAgent
from nexuscore.agents.debugger_agent import DebuggerAgent
from nexuscore.agents.guardian_agent import GuardianAgent
from nexuscore.agents.policy_agent import PolicyAgent
from nexuscore.agents.postmortem_agent import PostmortemAgent
from nexuscore.agents.knowledge_curator_agent import KnowledgeCuratorAgent
# from nexuscore.utils.config import config # .envからの読み込みはdotenvで直接行う

def setup_logging(verbose: bool):
    """ロギングの基本設定（旧コードの優れた実装を維持）"""
    log_level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=log_level,
        format="%(asctime)s - %(levelname)-8s - %(name)-20s - %(message)s",
        handlers=[
            logging.StreamHandler(),
            logging.FileHandler("nexus_core_run.log", mode='w', encoding='utf-8')
        ]
    )
    logging.info(f"Log level set to {logging.getLevelName(log_level)}")

def main():
    """
    コマンドラインからタスクを受け取り、Orchestratorを実行するメイン関数。
    """
    # --- 1. コマンドライン引数の定義（旧コードの堅牢な実装を拡張） ---
    parser = argparse.ArgumentParser(
        description="NexusCore - AI Multi-Agent Development System",
        formatter_class=argparse.RawTextHelpFormatter
    )
    
    parser.add_argument(
        "requirement",
        type=str,
        help="開発したいアプリケーションや機能の自然言語による初期要求。\n例: \"簡単なCRMアプリを作成して。ユーザーを追加、表示できること\""
    )
    parser.add_argument(
        "--project-path",
        type=str,
        required=True,
        help="開発プロジェクトが作成される、あるいは対象となるディレクトリのパス。"
    )
    # ▼▼▼▼▼ 統合点 (2/4): --language引数を追加 ▼▼▼▼▼
    parser.add_argument(
        "--language",
        type=str,
        choices=["ja", "en"],
        default="ja",
        help="RequirementAgentが使用する言語（jaまたはen）。"
    )
    # ▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲
    parser.add_argument(
        "--constitution-text",
        type=str,
        default="このプロジェクトのコードは、常にクリーンで読みやすく、保守性が高いこと。また、すべてのコードには型ヒントとdocstringが付与されている必要がある。",
        help="AIチーム全体が従うべきプロジェクトの原則（自然言語）。"
    )
    parser.add_argument(
        "-v", "--verbose",
        action="store_true",
        help="詳細なデバッグログをコンソールに出力します。"
    )

    args = parser.parse_args()

    # --- 2. ロギングと設定の初期化 ---
    setup_logging(args.verbose)
    
    project_path = os.path.abspath(args.project_path)
    os.makedirs(project_path, exist_ok=True)

    logging.info(f"Project Path: {project_path}")
    logging.info(f"User Initial Requirement: {args.requirement}")
    logging.info(f"Language: {args.language}")

    # --- プロジェクト憲法（品質ゲート含む）の定義（旧コードの優れた実装を維持） ---
    constitution = {
        "description": args.constitution_text,
        "quality_gate": {
            "MIN_COVERAGE": 90,
            "MIN_PYLINT_SCORE": 8.0
        }
    }
    logging.info(f"Full Constitution with Quality Gate: {constitution}")

    try:
        # --- 3. AI開発チーム（エージェント群）の招集 ---
        logging.info("Initializing AI agent team...")
        
        # BaseAgentとLLMRouterにより、APIキーやモデル名は自動で管理される
        
        # ▼▼▼▼▼ 統合点 (3/4): RequirementAgentをチームに追加 ▼▼▼▼▼
        requirement_agent = RequirementAgent(language=args.language)
        # ▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲
        architect = ArchitectAgent()
        planner = PlannerAgent()
        coder = CoderAgent()
        tester = TesterAgent()
        # 外部パスの注入（旧コードの堅牢な実装を維持）
        debugger = DebuggerAgent(knowledge_base_path=os.path.join(project_path, "fkb_local.json"), project_path=project_path)
        guardian = GuardianAgent()
        policy_agent = PolicyAgent(policy_rules_path=os.path.join(project_root, "config", "policy_rules.json"))
        postmortem_agent = PostmortemAgent()
        knowledge_curator_agent = KnowledgeCuratorAgent()

        # --- 4. 司令塔 (Orchestrator) の任命 ---
        logging.info("Initializing Orchestrator...")
        orchestrator = Orchestrator(
            project_path=project_path,
            constitution=constitution,
            # ▼▼▼▼▼ 統合点 (4/4): OrchestratorにRequirementAgentを渡す ▼▼▼▼▼
            requirement_agent=requirement_agent,
            # ▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲
            architect=architect,
            planner=planner,
            coder=coder,
            tester=tester,
            debugger=debugger,
            guardian=guardian,
            policy_agent=policy_agent,
            postmortem_agent=postmortem_agent,
            knowledge_curator_agent=knowledge_curator_agent
        )

        # --- 5. 開発プロセスの開始 ---
        logging.info("Starting full development process...")
        # 新しい一括実行メソッドを、CLI引数を渡して呼び出す
        orchestrator.run_full_project(
            user_initial_request=args.requirement,
            language=args.language
        )
        logging.info("Development process finished successfully.")

    except Exception as e:
        logging.critical(f"An unexpected error occurred in the main CLI: {e}", exc_info=True)
        sys.exit(1)

if __name__ == "__main__":
    main()

```


## run_policy_check_test.py

```python
# ==============================================================================
# ファイル名: run_policy_check_test.py (修正版)
# 場所: プロジェクトのルートディレクトリ
# メモ: PolicyAgentが開発サイクルに正しく組み込まれ、ポリシー違反を
#      検知・ブロックできるかを検証するためのE2Eテストスクリプト。
#      << 修正点 >>
#      - __init__.py をテスト用サンドボックスに自動生成し、
#        pytestのモジュール解決エラーを修正。
# ==============================================================================

import os
import shutil
import logging
import json
from pathlib import Path # pathlibをインポート

# --- プロジェクトのコアコンポーネントをインポート ---
from src.core.orchestrator import Orchestrator
from src.agents.architect_agent import ArchitectAgent
from src.agents.planner_agent import PlannerAgent
from src.agents.coder_agent import CoderAgent
from src.agents.tester_agent import TesterAgent
from src.agents.debugger_agent import DebuggerAgent
from src.agents.guardian_agent import GuardianAgent
from src.agents.policy_agent import PolicyAgent
from src.agents.patch_applier import PatchApplier

# --- テスト用の設定 ---
TEST_PROJECT_PATH = "policy_test_sandbox"
API_KEY = "dummy_key_for_testing"
MODEL = "dummy"

# --- ロギング設定 ---
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

def setup_test_environment():
    """テスト用のサンドボックス環境を準備する"""
    logger.info(f"Setting up test environment at: ./{TEST_PROJECT_PATH}")
    if os.path.exists(TEST_PROJECT_PATH):
        shutil.rmtree(TEST_PROJECT_PATH)
    
    # --- ★★★★★ ここからが最重要修正点 ★★★★★ ---
    # 各ディレクトリを作成し、同時に__init__.pyファイルも作成する
    app_dir = Path(TEST_PROJECT_PATH) / "app"
    tests_dir = Path(TEST_PROJECT_PATH) / "tests"
    
    app_dir.mkdir(parents=True, exist_ok=True)
    tests_dir.mkdir(exist_ok=True)
    
    # __init__.py を作成して、ディレクトリをPythonパッケージとして認識させる
    (app_dir / "__init__.py").touch()
    (tests_dir / "__init__.py").touch()
    
    # ダミーの初期ファイルを作成
    (app_dir / "main.py").write_text("# Initial application file\n", encoding='utf-8')
    (tests_dir / "test_main.py").write_text("# Initial test file\n", encoding='utf-8')
    # --- ★★★★★ ここまでが最重要修正点 ★★★★★ ---
    
    logger.info("Test environment setup complete with package markers (__init__.py).")

def run_test():
    """PolicyAgentの統合テストを実行する"""
    setup_test_environment()

    logger.info("--- Initializing Agents ---")
    
    # 各エージェントを初期化
    architect = ArchitectAgent(API_KEY, MODEL)
    planner = PlannerAgent(API_KEY, MODEL)
    coder = CoderAgent(API_KEY, MODEL)
    tester = TesterAgent(API_KEY, MODEL)
    debugger = DebuggerAgent(API_KEY, MODEL, knowledge_base_path="fkb_local.json")
    guardian = GuardianAgent(API_KEY, MODEL)
    policy_agent = PolicyAgent(API_KEY, MODEL, policy_rules_path="config/policy_rules.json")

    logger.info("--- Initializing Orchestrator with PolicyAgent ---")
    
    orchestrator = Orchestrator(
        project_path=TEST_PROJECT_PATH,
        constitution="Test Constitution: Behave ethically.",
        architect=architect,
        planner=planner,
        coder=coder,
        tester=tester,
        debugger=debugger,
        guardian=guardian,
        policy_agent=policy_agent
    )

    policy_violating_task = {
        "name": "create_debug_greeting",
        "module": "main",
        "description": "Create a function 'debug_greet' that takes a name and prints a greeting message to the console."
    }
    
    logger.info("\n" + "="*50)
    logger.info("🚀 STARTING TEST: EXECUTING A POLICY-VIOLATING TASK")
    logger.info(f"TASK: {policy_violating_task['description']}")
    logger.info("="*50 + "\n")
    
    # 1. CoderAgentに違反コードを生成させる (Simulated)
    logger.info("--- 1. CoderAgent Phase (Simulated) ---")
    violating_code = "def debug_greet(name):\n    print(f'Hello, {name}!')\n"
    source_file_path = os.path.join(TEST_PROJECT_PATH, "app/main.py")
    with open(source_file_path, "w", encoding='utf-8') as f:
        f.write(violating_code)
    logger.info(f"CoderAgent generated violating code:\n---\n{violating_code}\n---")

    # 2. TesterAgentにテストを生成させる (Simulated)
    logger.info("--- 2. TesterAgent Phase (Simulated) ---")
    test_code = "from app.main import debug_greet\n\ndef test_debug_greet(capsys):\n    debug_greet('World')\n    captured = capsys.readouterr()\n    assert captured.out == 'Hello, World!\\n'"
    test_file_path = os.path.join(TEST_PROJECT_PATH, "tests/test_main.py")
    with open(test_file_path, "w", encoding='utf-8') as f:
        f.write(test_code)
    logger.info("TesterAgent generated corresponding tests.")

    # 3. テスト実行サイクル (Actual)
    logger.info("--- 3. Test Execution Cycle (Actual) ---")
    tests_passed, _ = orchestrator.run_tests(test_file_path)
    if not tests_passed:
        logger.error("Tests failed unexpectedly even after the fix. There might be another issue.")
        return
    logger.info("✅ Tests passed successfully.")

    # 4. PolicyAgentによる監査の実行 (Actual)
    logger.info("--- 3.5. PolicyAgent Audit Phase (Actual) ---")
    files_for_audit = [
        {"path": "app/main.py", "content": violating_code},
        {"path": "tests/test_main.py", "content": test_code}
    ]
    policy_result = orchestrator.policy_agent.audit(files_for_audit)

    # 5. 結果の検証
    logger.info("\n" + "="*50)
    logger.info("🔬 TEST RESULT VERIFICATION")
    logger.info("="*50)
    
    if policy_result.get("result") == "REJECTED":
        logger.info("✅ SUCCESS: PolicyAgent correctly REJECTED the code.")
        violations = policy_result.get("violations", [])
        logger.info(f"Found {len(violations)} violation(s):")
        for v in violations:
            logger.info(f"  - {v}")
        
        found_lint_violation = any(v.get("policy_id") == "POLICY_LINT_001" for v in violations)
        if found_lint_violation:
            logger.info("✅ SUCCESS: The correct policy (POLICY_LINT_001) was triggered.")
        else:
            logger.error("❌ FAILURE: The code was rejected, but not for the expected reason (POLICY_LINT_001).")
    else:
        logger.error("❌ FAILURE: PolicyAgent INCORRECTLY approved the code with violations.")

    logger.info("\n--- Test Finished ---")


if __name__ == "__main__":
    run_test()

```


## tools\live_lint_checker.py

```python
# live_lint_checker.py

import time
import threading
import subprocess

def run_lint(filepath: str) -> str:
    result = subprocess.run(["pylint", filepath], capture_output=True, text=True)
    return result.stdout

def live_lint_checker(filepath: str, callback):
    def loop():
        last_code = None
        while True:
            try:
                with open(filepath) as f:
                    code = f.read()
                if code != last_code:
                    result = run_lint(filepath)
                    callback(result)
                    last_code = code
            except Exception as e:
                callback(f"[ERROR] {e}")
            time.sleep(0.5)

    threading.Thread(target=loop, daemon=True).start()

```


## simple_context_agent.py

```python
#!/usr/bin/env python3
r"""
Simple Context Agent - 安全版
フォルダ: C:/Users/USER/tools/NexusCore/simple_context_agent.py
目的: from your_module import エラーを確実に解決
"""

import os
import json
from typing import Dict
from datetime import datetime

class SimpleContextAgent:
    def __init__(self, project_root: str = None):
        self.project_root = project_root or os.getcwd()
        self.context_cache_file = os.path.join(self.project_root, ".nexus_context.json")
        print(f"🔍 プロジェクトルート: {self.project_root}")
        
        # キャッシュがあれば読み込み、なければ作成
        if os.path.exists(self.context_cache_file):
            self.context = self.load_context()
        else:
            self.context = self.create_context()
            self.save_context()
    
    def create_context(self) -> Dict:
        """安全なコンテキスト作成"""
        print("🔍 コンテキストを作成中...")
        
        context = {
            "tech_stack": {
                "frameworks": self._safe_detect_frameworks(),
                "python_version": "3.11+"
            },
            "file_structure": {
                "has_src_dir": os.path.exists(os.path.join(self.project_root, "src")),
                "has_tests_dir": os.path.exists(os.path.join(self.project_root, "tests")),
                "has_venv": os.path.exists(os.path.join(self.project_root, "venv"))
            },
            "dependencies": {
                "external": ["gradio", "openai", "pytest"],
                "internal": ["nexuscore"]
            },
            "environment": {
                "platform": os.name,
                "env_file_exists": os.path.exists(os.path.join(self.project_root, ".env")),
                "in_venv": os.getenv("VIRTUAL_ENV") is not None
            },
            "dev_policy": {
                "test_import_policy": "関数を直接埋め込み",
                "error_language": "日本語",
                "quality_requirements": ["docstring必須", "エラーハンドリング必須"],
                "security_policy": ["APIキー環境変数管理", "ハードコーディング禁止"],
                "configured_at": datetime.now().isoformat()
            },
            "last_updated": datetime.now().isoformat(),
            "version": "1.0-safe"
        }
        
        print("✅ コンテキスト作成完了")
        return context
    
    def _safe_detect_frameworks(self) -> list:
        """安全なフレームワーク検出"""
        frameworks = []
        req_file = os.path.join(self.project_root, "requirements.txt")
        
        if os.path.exists(req_file):
            try:
                with open(req_file, 'r', encoding='utf-8') as f:
                    content = f.read().lower()
                    if 'gradio' in content:
                        frameworks.append('gradio')
                    if 'openai' in content:
                        frameworks.append('openai')
                    if 'pytest' in content:
                        frameworks.append('pytest')
                    if 'streamlit' in content:
                        frameworks.append('streamlit')
            except Exception:
                frameworks = ['gradio', 'openai']
        
        return frameworks
    
    def load_context(self) -> Dict:
        """コンテキスト読み込み"""
        try:
            with open(self.context_cache_file, 'r', encoding='utf-8') as f:
                context = json.load(f)
                print(f"✅ キャッシュ読み込み: {self.context_cache_file}")
                return context
        except Exception as e:
            print(f"⚠️ キャッシュ読み込み失敗: {e}")
            return self.create_context()
    
    def save_context(self):
        """コンテキスト保存"""
        try:
            with open(self.context_cache_file, 'w', encoding='utf-8') as f:
                json.dump(self.context, f, indent=2, ensure_ascii=False)
            print(f"✅ コンテキスト保存: {self.context_cache_file}")
        except Exception as e:
            print(f"❌ 保存エラー: {e}")
    
    def get_error_prevention_rules(self) -> Dict:
        """エラー予防ルール（今回のエラー解決）"""
        return {
            "embed_functions_in_tests": True,
            "use_japanese_errors": True,
            "require_docstring": True,
            "require_error_handling": True,
            "use_env_vars": True,
            "test_policy": "関数を直接埋め込み"
        }
    
    def generate_enhanced_test_prompt(self, source_code: str) -> str:
        """エラー回避版テスト生成プロンプト"""
        return f"""以下のPythonコードに対するpytest形式のテストコードを生成してください：

{source_code}

重要な要件:
- インポート文は一切使用しない
- テスト対象の関数定義もテストファイルに含める
- 完全に自己完結したテストファイルとして作成
- pytest形式でテストを作成
- 正常系と異常系の両方をテスト
- 日本語でコメントを記述

`````` で終わるコードブロック形式で出力してください。"""

if __name__ == "__main__":
    print("🚀 SimpleContextAgent 開始")
    print("📁 実行場所: C:/Users/USER/tools/NexusCore/simple_context_agent.py")
    
    # 基本動作テスト
    agent = SimpleContextAgent()
    
    print("\n📊 コンテキスト:")
    print(json.dumps(agent.context, indent=2, ensure_ascii=False))
    
    print("\n🛡️ エラー予防ルール:")
    rules = agent.get_error_prevention_rules()
    for rule, value in rules.items():
        print(f"  {rule}: {value}")
    
    # テスト生成のデモ
    print("\n🧪 修正されたテスト生成プロンプト例:")
    sample_code = "def add(a, b): return a + b"
    enhanced_prompt = agent.generate_enhanced_test_prompt(sample_code)
    print(enhanced_prompt[:200] + "...")
    
    print("\n✅ SimpleContextAgent 完了！")
    print("💡 これで from your_module import エラーは解決されます。")

```


## run_self_healing.py

```python
# ==============================================================================
# フォルダ: (プロジェクトルート)
# ファイル名: run_self_healing.py
# メモ: 構造化ログの保存先ディレクトリをOrchestratorに渡すように
#      アップグレードされた最終テストスクリプト。
# ==============================================================================
import os
import sys
import shutil
import subprocess
import logging
from pathlib import Path

VERBOSE = True # 詳細ログの表示/非表示を切り替え

def setup_logging(level=logging.INFO):
    log_format = "%(asctime)s - %(levelname)-8s - %(name)-20s - %(message)s"
    for handler in logging.root.handlers[:]:
        logging.root.removeHandler(handler)
    logging.basicConfig(level=level, format=log_format)

def main():
    log_level = logging.DEBUG if VERBOSE else logging.INFO
    setup_logging(log_level)
    
    logging.info("--- NexusCore Self-Healing System (Test with Structured Logging) ---")

    try:
        project_root = Path(__file__).resolve().parent
        sandbox_path = project_root / "healing_sandbox"
        
        # (ファイルパスの定義は変更なし)
        # ...
        agent_sources = {
            "orchestrator.py": project_root / "src" / "agents" / "orchestrator.py",
            "debugger_agent.py": project_root / "src" / "agents" / "debugger_agent.py",
            "patch_applier.py": project_root / "src" / "agents" / "patch_applier.py",
            "base_agent.py": project_root / "src" / "agents" / "base_agent.py",
            "fkb_local.json": project_root / "fkb_local.json"
        }
        crm_app_sources = {
            "main.py": project_root / "my-crm-app" / "app" / "main.py",
            "test_main.py": project_root / "my-crm-app" / "tests" / "test_main.py"
        }


        logging.info("Verifying required files...")
        all_sources = {**agent_sources, **crm_app_sources}
        for name, path in all_sources.items():
            if not path.exists():
                raise FileNotFoundError(f"Required file not found: '{path}'")
            logging.debug(f"Found: {path.relative_to(project_root)}")

        logging.info(f"Setting up sandbox environment at: {sandbox_path}")
        if sandbox_path.exists():
            shutil.rmtree(sandbox_path)
        
        # (ディレクトリ作成は変更なし)
        # ...
        (sandbox_path / "app").mkdir(parents=True, exist_ok=True)
        (sandbox_path / "tests").mkdir(exist_ok=True)
        (sandbox_path / "src" / "agents").mkdir(parents=True, exist_ok=True)
        # ★★★★★ ログ保存用ディレクトリを追加 ★★★★★
        (sandbox_path / "logs").mkdir(exist_ok=True)


        # (ファイルコピーは変更なし)
        # ...
        for name, src_path in agent_sources.items():
            dest_folder = (sandbox_path / "src" / "agents") if name.endswith(".py") else sandbox_path
            shutil.copy(src_path, dest_folder / name)
        
        shutil.copy(crm_app_sources["main.py"], sandbox_path / "app" / "main.py")
        shutil.copy(crm_app_sources["test_main.py"], sandbox_path / "tests" / "test_main.py")
        logging.debug("Copied all required files to sandbox.")

        (sandbox_path / "app" / "__init__.py").touch()
        (sandbox_path / "tests" / "__init__.py").touch()
        (sandbox_path / "src" / "__init__.py").touch()
        (sandbox_path / "src" / "agents" / "__init__.py").touch()


        # --- ★★★★★ ここからが最重要修正点 ★★★★★ ---
        runner_script_code = f"""
import sys, logging
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))

log_level_str = "{logging.getLevelName(log_level)}"
log_level = logging.getLevelName(log_level_str)
log_format = "%(asctime)s - %(levelname)-8s - %(name)-20s - %(message)s"
logging.basicConfig(level=log_level, format=log_format)

from src.agents.orchestrator import Orchestrator
from src.agents.debugger_agent import DebuggerAgent
from src.agents.patch_applier import PatchApplier

def run():
    logging.info(">> Starting Self-Healing Cycle for CRM App...")
    
    debugger = DebuggerAgent(api_key="dummy_key", model="dummy_model", knowledge_base_path="fkb_local.json")
    patcher = PatchApplier()
    
    # Orchestratorにログ保存先のパスを渡す
    orchestrator = Orchestrator(
        debugger_agent=debugger,
        patch_applier=patcher,
        log_dir="logs", # サンドボックス内のlogsディレクトリを指定
        max_retries=3
    )
    
    orchestrator.self_healing_cycle(
        test_file_path="tests/test_main.py",
        source_file_path="app/main.py"
    )

if __name__ == '__main__':
    run()
"""
        # --- ★★★★★ ここまで ★★★★★ ---
        runner_script_path = sandbox_path / "sandbox_runner.py"
        runner_script_path.write_text(runner_script_code, encoding='utf-8')
        logging.debug("Created sandbox runner script.")

        logging.info("Executing the self-healing cycle for CRM App...")
        result = subprocess.run(
            [sys.executable, "sandbox_runner.py"],
            cwd=sandbox_path,
            capture_output=True, text=True, encoding='utf-8', errors='replace'
        )
        
        print("\\n--- Execution Log ---")
        print(result.stdout)
        if result.stderr:
            print("\\n--- Errors ---")
            print(result.stderr)
        print("---------------------")

        logging.info("Self-healing cycle finished.")
        print(f"\\n[INFO] Structured logs have been saved in '{sandbox_path / 'logs'}'")

    except FileNotFoundError as e:
        logging.critical(f"A required file was not found: {e}")
        sys.exit(1)
    except Exception as e:
        logging.critical(f"An unexpected error occurred: {e}", exc_info=True)
        sys.exit(1)

if __name__ == '__main__':
    main()

```


## tools\build_tree_sitter.py

```python
# build_tree_sitter.py

from tree_sitter import Language
import os

os.makedirs("build", exist_ok=True)

Language.build_library(
    # 出力先ファイル
    'build/my-languages.so',

    # 対象とする構文定義リポジトリ（すでにクローン済み）
    [
        'tree_sitter_languages/tree-sitter-python',
    ]
)

print("✅ Tree-sitterライブラリのビルド完了：build/my-languages.so")

```


## run_quality_loop_test.py

```python
# ==============================================================================
# ファイル名: run_quality_loop_test.py
# 場所: プロジェクトのルートディレクトリ
# メモ: DebuggerAgentの初期化を最終仕様に合わせた、完成版テストスクリプト。
# ==============================================================================

import os
import shutil
import logging
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

from src.core.orchestrator import Orchestrator
from src.agents.architect_agent import ArchitectAgent
from src.agents.planner_agent import PlannerAgent
from src.agents.coder_agent import CoderAgent
from src.agents.tester_agent import TesterAgent
from src.agents.debugger_agent import DebuggerAgent
from src.agents.guardian_agent import GuardianAgent
from src.agents.policy_agent import PolicyAgent

# --- テスト用の設定 ---
API_KEY = os.environ.get("OPENAI_API_KEY")
MODEL = "gpt-4o"
TEST_PROJECT_PATH = "quality_loop_test_sandbox"

# --- ロギング設定 ---
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[logging.StreamHandler()]
)
logger = logging.getLogger(__name__)

def setup_test_environment():
    """テスト用のサンドボックス環境を準備する"""
    logger.info(f"Setting up test environment at: ./{TEST_PROJECT_PATH}")
    if os.path.exists(TEST_PROJECT_PATH):
        shutil.rmtree(TEST_PROJECT_PATH)
    
    app_dir = Path(TEST_PROJECT_PATH) / "app"
    tests_dir = Path(TEST_PROJECT_PATH) / "tests"
    app_dir.mkdir(parents=True, exist_ok=True)
    tests_dir.mkdir(exist_ok=True)
    (app_dir / "__init__.py").touch()
    (tests_dir / "__init__.py").touch()
    (app_dir / "main.py").write_text("# Initial application file\n", encoding='utf-8')
    logger.info("Test environment setup complete.")

def run_test():
    """品質改善ループのE2Eテストを実行する"""
    if not API_KEY:
        logger.error("APIキーが見つかりません。.envファイルに 'OPENAI_API_KEY=...' を設定するか、環境変数を確認してください。")
        return
        
    setup_test_environment()

    logger.info("--- Initializing Agents with REAL LLM model ---")
    
    architect = ArchitectAgent(API_KEY, MODEL)
    planner = PlannerAgent(API_KEY, MODEL)
    coder = CoderAgent(API_KEY, MODEL)
    tester = TesterAgent(API_KEY, MODEL)
    # ★ DebuggerAgentにプロジェクトパスを渡すように修正
    debugger = DebuggerAgent(API_KEY, MODEL, knowledge_base_path="fkb_local.json", project_path=TEST_PROJECT_PATH)
    guardian = GuardianAgent(API_KEY, MODEL)
    policy_agent = PolicyAgent(API_KEY, MODEL, policy_rules_path="config/policy_rules.json")

    logger.info(f"--- Initializing Orchestrator (Model: {MODEL}) ---")
    
    orchestrator = Orchestrator(
        project_path=TEST_PROJECT_PATH,
        constitution="Test Constitution: Write clean, documented, and professional code.",
        architect=architect,
        planner=planner,
        coder=coder,
        tester=tester,
        debugger=debugger,
        guardian=guardian,
        policy_agent=policy_agent
    )

    violating_task = {
        "name": "create_user_greeting",
        "module": "main",
        "description": "Create a function 'greet' that takes a name and returns a greeting message. It should be simple."
    }
    
    logger.info("\n" + "="*50)
    logger.info("🚀 STARTING TEST: QUALITY IMPROVEMENT FEEDBACK LOOP")
    logger.info("="*50 + "\n")

    orchestrator.execute_task(violating_task)

    logger.info("\n" + "="*50)
    logger.info("🔬 FINAL VERIFICATION")
    logger.info("="*50)
    
    final_code_path = Path(TEST_PROJECT_PATH) / "app" / "main.py"
    if final_code_path.exists():
        final_code = final_code_path.read_text(encoding='utf-8')
        logger.info(f"Final generated code in {final_code_path}:\n---\n{final_code}\n---")
        
        if "print(" not in final_code and '"""' in final_code:
            logger.info("✅ SUCCESS: Final code appears to have fixed the violations (no 'print', has docstring).")
        else:
            logger.error("❌ FAILURE: Final code still seems to contain policy violations.")
    else:
        logger.error("❌ FAILURE: Final code was not generated.")

if __name__ == "__main__":
    run_test()

```


## healing_sandbox\app\main.py

```python
# my-crm-app/app/main.py
"""
Main application module for the CRM.

This module contains the core business logic.
"""

def hello_world(username: str) -> str:
    """
    Greets the user by their name.

    This function provides a personalized greeting message.

    Args:
        username (str): The name of the user to greet.

    Returns:
        str: The complete greeting message.
    """
    if not isinstance(username, str) or not username:
        return "Hello, anonymous!"
    return f"Hello, {username}!"

def simple_greeting() -> str:
    """
    Returns a simple greeting message.

    This function provides a basic greeting.

    Returns:
        str: A string in the format 'Hello!'.
    """
    return "Hello!"

def greet_user(username: str) -> str:
    """
    Returns a greeting message for the given username.

    This function provides a personalized greeting message.

    Args:
        username (str): The name of the user to greet.

    Returns:
        str: A greeting message in the format 'Hello, [username]!'
    """
    return f"Hello, {username}!"

def greet(username: str = None) -> str:
    """
    Greets the user with a personalized message or a default message if the username is empty or null.
    Handles special characters and long usernames gracefully.

    Args:
        username (str): The name of the user to greet. Can be empty, null, or contain special characters.

    Returns:
        str: A greeting string. 'Hello, [username]!' if the username is provided, 
             and a suitable default message if the username is empty or null.
    """
    if username is None or not username:
        return "Hello, stranger!"
    else:
        return f"Hello, {username}!"
```


## my-crm-app\app\main.py

```python
# my-crm-app/app/main.py
"""
Main application module for the CRM.

This module contains the core business logic.
"""

def hello_world(username: str) -> str:
    """
    Greets the user by their name.

    This function provides a personalized greeting message.

    Args:
        username (str): The name of the user to greet.

    Returns:
        str: The complete greeting message.
    """
    if not isinstance(username, str) or not username:
        return "Hello, anonymous!"
    return f"Hello, {username}!"

def simple_greeting() -> str:
    """
    Returns a simple greeting message.

    This function provides a basic greeting.

    Returns:
        str: A string in the format 'Hello!'.
    """
    return "Hello!"

def greet_user(username: str) -> str:
    """
    Returns a greeting message for the given username.

    This function provides a personalized greeting message.

    Args:
        username (str): The name of the user to greet.

    Returns:
        str: A greeting message in the format 'Hello, [username]!'
    """
    return f"Hello, {username}!"

def greet(username: str = None) -> str:
    """
    Greets the user with a personalized message or a default message if the username is empty or null.
    Handles special characters and long usernames gracefully.

    Args:
        username (str): The name of the user to greet. Can be empty, null, or contain special characters.

    Returns:
        str: A greeting string. 'Hello, [username]!' if the username is provided, 
             and a suitable default message if the username is empty or null.
    """
    if username is None or not username:
        return "Hello, there!"
    else:
        return f"Hello, {username}!"
```


## src\dev_tools\test_manager.py

```python
# test_manager.py
import os
import sys
from dotenv import load_dotenv

# 環境変数読み込み
load_dotenv()
api_key = os.getenv("OPENAI_API_KEY")

# モジュールパスを追加（src配下を明示）
BASE_DIR = os.path.dirname(os.path.dirname(__file__))  # src/
sys.path.append(BASE_DIR)
sys.path.append(os.path.join(BASE_DIR, "modules"))

# モジュールインポート（例）
try:
    from whisper_handler import transcribe_audio
    from code_generator import generate_code_from_text
    from tester import save_and_test_code
    from diff_viewer import generate_diff
except ImportError as e:
    print(f"❌ モジュールの読み込みに失敗しました: {e}")
    sys.exit(1)

# テスト関数
def run_all_tests(audio_path=None, transcript_text=None):
    if not api_key:
        print("❌ .envにOPENAI_API_KEYが定義されていません。")
        return

    print("✅ OpenCodeInterpreter テスト開始\n")

    if audio_path:
        print(f"🎤 音声ファイル文字起こし: {audio_path}")
        transcript = transcribe_audio(audio_path)
    elif transcript_text:
        print(f"📝 指定されたテキストからコード生成：{transcript_text}")
        transcript = transcript_text
    else:
        print("⚠️ 音声ファイルまたはテキストを指定してください。")
        return

    print("\n🧠 GPTコード生成中...")
    code = generate_code_from_text(transcript)
    print("\n" + code)

    print("\n🧪 テスト実行中...")
    result = save_and_test_code(code)
    print("\n" + result)

    print("\n🔍 差分表示...")
    diff = generate_diff("", code)
    print(diff)

    print("\n✅ テスト完了")

# 実行例（任意の音声 or テキストで切り替え）
if __name__ == "__main__":
    # audio_path = os.path.join(BASE_DIR, "sandbox_output", "sample_audio.wav")
    audio_path = None  # 音声ファイルがない場合は None
    transcript_text = "偶数か奇数かを判定するPython関数を作成して"

    run_all_tests(audio_path, transcript_text)

```


## run_vc_scout.py

```python
# ファイル名: run_vc_scout.py
# メモ: これは、私たちが共に設計した「NexusOS」の上で、あなたが実装した
#      完璧な「VentureCapitalistAgent」を、最初の記念すべきアプリケーションとして
#      起動するための公式ランチャーです。
#      OSのカーネルから、標準化されたLLMクライアントや検索ツールを取得し、
#      エージェントに注入（DI）することで、疎結合でメンテナンス性の高い
#      アーキテクチャを実現します。

import logging
from nexus_os_kernel import get_kernel # OSカーネルを取得する
from nexuscore.ventures.vc_agent import VentureCapitalistAgent

# --- ロギング設定 ---
# アプリケーションレベルのロガーを設定
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def main():
    """
    NexusOSのアプリケーションとして、VCエージェントの市場調査タスクを実行する。
    """
    logger.info("Booting NexusOS application: Venture Scout...")

    try:
        # 1. NexusOSカーネルを取得
        # カーネルは、認証済みのLLMクライアントや各種ツールへの
        # 安全なアクセスを提供する。
        kernel = get_kernel()
        logger.info("NexusOS Kernel connection established.")

        # 2. カーネルから必要なサービス（ツール）を取得
        # これにより、VCエージェントはツールの具体的な実装を知る必要がなくなる。
        # 注意：あなたのコードに合わせて 'Google Search' というキーを使用します。
        required_tools = {
            "Google Search": kernel.get_service("Google Search_tool")
        }
        llm_client = kernel.get_service("default_llm_client")

        # 3. あなたのVCエージェントをインスタンス化
        # OSから取得した、信頼できるサービスを注入する。
        vc_agent = VentureCapitalistAgent(
            llm_client=llm_client,
            tools=required_tools
        )
        logger.info("VentureCapitalistAgent instance created successfully.")

        # 4. メインのビジネスロジックを実行
        investment_memo = vc_agent.scout_for_opportunities()

        # 5. 結果を処理し、次のアクションを決定
        if investment_memo:
            logger.info("Investment memo received. Submitting for human review...")
            
            # --- ここでGradio UIや他の通知システムと連携する ---
            # 例：UIに「新しい投資案件が提案されました。承認しますか？」と表示
            # この例では、承認されたものと仮定する。
            human_approval_payload = {
                "approved_by_human": True,
                "reason": "Initial analysis looks promising. Proceed with MVP clone."
            }

            # 6. あなたのVCエージェントの自己クローン機能を呼び出し
            vc_agent.trigger_self_clone(
                venture_name=investment_memo["ventureName"],
                initial_policy=human_approval_payload
            )
        else:
            logger.warning("VC Agent did not return an investment memo in this run.")

    except Exception as e:
        logger.critical(f"A critical error occurred in the Venture Scout application: {e}", exc_info=True)
        # ここで、システム管理者に緊急通知を送るなどの処理を行う
    
    finally:
        logger.info("Venture Scout application run finished.")


if __name__ == "__main__":
    main()
```


## my-crm-app\app\__init__.py

```python
# ==============================================================================
# フォルダ: my-crm-app/app
# ファイル名: __init__.py
# メモ: アプリケーションの心臓部。ハードコードされた設定を排除し、
#      config.pyからすべての設定を読み込むように修正。
#      これにより、設定の一元管理アーキテクチャが完成します。
# ==============================================================================
import os
from flask import Flask
from flask_sqlalchemy import SQLAlchemy

# --- ★★★ ここからが最重要修正点 ★★★ ---
# 1. 親ディレクトリにあるconfig.pyからConfigクラスをインポート
from config import Config
# --- ★★★ ここまで ★★★ ---

# SQLAlchemyのインスタンスを作成
db = SQLAlchemy()

def create_app(config_class=Config):
    """
    アプリケーションファクトリ関数。
    Flaskアプリケーションのインスタンスを生成し、設定を読み込み、
    拡張機能とブループリントを初期化します。
    """
    app = Flask(__name__, instance_relative_config=True)

    # --- ★★★ ここからが最重要修正点 ★★★ ---
    # 2. config.pyのConfigクラスから設定を読み込む
    app.config.from_object(config_class)
    # --- ★★★ ここまで ★★★ ---

    # instanceフォルダが存在することを確認（DBファイルなどが保存される）
    try:
        os.makedirs(app.instance_path)
    except OSError:
        pass

    # 拡張機能（データベース）をアプリケーションに登録
    db.init_app(app)

    # --- ★★★ ここからが最重要修正点 ★★★ ---
    # 3. routes.pyで定義したBlueprintをアプリケーションに登録
    from . import routes
    app.register_blueprint(routes.bp)
    # --- ★★★ ここまで ★★★ ---
    
    return app

```


## src\dev_tools\test_openai_connection.py

```python
# test_openai_connection.py
import os
from openai import OpenAI
from dotenv import load_dotenv

# .env から APIキーを読み込み
load_dotenv()
api_key = os.getenv("OPENAI_API_KEY")

if not api_key:
    print("❌ .env に OPENAI_API_KEY が定義されていません。")
    exit(1)

client = OpenAI(api_key=api_key)

# GPT-4 に簡単な質問を送信して動作確認
try:
    response = client.chat.completions.create(
        model="gpt-4",
        messages=[
            {"role": "user", "content": "こんにちは！APIは正常に動いていますか？"}
        ]
    )
    print("✅ 接続成功！レスポンス：\n")
    print(response.choices[0].message.content)

except Exception as e:
    print(f"❌ エラーが発生しました：{e}")

```


## my-crm-app\app\routes.py

```python
# TODO: Define routes for customer management

from flask import Blueprint, request, jsonify
from .models import Customer
from . import db

bp = Blueprint('main', __name__)

@bp.route('/customers', methods=['GET'])
def get_customers():
    # TODO: Implement logic to retrieve customers
    pass

@bp.route('/customers', methods=['POST'])
def add_customer():
    # TODO: Implement logic to add a new customer
    pass

@bp.route('/customers/<int:id>', methods=['PUT'])
def update_customer(id):
    # TODO: Implement logic to update an existing customer
    pass

@bp.route('/customers/<int:id>', methods=['DELETE'])
def delete_customer(id):
    # TODO: Implement logic to delete a customer
    pass

```


## gradio_app.py

```python
import gradio as gr
import os
import re

def save_to_sample_py(code_str):
    """sample.py に関数コードを保存する"""
    with open("sample.py", "w", encoding="utf-8") as f:
        f.write(code_str.strip())
    return "✅ sample.py に保存されました。"

def extract_function_name(code_str):
    """関数名を抽出（最初の def xxx(...) を探す）"""
    match = re.search(r'def\s+(\w+)\s*\(', code_str)
    return match.group(1) if match else None

def generate_test_code(code_str):
    """pytest 形式のテストコードを生成"""
    func_name = extract_function_name(code_str)
    if not func_name:
        return "⚠️ 関数が見つかりません。先に正しい Python 関数を入力してください。"
    
    test_code = f'''# test_sample.py
import pytest
from sample import {func_name}

def test_{func_name}():
    # ✅ ここは任意で編集してください（例：is_prime 用のテスト例）
    assert {func_name}(2) == True
    assert {func_name}(4) == False
    assert {func_name}(5) == True
    assert {func_name}(0) == False
    assert {func_name}(-1) == False
'''
    return test_code

with gr.Blocks(title="Python関数→保存＋テスト生成") as demo:
    gr.Markdown("## 🧪 Python関数を入力 → sample.py に保存 → pytestコードを生成")

    code_input = gr.Code(label="✏️ Python関数を入力", language="python")

    with gr.Row():
        save_btn = gr.Button("💾 sample.py に保存")
        gen_test_btn = gr.Button("🧪 テストコード生成")

    save_output = gr.Textbox(label="保存メッセージ")
    test_output = gr.Code(label="✅ 自動生成されたユニットテスト", language="python")

    save_btn.click(fn=save_to_sample_py, inputs=code_input, outputs=save_output)
    gen_test_btn.click(fn=generate_test_code, inputs=code_input, outputs=test_output)

if __name__ == "__main__":
    demo.launch()

```


## run_tests.py

```python
#!/usr/bin/env python3
# ==============================================================================
# ファイル名: run_tests.py
# 機能: NexusCoreプロジェクト用のカスタムテストランナー
# バージョン: 1.0.0
# 作成日: 2025-08-04
# 実行方法: python run_tests.py
# ==============================================================================

import unittest
import sys
from pathlib import Path

def run_all_tests():
    """
    プロジェクト全体のテストスイートを実行します。
    このスクリプトは、正しいモジュールパスを設定し、
    一貫したテスト環境を提供します。
    """
    # プロジェクトのルートディレクトリを取得
    project_root = Path(__file__).parent
    
    # 'src' ディレクトリをPythonの検索パスに追加
    # これにより、`from nexuscore.analyzer...` のようなインポートが可能になる
    src_path = project_root / 'src'
    if str(src_path) not in sys.path:
        sys.path.insert(0, str(src_path))
        print(f"✅ Added '{src_path}' to system path.")

    # テストローダーを作成
    # 'tests' ディレクトリから 'test_*.py' というパターンのファイルを探す
    loader = unittest.TestLoader()
    suite = loader.discover(start_dir='tests', pattern='test_*.py')
    
    # テストランナーを作成し、スイートを実行
    runner = unittest.TextTestRunner(verbosity=2)
    print("\n🚀 Starting NexusCore test suite...")
    print("=" * 70)
    
    result = runner.run(suite)
    
    print("=" * 70)
    print("✅ Test suite finished.")
    
    # CI/CDのために終了コードを返す
    if result.wasSuccessful():
        sys.exit(0)
    else:
        sys.exit(1)

if __name__ == '__main__':
    run_all_tests()

```


## src\sandbox_logs\repair_20250713_131833_fixed.py

```python
元のコードには、Pythonの文法エラーがあります。Pythonは英語ベースのプログラミング言語であり、日本語のコメントや文字列以外の場所で日本語を使用するとエラーが発生します。そのため、日本語の部分を削除または英語のコメントに変更する必要があります。

また、関数addの中でaとbを引き算していますが、関数名から推測するに加算が意図されていると思われます。そのため、その部分も修正します。

修正後のコードは以下の通りです。

```python
def add(a, b):
    return a + b  # Corrected from subtraction to addition
```

ただし、エラーメッセージからは、pytest形式のユニットテストが期待されているようです。そのため、適切なテストケースも追加すると以下のようになります。

```python
def add(a, b):
    return a + b  # Corrected from subtraction to addition

def test_add():
    assert add(1, 2) == 3
    assert add(-1, 1) == 0
    assert add(0, 0) == 0
```
```


## src\sandbox_logs\repair_20250713_131843_original.py

```python
元のコードには、Pythonの文法エラーがあります。Pythonは英語ベースのプログラミング言語であり、日本語のコメントや文字列以外の場所で日本語を使用するとエラーが発生します。そのため、日本語の部分を削除または英語のコメントに変更する必要があります。

また、関数addの中でaとbを引き算していますが、関数名から推測するに加算が意図されていると思われます。そのため、その部分も修正します。

修正後のコードは以下の通りです。

```python
def add(a, b):
    return a + b  # Corrected from subtraction to addition
```

ただし、エラーメッセージからは、pytest形式のユニットテストが期待されているようです。そのため、適切なテストケースも追加すると以下のようになります。

```python
def add(a, b):
    return a + b  # Corrected from subtraction to addition

def test_add():
    assert add(1, 2) == 3
    assert add(-1, 1) == 0
    assert add(0, 0) == 0
```
```


## src\sandbox_logs\repair_20250713_132959_fixed.py

```python
このエラーは、Pythonコードが日本語で書かれているために発生しています。Pythonは日本語のコメント以外を解釈できません。そのため、日本語で書かれたコードを英語に置き換える必要があります。ただし、元のコードが何をするものだったのかが不明なため、具体的な修正案を提案することはできません。

ただし、エラーメッセージから推測すると、おそらくユニットテストを書こうとしていた可能性があります。その場合、以下のような形式で書くことが一般的です。

```python
import unittest

def add(a, b):
    return a + b

class TestAdd(unittest.TestCase):
    def test_add(self):
        self.assertEqual(add(1, 2), 3)

if __name__ == '__main__':
    unittest.main()
```

このコードは、add関数が正しく動作することを確認するユニットテストを含んでいます。
```


## src\sandbox_logs\repair_20250713_133018_fixed.py

```python
申し訳ありませんが、元のコードが見えないため、具体的な修正案を提案することはできません。ただし、エラーメッセージから推測すると、Pythonコードが日本語で書かれているためにエラーが発生しているようです。Pythonは日本語のコメント以外を解釈できません。そのため、日本語で書かれたコードを英語に置き換える必要があります。

また、エラーメッセージからは、ユニットテストを書こうとしていたことが推測できます。その場合、以下のような形式で書くことが一般的です。

```python
import unittest

def add(a, b):
    return a + b

class TestAdd(unittest.TestCase):
    def test_add(self):
        self.assertEqual(add(1, 2), 3)

if __name__ == '__main__':
    unittest.main()
```

このコードは、add関数が正しく動作することを確認するユニットテストを含んでいます。
```


## src\sandbox_logs\repair_20250713_133018_original.py

```python
このエラーは、Pythonコードが日本語で書かれているために発生しています。Pythonは日本語のコメント以外を解釈できません。そのため、日本語で書かれたコードを英語に置き換える必要があります。ただし、元のコードが何をするものだったのかが不明なため、具体的な修正案を提案することはできません。

ただし、エラーメッセージから推測すると、おそらくユニットテストを書こうとしていた可能性があります。その場合、以下のような形式で書くことが一般的です。

```python
import unittest

def add(a, b):
    return a + b

class TestAdd(unittest.TestCase):
    def test_add(self):
        self.assertEqual(add(1, 2), 3)

if __name__ == '__main__':
    unittest.main()
```

このコードは、add関数が正しく動作することを確認するユニットテストを含んでいます。
```


## src\sandbox_logs\repair_20250713_133036_fixed.py

```python
申し訳ありませんが、エラーメッセージからは具体的な修正案を提案することが難しいです。ただし、エラーメッセージから推測すると、Pythonコードが日本語で書かれているためにエラーが発生しているようです。Pythonは日本語のコメント以外を解釈できません。そのため、日本語で書かれたコードを英語に置き換える必要があります。

また、エラーメッセージからは、ユニットテストを書こうとしていたことが推測できます。その場合、以下のような形式で書くことが一般的です。

```python
import unittest

def add(a, b):
    return a + b

class TestAdd(unittest.TestCase):
    def test_add(self):
        self.assertEqual(add(1, 2), 3)

if __name__ == '__main__':
    unittest.main()
```

このコードは、add関数が正しく動作することを確認するユニットテストを含んでいます。
```


## src\sandbox_logs\repair_20250713_133036_original.py

```python
申し訳ありませんが、元のコードが見えないため、具体的な修正案を提案することはできません。ただし、エラーメッセージから推測すると、Pythonコードが日本語で書かれているためにエラーが発生しているようです。Pythonは日本語のコメント以外を解釈できません。そのため、日本語で書かれたコードを英語に置き換える必要があります。

また、エラーメッセージからは、ユニットテストを書こうとしていたことが推測できます。その場合、以下のような形式で書くことが一般的です。

```python
import unittest

def add(a, b):
    return a + b

class TestAdd(unittest.TestCase):
    def test_add(self):
        self.assertEqual(add(1, 2), 3)

if __name__ == '__main__':
    unittest.main()
```

このコードは、add関数が正しく動作することを確認するユニットテストを含んでいます。
```


## src\sandbox_logs\repair_20250713_134201_fixed.py

```python
```python
# 以下のように、pytest形式のユニットテストを生成します。
def add(a, b):
    return a + b
```

エラーメッセージによると、Pythonのコード中に無効な文字 '、' (U+3001)が存在しています。しかし、提供されたコードにはそのような文字は存在していません。したがって、エラーはコメント部分に由来している可能性が高いです。

Pythonのコメントは英語を基本としており、一部の非ASCII文字はサポートされていません。このエラーは、コメント内の日本語の句読点 '、' が原因である可能性があります。

したがって、コメントを英語に変更することでエラーを解消できます。以下に修正後のコードを示します。

```python
# Generate unit tests in pytest format as follows.
def add(a, b):
    return a + b
```

なお、このエラーが発生した環境が日本語を完全にサポートしていない可能性もあります。その場合、日本語のコメントを全て英語に変更するか、非ASCII文字を含まないようにする必要があります。
```


## my-crm-app\app\views.py

```python
# TODO: Define routes and view functions

from flask import Blueprint, request, jsonify
from .models import Customer
from . import db

main = Blueprint('main', __name__)

@main.route('/customers', methods=['GET'])
def get_customers():
    # TODO: Implement logic to retrieve customers
    return jsonify([])

@main.route('/customers', methods=['POST'])
def add_customer():
    # TODO: Implement logic to add a new customer
    return jsonify({'message': 'Customer added'})

```


## _extract_deps.py

```python
import sys, tomllib
from pathlib import Path

p = Path("pyproject.toml")
if not p.exists():
    print("[info] pyproject.toml: not found at repo root")
    sys.exit(0)

data = tomllib.loads(p.read_text(encoding="utf-8"))

def section(title, items):
    print(f"\n# {title}")
    if not items:
        print("(empty)")
    else:
        for x in sorted(items):
            print(x)

proj_deps = []
poetry_deps = []
opt_groups = {}

# PEP 621
proj_deps = list(data.get("project", {}).get("dependencies", []) or [])

# Poetry
for k, v in (data.get("tool", {}).get("poetry", {}).get("dependencies", {}) or {}).items():
    if k.lower() == "python":
        continue
    if isinstance(v, str):
        poetry_deps.append(f"{k} {v}")
    elif isinstance(v, dict):
        vers = v.get("version", "")
        extras = v.get("extras", [])
        poetry_deps.append(f"{k}{'['+','.join(extras)+']' if extras else ''} {vers}")

# optional-dependencies (PEP 621)
opt_groups = data.get("project", {}).get("optional-dependencies", {}) or {}

print(f"[info] Loaded: {p.resolve()}")
section("project.dependencies", proj_deps)
section("tool.poetry.dependencies", poetry_deps)
for grp, lst in opt_groups.items():
    section(f"optional-dependencies.{grp}", lst)

```


## src\sandbox_logs\repair_20250713_134136_fixed.py

```python
エラーメッセージから見ると、エラーは無効な文字 '、' (U+3001) によるもので、これはPythonが理解できない文字です。このエラーは、通常、非ASCII文字がコード内に含まれている場合に発生します。PythonはデフォルトでASCII文字のみをサポートしており、その他の文字を使用する場合は、ファイルの先頭に特定のエンコーディングを指定する必要があります。

ただし、このエラーメッセージは、Pythonコードとして解釈できない日本語のコメントが含まれているために発生している可能性が高いです。Pythonのコメントは '#' 記号で始まります。

したがって、元のコードには実際のエラーはなく、コメントを正しくフォーマットすれば問題は解決するはずです。

修正後のコードは以下の通りです：

```python
# 以下は、pytest形式のユニットテストの一例です。
def add(a, b):
    return a + b
```

ただし、このエラーメッセージはunittestを使用してテストを実行しようとしたときに発生しているようです。そのため、実際には、この関数をテストするための適切なテストケースが必要になるでしょう。
```


## src\sandbox_logs\repair_20250713_134145_original.py

```python
エラーメッセージから見ると、エラーは無効な文字 '、' (U+3001) によるもので、これはPythonが理解できない文字です。このエラーは、通常、非ASCII文字がコード内に含まれている場合に発生します。PythonはデフォルトでASCII文字のみをサポートしており、その他の文字を使用する場合は、ファイルの先頭に特定のエンコーディングを指定する必要があります。

ただし、このエラーメッセージは、Pythonコードとして解釈できない日本語のコメントが含まれているために発生している可能性が高いです。Pythonのコメントは '#' 記号で始まります。

したがって、元のコードには実際のエラーはなく、コメントを正しくフォーマットすれば問題は解決するはずです。

修正後のコードは以下の通りです：

```python
# 以下は、pytest形式のユニットテストの一例です。
def add(a, b):
    return a + b
```

ただし、このエラーメッセージはunittestを使用してテストを実行しようとしたときに発生しているようです。そのため、実際には、この関数をテストするための適切なテストケースが必要になるでしょう。
```


## src\sandbox_logs\repair_20250713_213259_fixed.py

```python
エラーメッセージから見ると、問題はPythonコードではなく、テストコードにあるようです。エラーメッセージは、テストコードの1行目に無効な文字があると指摘しています。これは、PythonがASCII以外の文字を認識できないためです。

ただし、提供された情報からは、テストコードの内容を確認することはできません。したがって、具体的な修正方法を提案することはできません。

ただし、一般的なアドバイスとしては、Pythonコードやテストコードに非ASCII文字（日本語など）を使用する場合は、ファイルの先頭に文字エンコーディングを指定することをお勧めします。これは、Pythonがファイルの文字エンコーディングを正しく認識するために必要です。

以下のように、ファイルの先頭に文字エンコーディングを指定します：

```python
# -*- coding: utf-8 -*-
```

この行を追加すると、PythonはファイルがUTF-8でエンコードされていることを認識し、非ASCII文字を正しく処理できます。

ただし、この修正が問題を解決するかどうかは、テストコードの他の部分にどのような内容が含まれているかによります。
```


## src\sandbox_logs\repair_20250713_213319_original.py

```python
エラーメッセージから見ると、問題はPythonコードではなく、テストコードにあるようです。エラーメッセージは、テストコードの1行目に無効な文字があると指摘しています。これは、PythonがASCII以外の文字を認識できないためです。

ただし、提供された情報からは、テストコードの内容を確認することはできません。したがって、具体的な修正方法を提案することはできません。

ただし、一般的なアドバイスとしては、Pythonコードやテストコードに非ASCII文字（日本語など）を使用する場合は、ファイルの先頭に文字エンコーディングを指定することをお勧めします。これは、Pythonがファイルの文字エンコーディングを正しく認識するために必要です。

以下のように、ファイルの先頭に文字エンコーディングを指定します：

```python
# -*- coding: utf-8 -*-
```

この行を追加すると、PythonはファイルがUTF-8でエンコードされていることを認識し、非ASCII文字を正しく処理できます。

ただし、この修正が問題を解決するかどうかは、テストコードの他の部分にどのような内容が含まれているかによります。
```


## quality_gate_test_sandbox\app\calculator.py

```python
def add_two_numbers(a: int, b: int) -> int:
    """
    Create a function 'add' that takes two integers 'a' and 'b' and returns their sum.
    """
    return a + b


def test_add_two_numbers():
    """Test cases for add_two_numbers function."""
    assert add_two_numbers(2, 3) == 5
    assert add_two_numbers(-2, 3) == 1
    assert add_two_numbers(2, -3) == -1
    assert add_two_numbers(0, 0) == 0
    assert add_two_numbers(100, 200) == 300
```


## sandbox_repo\app\main.py

```python
def add(a, b):
    """
    Add two numbers and return the result.

    Args:
    a (int or float): The first number.
    b (int or float): The second number.

    Returns:
    int or float: The sum of the two numbers.
    """
    return a + b
```


## src\sandbox_logs\repair_20250713_125710_fixed.py

```python
エラーの内容から見ると、Pythonのコードではなく、コメント部分に非ASCII文字（日本語）が含まれていることが原因でSyntaxErrorが発生しています。Pythonのコメントは基本的にASCII文字のみを使用するべきです。

また、関数の内容自体も間違っているようです。addという関数名から推測するに、この関数は2つの数値を加算することが期待されますが、現在の実装では引き算を行っています。

これらの問題を修正したコードは以下の通りです。

```python
def add(a, b):
    return a + b  # Corrected from subtraction to addition
```

ただし、エラーメッセージにはユニットテストの実行に関する情報も含まれています。この情報から推測するに、このコードはユニットテストの一部として実行されている可能性があります。その場合、テストコードも同様に修正する必要があります。ただし、具体的なテストコードが示されていないため、その部分については具体的な修正案を提供できません。
```


## src\sandbox_logs\repair_20250713_125723_original.py

```python
エラーの内容から見ると、Pythonのコードではなく、コメント部分に非ASCII文字（日本語）が含まれていることが原因でSyntaxErrorが発生しています。Pythonのコメントは基本的にASCII文字のみを使用するべきです。

また、関数の内容自体も間違っているようです。addという関数名から推測するに、この関数は2つの数値を加算することが期待されますが、現在の実装では引き算を行っています。

これらの問題を修正したコードは以下の通りです。

```python
def add(a, b):
    return a + b  # Corrected from subtraction to addition
```

ただし、エラーメッセージにはユニットテストの実行に関する情報も含まれています。この情報から推測するに、このコードはユニットテストの一部として実行されている可能性があります。その場合、テストコードも同様に修正する必要があります。ただし、具体的なテストコードが示されていないため、その部分については具体的な修正案を提供できません。
```


## src\sandbox_output\test_sample.py

```python
import pytest
from sample import is_prime

def test_is_prime():
    assert is_prime(2) == True
    assert is_prime(3) == True
    assert is_prime(4) == False
    assert is_prime(5) == True
    assert is_prime(20) == False
    assert is_prime(23) == True
    assert is_prime(1) == False
    assert is_prime(-1) == False
```


## src\sandbox_logs\repair_20250713_114552_fixed.py

```python
ここでのエラーはPythonのコード自体に問題があるわけではなく、テストモジュールのインポートに失敗していることが原因となっています。したがって、Pythonのコードを修正することで解決する問題ではありません。

エラーメッセージを見ると、'C:\\Users\\USER\\AppData\\Local\\Temp\\tmpjgrmw9nh\\test_main'というモジュールが見つからないという内容です。これは、テストを実行する際に必要なモジュールが適切な場所に存在しない、または適切な名前で存在しない可能性があります。

解決策としては、以下のことを確認してみてください。

1. テストモジュールが正しい場所に存在しているか確認する。
2. テストモジュールの名前が正しいか確認する。
3. Pythonのパス設定が正しいか確認する。

これらを確認・修正した上で再度テストを実行してみてください。
```


## src\sandbox_logs\repair_20250713_124402_fixed.py

```python
元のコードには二つの問題があります。一つは、関数`add`が実際には引数を減算していること、もう一つは、エラーメッセージから見て、Pythonのコードが日本語のコメントで始まっていることです。PythonはデフォルトでASCII文字しか受け付けないため、日本語のコメントが原因でエラーが発生しています。

以下に修正したコードを示します：

```python
# 以下は、指定されたPythonコードに対するpytest形式のユニットテストです。
def add(a, b):
    return a + b  # 修正：return a - bからreturn a + bへ
```

この修正により、関数`add`は引数を正しく加算し、日本語のコメントもASCII文字に変換されてエラーが解消されます。
```


## src\sandbox_logs\repair_20250713_124414_original.py

```python
元のコードには二つの問題があります。一つは、関数`add`が実際には引数を減算していること、もう一つは、エラーメッセージから見て、Pythonのコードが日本語のコメントで始まっていることです。PythonはデフォルトでASCII文字しか受け付けないため、日本語のコメントが原因でエラーが発生しています。

以下に修正したコードを示します：

```python
# 以下は、指定されたPythonコードに対するpytest形式のユニットテストです。
def add(a, b):
    return a + b  # 修正：return a - bからreturn a + bへ
```

この修正により、関数`add`は引数を正しく加算し、日本語のコメントもASCII文字に変換されてエラーが解消されます。
```


## src\sandbox_logs\repair_20250713_213319_fixed.py

```python
申し訳ありませんが、テスト対象のPythonコードが具体的に提供されていないため、具体的な修正コードを生成することができません。ただし、エラーメッセージから推測するに、テストコードの先頭に非ASCII文字（この場合は日本語）が含まれていることが問題のようです。

Pythonのソースコードに非ASCII文字を使用する場合、ファイルの先頭に文字エンコーディングを指定することが一般的です。以下のように、ファイルの先頭に文字エンコーディングを指定します：

```python
# -*- coding: utf-8 -*-
```

この行を追加すると、PythonはファイルがUTF-8でエンコードされていることを認識し、非ASCII文字を正しく処理できます。

ただし、この修正が問題を解決するかどうかは、テストコードの他の部分にどのような内容が含まれているかによります。
```


## src\sandbox_logs\repair_20250713_213331_original.py

```python
申し訳ありませんが、テスト対象のPythonコードが具体的に提供されていないため、具体的な修正コードを生成することができません。ただし、エラーメッセージから推測するに、テストコードの先頭に非ASCII文字（この場合は日本語）が含まれていることが問題のようです。

Pythonのソースコードに非ASCII文字を使用する場合、ファイルの先頭に文字エンコーディングを指定することが一般的です。以下のように、ファイルの先頭に文字エンコーディングを指定します：

```python
# -*- coding: utf-8 -*-
```

この行を追加すると、PythonはファイルがUTF-8でエンコードされていることを認識し、非ASCII文字を正しく処理できます。

ただし、この修正が問題を解決するかどうかは、テストコードの他の部分にどのような内容が含まれているかによります。
```


## src\sandbox_logs\repair_20250713_121010_fixed.py

```python
エラーの内容を見ると、Pythonのコードが日本語で書かれているためにSyntaxErrorが発生しているようです。Pythonのコードは英語で書く必要があります。

また、関数名がaddなのに、実際の処理が引き算になっているのも問題です。これを加算に修正する必要があります。

修正後のコードは以下の通りです。

```python
def add(a, b):
    return a + b
```
```


## src\sandbox_logs\repair_20250713_121031_original.py

```python
エラーの内容を見ると、Pythonのコードが日本語で書かれているためにSyntaxErrorが発生しているようです。Pythonのコードは英語で書く必要があります。

また、関数名がaddなのに、実際の処理が引き算になっているのも問題です。これを加算に修正する必要があります。

修正後のコードは以下の通りです。

```python
def add(a, b):
    return a + b
```
```


## src\sandbox_logs\repair_20250713_124433_fixed.py

```python
```python
# This is a pytest-style unit test for the provided Python code.
def add(a, b):
    return a + b  # Fixed: changed from return a - b to return a + b
```
エラーメッセージを見ると、Pythonのコード内で無効な文字が使われていることが原因でエラーが発生しています。具体的には、日本語の文字「、」が原因でエラーが発生しています。

しかし、提供されたコードにはそのような文字は存在しないため、エラーが発生した原因を特定することは難しいです。エラーメッセージに記載されているファイルパスを見ると、エラーはユーザーのローカル環境で発生しているようです。そのため、ユーザーがローカル環境で何かしらの操作を行った結果、エラーが発生した可能性があります。

したがって、提供されたコード自体には問題がないと考えられます。ユーザーには、ローカル環境での操作を見直すか、エラーが発生した環境での詳細な情報を提供してもらうことをおすすめします。
```


## src\sandbox_logs\repair_20250713_131857_fixed.py

```python
```python
def add(a, b):
    return a + b

def test_add():
    assert add(1, 2) == 3
    assert add(-1, 1) == 0
    assert add(0, 0) == 0
```
エラーメッセージから、Pythonのコード内に無効な文字（'、'）があることが原因と推測されます。そのため、その部分を削除しました。また、元のコードには「# Corrected from subtraction to addition」というコメントがありましたが、これは誤解を招く可能性があるため削除しました。
```


## src\sandbox_logs\repair_20250713_142329_fixed.py

```python
申し訳ありませんが、具体的なPythonコードが提供されていないため、修正済みのコードを提供することができません。ただし、エラーメッセージから推測すると、Pythonコード内に非ASCII文字（この場合は日本語）が含まれているためにエラーが発生しているようです。

PythonはASCII文字以外もサポートしていますが、その場合はファイルの先頭に文字コードを示す特別なコメント（マジックコメント）を記述する必要があります。以下のように、ファイルの先頭に`# -*- coding: utf-8 -*-`を追加すると、UTF-8でエンコードされた非ASCII文字を含むPythonコードを正しく解釈できます。

```python
# -*- coding: utf-8 -*-
# ここでは、簡単なPythonの関数とそのためのpytest形式のユニットテストを提供します。
```

ただし、一般的には、Pythonコード内で非ASCII文字を使用するのは避けるべきです。特に、エラーメッセージに示されているように、非ASCII文字が含まれるとPythonの構文解析が失敗し、`SyntaxError`が発生します。そのため、非ASCII文字を含むコメントやドキュメンテーション文字列以外の部分は、ASCII文字だけを使用するようにしてください。
```


## src\sandbox_logs\repair_20250713_173722_fixed.py

```python
申し訳ありませんが、具体的なPythonコードが示されていないため、特定の関数やクラスに対するpytest形式のユニットテストを生成することはできません。というコメントは非ASCII文字を含んでいるため、エラーが発生しています。PythonのコメントはASCII文字のみをサポートしていますので、非ASCII文字を含むコメントは適切にエンコードするか、ASCII文字のみを使用するように変更する必要があります。

以下に修正例を示します。

--- 修正済みコード ---
```python
# Sorry, but without specific Python code, it's impossible to generate pytest-style unit tests for specific functions or classes.
```

この修正では、非ASCII文字を含むコメントをASCII文字のみを使用するように英語に変更しました。
```


## src\sandbox_logs\repair_20250713_173733_original.py

```python
申し訳ありませんが、具体的なPythonコードが示されていないため、特定の関数やクラスに対するpytest形式のユニットテストを生成することはできません。というコメントは非ASCII文字を含んでいるため、エラーが発生しています。PythonのコメントはASCII文字のみをサポートしていますので、非ASCII文字を含むコメントは適切にエンコードするか、ASCII文字のみを使用するように変更する必要があります。

以下に修正例を示します。

--- 修正済みコード ---
```python
# Sorry, but without specific Python code, it's impossible to generate pytest-style unit tests for specific functions or classes.
```

この修正では、非ASCII文字を含むコメントをASCII文字のみを使用するように英語に変更しました。
```


## my-crm-app\app\models.py

```python
# TODO: Define database models

from . import db

class Customer(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    # TODO: Add more fields as necessary

```


## src\sandbox_logs\repair_20250713_114519_fixed.py

```python
エラーメッセージを見ると、テストモジュールのインポートに失敗しているようです。これはPythonのコードに問題があるというよりは、テスト環境の設定やファイルの配置に問題がある可能性が高いです。ユーザーが提供したコードの中には、確かに間違いがありますが、それがこのエラーの原因ではないようです。

ただし、ユーザーが指摘した通り、関数addの中の演算が間違っています。正しくは以下のようになります。

--- 修正済みコード ---
```python
def add(a, b):
    return a + b  # ✔️ a + b
```
```


## src\sandbox_logs\repair_20250713_114534_original.py

```python
エラーメッセージを見ると、テストモジュールのインポートに失敗しているようです。これはPythonのコードに問題があるというよりは、テスト環境の設定やファイルの配置に問題がある可能性が高いです。ユーザーが提供したコードの中には、確かに間違いがありますが、それがこのエラーの原因ではないようです。

ただし、ユーザーが指摘した通り、関数addの中の演算が間違っています。正しくは以下のようになります。

--- 修正済みコード ---
```python
def add(a, b):
    return a + b  # ✔️ a + b
```
```


## src\sandbox_logs\repair_20250713_131843_fixed.py

```python
```python
def add(a, b):
    return a + b  # Corrected from subtraction to addition

def test_add():
    assert add(1, 2) == 3
    assert add(-1, 1) == 0
    assert add(0, 0) == 0
```
```


## src\sandbox_logs\repair_20250713_131857_original.py

```python
```python
def add(a, b):
    return a + b  # Corrected from subtraction to addition

def test_add():
    assert add(1, 2) == 3
    assert add(-1, 1) == 0
    assert add(0, 0) == 0
```
```


## src\sandbox_logs\repair_20250713_142257_fixed.py

```python
エラーメッセージから、Pythonコード内に無効な文字（'、'）が存在することが原因であることがわかります。PythonはASCII文字とUnicode文字をサポートしていますが、コード内のコメントや文字列以外の場所で非ASCII文字を使用することは推奨されていません。

したがって、このエラーを修正するには、無効な文字を削除または適切なASCII文字に置き換える必要があります。

ただし、提供されたコードにはそのような文字は見当たらないため、エラーが発生した具体的なコードが不明です。そのため、具体的な修正コードを提供することはできません。

ただし、一般的なアドバイスとして、Pythonコード内で非ASCII文字を使用する場合は、それらをコメントや文字列内に限定し、それ以外の場所ではASCII文字のみを使用するようにすると良いでしょう。
```


## src\sandbox_logs\repair_20250713_142312_original.py

```python
エラーメッセージから、Pythonコード内に無効な文字（'、'）が存在することが原因であることがわかります。PythonはASCII文字とUnicode文字をサポートしていますが、コード内のコメントや文字列以外の場所で非ASCII文字を使用することは推奨されていません。

したがって、このエラーを修正するには、無効な文字を削除または適切なASCII文字に置き換える必要があります。

ただし、提供されたコードにはそのような文字は見当たらないため、エラーが発生した具体的なコードが不明です。そのため、具体的な修正コードを提供することはできません。

ただし、一般的なアドバイスとして、Pythonコード内で非ASCII文字を使用する場合は、それらをコメントや文字列内に限定し、それ以外の場所ではASCII文字のみを使用するようにすると良いでしょう。
```


## src\sandbox_logs\repair_20250713_174027_fixed.py

```python
申し訳ありませんが、具体的なPythonコードが提供されていないため、具体的な修正コードを提供することができません。ただし、エラーメッセージから推測するに、'test_main.py' ファイルの1行目に無効な文字が含まれているようです。以下のように修正することをおすすめします。

--- 修正例 ---
# 1行目の日本語コメントを削除または英語に変更します。
# 以下は一例です。

# Sorry, but I can't create a specific unit test because no specific Python code has been provided.
```


## src\sandbox_logs\repair_20250713_174037_original.py

```python
申し訳ありませんが、具体的なPythonコードが提供されていないため、具体的な修正コードを提供することができません。ただし、エラーメッセージから推測するに、'test_main.py' ファイルの1行目に無効な文字が含まれているようです。以下のように修正することをおすすめします。

--- 修正例 ---
# 1行目の日本語コメントを削除または英語に変更します。
# 以下は一例です。

# Sorry, but I can't create a specific unit test because no specific Python code has been provided.
```


## src\sandbox_logs\repair_20250713_213522_original.py

```python
def is_prime(n):
    if n <= 1:
        return False
    for i in range(2, int(n**0.5) + 1):
        if n % i == 0:
            return False
    return True
```


## src\sandbox_output\sample.py

```python
def is_prime(n):
    if n < 2:
        return False
    for i in range(2, int(n**0.5) + 1):
        if n % i == 0:
            return False
    return True
```


## src\nexuscore\agents\requirement_agent.py

```python
# ==============================================================================
# ファイル: src/nexuscore/agents/requirement_agent.py
# 版数  : v.fix-28 + budget-hook
# 変更点:
#   - Step2: 予算フック on_budget_tick を追加し、LLM実行直前に1行呼ぶ
#     * interpret_user_input / _generate_suggestions / generate_intermediate_spec
# 他は既存仕様（FSM, UI, JSONサニタイズ等）を維持
# ==============================================================================

from __future__ import annotations
import os
import re
import json
import uuid
import gradio as gr
from typing import Dict, List, Optional, Any, Set, Callable
from datetime import datetime

# --- 依存（BaseAgent / json_sanitizer） ---
try:
    from .base_agent import BaseAgent
    from ..utils.json_sanitizer import sanitize_json_like
except ImportError:
    # --- フォールバック定義 ---
    def sanitize_json_like(payload: Any) -> Any: return payload
    class BaseAgent:
        def __init__(self, *args, **kwargs): print("警告: BaseAgentが見つかりません。（フォールバック）")
        def execute_llm_task(self, prompt: str, as_json: bool = False) -> str:
            return "{}"
        def _call_llm(self, prompt: str, system_prompt: str, as_json: bool = False) -> str:
            return self.execute_llm_task(prompt, as_json)

# --- 定数/ディレクトリ ---
SESSIONS_DIR = os.path.join(os.path.dirname(__file__), '..', '..', 'logs', 'requirement_sessions')
os.makedirs(SESSIONS_DIR, exist_ok=True)

SUPPORTED_LANGS = {"ja": "日本語", "en": "English"}

# --- UIテキスト ---
UI_TEXT = {
    "ja": {
        "title": "Requirement Agent",
        "send": "送信",
        "finish": "この内容で仕様書を作成",
        "mid_draft_btn": "中間仕様書を作成",
        "draft_label": "中間仕様書（Draft）",
        "final_spec": "最終要求仕様書",
        "hearing_intro": "承知いたしました。では、要求を具体化するためにいくつか質問させてください。",
        "first_ai_done": "ありがとうございます。すべての基本項目についてお伺いしました。ここからは内容を洗練させていきましょう。追加や変更、提案依頼など、ご自由にお申し付けください。",
        "acknowledge_addition": "承知いたしました。ご要望を反映しました。他に何かございますか？",
        "suggestion_intro": "承知いたしました。現在の要件に基づき、以下の拡張案を提案します。",
        "gen_fail": "仕様書の生成に失敗しました。",
        "status_label": "状態",
        "chat_label": "対話履歴",
        "input_label": "要求入力",
        "input_ph": "具体的な機能・非機能・方針などをご自由に入力してください…",
        "thanks_and_wait": "ありがとうございます。仕様書を作成します…",
        "ask_to_type": "入力をお願いします。",
        "boot_msg": "Gradio UIを起動します。ブラウザで対話を行ってください。",
        "progress_label": "進捗",
        "lang_select": "UI言語",
        # ワンクリックボタン
        "yes_btn": "はい",
        "no_btn": "いいえ",
        "suggest_btn": "提案して",
    },
    "en": {
        "title": "Requirement Agent",
        "send": "Send",
        "finish": "Generate Final Spec",
        "mid_draft_btn": "Create Draft Spec",
        "draft_label": "Draft Requirements",
        "final_spec": "Final Requirements",
        "hearing_intro": "Understood. Let me ask a few questions.",
        "first_ai_done": "Thanks. We covered the basics. Feel free to ask for additions, changes, or suggestions.",
        "acknowledge_addition": "Acknowledged. Your request has been reflected. Anything else?",
        "suggestion_intro": "Based on the current requirements, I suggest the following extensions:",
        "gen_fail": "Failed to generate the specification.",
        "status_label": "Status",
        "chat_label": "Conversation",
        "input_label": "Requirement input",
        "input_ph": "Describe features / NFRs / policies…",
        "thanks_and_wait": "Thanks. Generating the specification…",
        "ask_to_type": "Please type something.",
        "boot_msg": "Launching Gradio UI. Please use your browser.",
        "progress_label": "Progress",
        "lang_select": "UI Language",
        # Quick buttons
        "yes_btn": "Yes",
        "no_btn": "No",
        "suggest_btn": "Suggest",
    }
}

SYSTEM_PROMPTS = {
    "ja": {
        "interpretation": "# 命令: ユーザーの意図を抽出し、JSONで出力。コードフェンス禁止。",
        "spec": "# 命令: スロット情報と対話履歴を基に、要求仕様書(JSON)を生成。未定は'tbd'。",
        "suggest": "# 命令: 既存の要求仕様に基づき、革新的な拡張案を3つ提案。JSONで出力。"
    },
    "en": {
        "interpretation": "# Instruction: Extract user intent and output as JSON. No code fences.",
        "spec": "# Instruction: Generate a requirements spec (JSON) from slots and history. Use 'tbd' for undefined items.",
        "suggest": "# Instruction: Suggest 3 innovative extensions based on current specs. Output as JSON."
    }
}

# --- 人間仕様言語マッピング ---
ANSWER_MAP = {
    "ja": {
        "persona": {
            "1": "個人バイヤー", "１": "個人バイヤー", "個人バイヤー": "個人バイヤー",
            "2": "小規模事業者", "２": "小規模事業者", "小規模事業者": "小規模事業者",
            "3": "企業内担当者", "３": "企業内担当者", "企業内担当者": "企業内担当者",
            "4": "その他",       "４": "その他",       "その他": "その他"
        },
        "data_acquisition_policy": {
            "1": "保守的", "１": "保守的", "保守的": "保守的",
            "2": "標準",   "２": "標準",   "標準": "標準",
            "3": "積極的", "３": "積極的", "積極的": "積極的"
        },
        "non_functional_defaults": {
            "1": "はい", "１": "はい", "はい": "はい",
            "2": "いいえ（後で個別設定）", "２": "いいえ（後で個別設定）", "いいえ": "いいえ（後で個別設定）"
        },
        "risk_policy": {
            "1": "はい", "１": "はい", "はい": "はい",
            "2": "いいえ（個別指定）", "２": "いいえ（個別指定）", "いいえ": "いいえ（個別指定）"
        },
        "core_features": {
            "1": "product_harvesting",  "１": "product_harvesting",
            "2": "competitor_analysis", "２": "competitor_analysis",
            "3": "recommendation",      "３": "recommendation",
            "4": "email_generation",    "４": "email_generation",
            "5": "price_stock_tracking","５": "price_stock_tracking",
            "商品収集": "product_harvesting",
            "競合分析": "competitor_analysis",
            "レコメンド": "recommendation",
            "メール生成": "email_generation",
            "価格/在庫トラッキング": "price_stock_tracking",
            "価格在庫トラッキング": "price_stock_tracking"
        }
    },
    "en": {
        "persona": {
            "1": "Individual Buyer", "Individual Buyer": "Individual Buyer",
            "2": "Small Business",   "Small Business":   "Small Business",
            "3": "Enterprise Staff", "Enterprise Staff": "Enterprise Staff",
            "4": "Other",            "Other":            "Other"
        },
        "data_acquisition_policy": {
            "1": "Conservative", "Conservative": "Conservative",
            "2": "Standard",     "Standard":     "Standard",
            "3": "Aggressive",   "Aggressive":   "Aggressive"
        },
        "non_functional_defaults": {
            "1": "Yes", "Yes": "Yes",
            "2": "No (configure later)", "No": "No (configure later)"
        },
        "risk_policy": {
            "1": "Yes", "Yes": "Yes",
            "2": "No (specify later)", "No": "No (specify later)"
        },
        "core_features": {
            "1": "product_harvesting",
            "2": "competitor_analysis",
            "3": "recommendation",
            "4": "email_generation",
            "5": "price_stock_tracking",
            "Product Harvesting": "product_harvesting",
            "Competitor Analysis": "competitor_analysis",
            "Recommendations": "recommendation",
            "Email Generation": "email_generation",
            "Price/Stock Tracking": "price_stock_tracking"
        }
    }
}

def _to_half_width_digits(s: str) -> str:
    trans = str.maketrans("０１２３４５６７８９", "0123456789")
    return s.translate(trans)

class RequirementAgent(BaseAgent):
    # Orchestrator から注入可能な予算フック
    on_budget_tick: Optional[Callable[[str], None]] = None

    def __init__(self, api_key: str = None, model: str = None, session_id: Optional[str] = None, language: str = "ja"):
        super().__init__(api_key, model)
        self.set_language(language)
        # --- フェーズFSM ---
        self.dialogue_phase: str = "GATHERING"  # GATHERING → VALIDATION → REFINEMENT → FINALIZING
        self.phase_history: List[str] = [self.dialogue_phase]
        self.hearing_completed: bool = False
        self.last_question_text: str = ""
        self.asked_slots: Set[str] = set()

        # --- 進行状態 ---
        self.conversation_history: List[Dict[str, str]] = []
        self.final_requirements: Optional[Dict] = None
        self.session_id = session_id or (datetime.now().strftime("%Y%m%d_%H%M%S") + "_" + uuid.uuid4().hex[:8])

```


## src\sandbox_logs\repair_20250713_125723_fixed.py

```python
```python
def add(a, b):
    return a + b  # Corrected from subtraction to addition
```

エラーメッセージによれば、問題はテストコードのコメント部分にあります。非ASCII文字を含むコメントはPythonの構文エラーを引き起こす可能性があります。したがって、コメントを英語に変更するか、または完全に削除することをお勧めします。
```


## src\sandbox_logs\repair_20250713_125733_original.py

```python
```python
def add(a, b):
    return a + b  # Corrected from subtraction to addition
```

エラーメッセージによれば、問題はテストコードのコメント部分にあります。非ASCII文字を含むコメントはPythonの構文エラーを引き起こす可能性があります。したがって、コメントを英語に変更するか、または完全に削除することをお勧めします。
```


## src\sandbox_logs\repair_20250713_213331_fixed.py

```python
```python
# -*- coding: utf-8 -*-

# 以下に、一般的なPython関数とそのテストコードの例を示します。
```
上記のように、Pythonファイルの先頭に文字エンコーディングを指定することで、非ASCII文字を含むコードも正しく解釈されます。ただし、Python3ではデフォルトでUTF-8が使用されるため、この行は必須ではありません。また、エラーメッセージからは、非ASCII文字が原因であることが示唆されていますが、具体的なコードがないため、他の可能性も排除できません。
```


## src\sandbox_logs\repair_20250713_114534_fixed.py

```python
```python
def add(a, b):
    return a + b  # ✔️ a + b
```
上記のエラーは、テストモジュールのインポートに失敗していることが原因です。これはPythonのコードに問題があるというよりは、テスト環境の設定やファイルの配置に問題がある可能性が高いです。したがって、コードの修正だけでは解決しないかもしれません。テスト環境の設定や、テストファイルの配置を見直すことをおすすめします。
```


## src\sandbox_logs\repair_20250713_114552_original.py

```python
```python
def add(a, b):
    return a + b  # ✔️ a + b
```
上記のエラーは、テストモジュールのインポートに失敗していることが原因です。これはPythonのコードに問題があるというよりは、テスト環境の設定やファイルの配置に問題がある可能性が高いです。したがって、コードの修正だけでは解決しないかもしれません。テスト環境の設定や、テストファイルの配置を見直すことをおすすめします。
```


## src\sandbox_logs\repair_20250713_124414_fixed.py

```python
```python
# This is a pytest-style unit test for the provided Python code.
def add(a, b):
    return a + b  # Fixed: changed from return a - b to return a + b
```
```


## src\sandbox_logs\repair_20250713_124433_original.py

```python
```python
# This is a pytest-style unit test for the provided Python code.
def add(a, b):
    return a + b  # Fixed: changed from return a - b to return a + b
```
```


## src\sandbox_logs\repair_20250713_125733_fixed.py

```python
```python
def add(a, b):
    return a + b  # Corrected from subtraction to addition
```
エラーメッセージが示すように、問題はテストコードのコメント部分にあります。非ASCII文字を含むコメントはPythonの構文エラーを引き起こす可能性があります。したがって、コメントを英語に変更するか、または完全に削除することをお勧めします。
```


## src\sandbox_logs\repair_20250713_134145_fixed.py

```python
```python
# 以下のように、pytest形式のユニットテストを生成します。
def add(a, b):
    return a + b
```
```


## src\sandbox_logs\repair_20250713_134201_original.py

```python
```python
# 以下のように、pytest形式のユニットテストを生成します。
def add(a, b):
    return a + b
```
```


## src\sandbox_logs\repair_20250713_173707_fixed.py

```python
エラーメッセージから見ると、Pythonのコードに非ASCII文字（この場合は日本語）が含まれているためにSyntaxErrorが発生しています。PythonはASCII文字のみをサポートしていますので、非ASCII文字を含むコメントや文字列は適切にエンコードする必要があります。

しかし、このエラーメッセージは具体的なコードを示していないため、具体的な修正方法を提案することは難しいです。ただし、一般的には、非ASCII文字を含むコメントや文字列を削除するか、適切にエンコード（例えば、文字列をUnicodeにする）することで解決できます。

そのため、元のコードが提供されていないため、修正済みのコードを提供することはできません。
```


## src\sandbox_logs\repair_20250713_173722_original.py

```python
エラーメッセージから見ると、Pythonのコードに非ASCII文字（この場合は日本語）が含まれているためにSyntaxErrorが発生しています。PythonはASCII文字のみをサポートしていますので、非ASCII文字を含むコメントや文字列は適切にエンコードする必要があります。

しかし、このエラーメッセージは具体的なコードを示していないため、具体的な修正方法を提案することは難しいです。ただし、一般的には、非ASCII文字を含むコメントや文字列を削除するか、適切にエンコード（例えば、文字列をUnicodeにする）することで解決できます。

そのため、元のコードが提供されていないため、修正済みのコードを提供することはできません。
```


## src\sandbox_logs\repair_20250713_174013_fixed.py

```python
このエラーは、Pythonコード内に無効な文字が含まれているために発生しています。具体的には、日本語の文字「、」がコード内に含まれています。PythonはASCII文字以外をコード内に含めることは許可していません（コメントや文字列リテラルを除く）。したがって、このエラーを解決するためには、この無効な文字を削除または置換する必要があります。

しかし、提供されたコードにはそのような文字は見当たらず、エラーメッセージの内容と一致していないため、具体的な修正コードを提供することはできません。エラーメッセージは「test_main.py」のファイルから発生しているようですが、その内容は提供されていません。

したがって、エラーが発生している「test_main.py」のファイルを確認し、無効な文字を削除または置換することをお勧めします。
```


## src\sandbox_logs\repair_20250713_174027_original.py

```python
このエラーは、Pythonコード内に無効な文字が含まれているために発生しています。具体的には、日本語の文字「、」がコード内に含まれています。PythonはASCII文字以外をコード内に含めることは許可していません（コメントや文字列リテラルを除く）。したがって、このエラーを解決するためには、この無効な文字を削除または置換する必要があります。

しかし、提供されたコードにはそのような文字は見当たらず、エラーメッセージの内容と一致していないため、具体的な修正コードを提供することはできません。エラーメッセージは「test_main.py」のファイルから発生しているようですが、その内容は提供されていません。

したがって、エラーが発生している「test_main.py」のファイルを確認し、無効な文字を削除または置換することをお勧めします。
```


## src\nexuscore\core\orchestrator.py

```python
# ==============================================================================
# 操作するソフト: VSCode (または任意のテキストエディタ)
# フォルダ: src/nexuscore/core/
# ファイル名: orchestrator.py
# バージョン: 4.1 (Governance/Budget Hooks integrated)
#
# 目的:
#  - 既存の v3 系オーケストレータの「観測可能性/堅牢性」を維持しつつ、
#    Step 2（予算フック）、Step 3（コミット抑止）、Step 4（L2ブランチ運用）を追加。
#  - Agent 側の on_budget_tick を一括注入し、constitution の automation_policy に準拠。
# ==============================================================================

from __future__ import annotations

import os
import re
import sys
import json
import time
import uuid
import logging
import subprocess
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Union
from pathlib import Path

# --- 依存エージェントとユーティリティ ---
from nexuscore.agents.requirement_agent import RequirementAgent
from nexuscore.agents.planner_agent import PlannerAgent
from nexuscore.agents.coder_agent import CoderAgent
from nexuscore.agents.tester_agent import TesterAgent
from nexuscore.agents.guardian_agent import GuardianAgent
from nexuscore.agents.architect_agent import ArchitectAgent
from nexuscore.agents.debugger_agent import DebuggerAgent
from nexuscore.agents.postmortem_agent import PostmortemAgent
from nexuscore.agents.knowledge_curator_agent import KnowledgeCuratorAgent
from nexuscore.agents.patch_applier import PatchApplier
from nexuscore.agents.policy_agent import PolicyAgent

from nexuscore.utils import code_analyzer

# --- データベースモジュール ---
from nexuscore.database.state_manager import state_manager
from nexuscore.database.knowledge_base import knowledge_base


def clean_llm_output(text: str) -> str:
    """``` ～ ``` を剥がして中身だけにする簡易サニタイザ"""
    if not text:
        return ""
    m = re.search(r"```(?:python\n)?(.*)```", text, re.DOTALL)
    return m.group(1).strip() if m else text.strip()


@dataclass
class Orchestrator:
    # --- 依存と設定 ---
    project_path: str
    constitution: Dict

    # 主要エージェント（DI可能）
    requirement_agent: RequirementAgent
    architect: ArchitectAgent
    planner: PlannerAgent
    coder: CoderAgent
    tester: TesterAgent
    debugger: DebuggerAgent
    guardian: GuardianAgent
    policy_agent: PolicyAgent
    postmortem_agent: PostmortemAgent
    knowledge_curator_agent: KnowledgeCuratorAgent

    # リトライ等
    max_retries: int = 5
    max_quality_retries: int = 3

    # ロガー
    logger: logging.Logger = field(init=False)
    log_dir: str = field(init=False)
    actor_id: str = "orchestrator-main"

    # 予算状態（タスク毎にリセット）
    _budget_calls: int = field(default=0, init=False)
    _budget_limit: int = field(default=0, init=False)
    _budget_hard_stop: bool = field(default=True, init=False)

    def __post_init__(self):
        self.logger = logging.getLogger(self.__class__.__name__)
        if not self.logger.handlers:
            logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s [%(name)s] %(message)s")
        self.log_dir = os.path.join(self.project_path, ".nexus_logs")
        os.makedirs(self.log_dir, exist_ok=True)
        self.logger.info(f"Production Orchestrator initialized for project: {self.project_path}")
        self.logger.info(f"Logging to: {self.log_dir}")

    # =========================================================
    #  観測可能性: イベント/ステート更新（共通ユーティリティ）
    # =========================================================
    def _emit_event(
        self,
        task_id: str,
        name: str,
        details: Union[str, Dict[str, Any], None] = None,
        *,
        phase: Optional[str] = None,
        attempt: Optional[int] = None,
    ) -> None:
        now = time.time()
        payload = details if isinstance(details, dict) else ({"message": details} if details is not None else {})
        try:
            state_manager.append_event(task_id, {
                "event": name,
                "timestamp": now,
                "phase": phase,
                "attempt": attempt,
                "actor": self.actor_id,
                "details": payload,
            })
        except Exception:
            # ログへのフォールバック
            self.logger.debug(f"[event:{name}] {payload}")

    def _update_task_state(self, task_id: str, phase: str, progress: int,
                           details: Union[str, Dict[str, Any]], attempt: int = 0):
        now = time.time()
        progress = max(0, min(100, int(progress)))  # サニタイズ
        state = {
            "phase": phase,
            "progress": progress,
            "details": details,
            "attempt": attempt,
            "actor": self.actor_id,
            "updated_at": now
        }
        try:
            state_manager.set_task_state(task_id, state)
            self._emit_event(task_id, "state_updated", {"phase": phase, "progress": progress}, phase=phase, attempt=attempt)
        except Exception:
            self.logger.debug(f"[state:{phase}] {details}")

    # =========================================================
    #  予算フック（Step 2）
    # =========================================================
    def _reset_budget(self):
        ap = (self.constitution or {}).get("automation_policy", {})
        budget = ap.get("budget", {})
        self._budget_calls = 0
        self._budget_limit = int(budget.get("max_llm_calls_per_task", 0) or 0)
        self._budget_hard_stop = bool(budget.get("hard_stop_on_exceed", True))

    def _tick_llm_budget(self, step: str, task_id: Optional[str] = None):
        """LLMコールの度に呼ばれる。上限超過で hard_stop なら例外"""
        self._budget_calls += 1
        info = {"step": step, "calls": self._budget_calls, "limit": self._budget_limit}
        if task_id:
            self._emit_event(task_id, "budget_tick", info, phase="BUDGET")
        if self._budget_limit and self._budget_calls > self._budget_limit:
            msg = f"LLM budget exceeded: {self._budget_calls}/{self._budget_limit} at step={step}"
            if self._budget_hard_stop:
                raise RuntimeError(msg)
            self.logger.warning(msg)

    def _bind_budget_hook(self, task_id: Optional[str]):
        """task_id を閉じ込めた on_budget_tick クロージャを返す"""
        return (lambda step: self._tick_llm_budget(step, task_id)) if task_id else (lambda step: self._tick_llm_budget(step))

    # =========================================================
    #  補助: テスト実行/自己修復/品質ゲート
    # =========================================================
    def run_tests(self, test_file_path: str) -> tuple[bool, str]:
        try:
            timeout_sec = int(os.getenv("TEST_TIMEOUT_SEC", "600"))
            result = subprocess.run(
                [sys.executable, "-m", "pytest", os.path.relpath(test_file_path, self.project_path)],
                cwd=self.project_path,
                capture_output=True, text=True, encoding="utf-8", errors="replace",
                check=False, timeout=timeout_sec
            )
            return result.returncode == 0, result.stdout + "\n" + result.stderr
        except subprocess.TimeoutExpired:
            return False, f"Error: TimeoutExpired after {int(os.getenv('TEST_TIMEOUT_SEC', '600'))} seconds."
        except Exception as e:
            return False, f"Error: {e}"

    def _run_and_handle_tests(self, test_file_path: str, task_id: str, attempt: int) -> tuple[bool, str]:
        tests_passed, test_output = self.run_tests(test_file_path)
        if tests_passed:
            self._emit_event(task_id, "tests_passed", {"path": test_file_path}, phase="SELF_HEALING", attempt=attempt + 1)
        else:
            last_line = test_output.strip().splitlines()[-1] if test_output else "unknown error"
            self._emit_event(task_id, "tests_failed", {"error_signature": last_line}, phase="SELF_HEALING", attempt=attempt + 1)
        return tests_passed, test_output

    def _attempt_to_debug(self, test_output: str, source_file_path: str,
                          test_file_path: str, task_id: str, attempt: int) -> bool:
        """DebuggerAgent でパッチ修復を試みる"""
        try:
            files_ctx = {"source_file": source_file_path, "test_file": test_file_path}
            debug_result = self.debugger.debug(test_output, files_ctx)
            if not debug_result or "patch" not in debug_result:
                ret
```


## quality_loop_test_sandbox\app\main.py

```python
# Initial application file

def greet(name):
    return f"Hello, {name}!"
```


## src\sandbox_logs\repair_20250713_174037_fixed.py

```python
# 1行目の日本語コメントを削除または英語に変更します。
# 以下は一例です。

# Sorry, but I can't create a specific unit test because no specific Python code has been provided.
```


## src\sandbox_logs\repair_20250713_213538_fixed.py

```python
申し訳ありませんが、エラー内容からは具体的な修正コードを提供することができません。ただし、非ASCII文字を含むコメントや文字列を削除または英語に置き換えることで問題は解決するはずです。例えば、エラーが発生した行は日本語のコメントと思われますので、それを英語に置き換えると以下のようになります。

--- 修正例 ---
# Sorry, but the test target Python code is not provided, so we cannot generate a specific pytest style unit test. However, we will show a general format below.
```


## src\sandbox_logs\repair_20250713_213549_original.py

```python
申し訳ありませんが、エラー内容からは具体的な修正コードを提供することができません。ただし、非ASCII文字を含むコメントや文字列を削除または英語に置き換えることで問題は解決するはずです。例えば、エラーが発生した行は日本語のコメントと思われますので、それを英語に置き換えると以下のようになります。

--- 修正例 ---
# Sorry, but the test target Python code is not provided, so we cannot generate a specific pytest style unit test. However, we will show a general format below.
```


## src\nexuscore\agents\context_agent.py

```python
#!/usr/bin/env python3
r"""
Context Agent - 完全版（simple版の安定性 + 元版の全機能）
📁 C:\Users\USER\tools\NexusCore\src\nexuscore\agents\context_agent.py
"""

import os
import sys
import json
import threading
import time
from typing import Dict, Optional, Any
from datetime import datetime

# パス問題の解決（simple版の成功要因を統合）
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.join(current_dir, "../../..")
if project_root not in sys.path:
    sys.path.insert(0, project_root)

# 安全なインポート
try:
    from nexuscore.agents.context_analyzer import ContextAnalyzer
    # policy_interfaceはオプション機能の可能性があるため、より安全にインポート
    PolicyInterface = None
    from nexuscore.agents.policy_interface import PolicyInterface
except ImportError:
    # フォールバック: 同じディレクトリから
    from .context_analyzer import ContextAnalyzer
    try:
        from .policy_interface import PolicyInterface
    except ImportError:
        print("⚠️ policy_interface.pyが見つかりません。コマンドライン入力のみ利用可能です。")
        PolicyInterface = None


class ContextAgent:
    def __init__(self, project_root: str = None):
        self.project_root = project_root or self._find_project_root()
        self.context_cache_file = os.path.join(self.project_root, ".nexus_context.json")
        
        # 安全な初期化（simple版の安定性を採用）
        try:
            self.analyzer = ContextAnalyzer(self.project_root)
            # PolicyInterfaceが正常にインポートできた場合のみインスタンス化
            self.policy_interface = PolicyInterface() if PolicyInterface else None
            print("✅ 完全版Context Agent初期化完了")
        except Exception as e:
            print(f"⚠️ 高度機能初期化失敗、基本機能で継続: {e}")
            self.analyzer = None
            self.policy_interface = None
        
        self.context_profile = self.load_or_create_context()

    def _find_project_root(self) -> str:
        """ .git フォルダまたは pyproject.toml を基準にプロジェクトルートを探索 """
        path = os.path.abspath(os.path.dirname(__file__))
        for _ in range(5): # 5階層上まで探索
            if os.path.isdir(os.path.join(path, '.git')) or os.path.isfile(os.path.join(path, 'pyproject.toml')):
                return path
            path = os.path.dirname(path)
        return os.getcwd() # 見つからない場合はカレントディレクトリ

    def load_or_create_context(self) -> Dict:
        """既存コンテキストをロードまたは新規作成"""
        if os.path.exists(self.context_cache_file):
            return self.load_cached_context()
        else:
            return self.create_new_context()
    
    def load_cached_context(self) -> Dict:
        """キャッシュされたコンテキストをロード"""
        try:
            with open(self.context_cache_file, 'r', encoding='utf-8') as f:
                context = json.load(f)
                print(f"✅ キャッシュされたコンテキストをロードしました: {self.context_cache_file}")
                return context
        except Exception as e:
            print(f"⚠️ コンテキストキャッシュの読み込みに失敗: {e}")
            return self.create_new_context()
    
    def create_new_context(self) -> Dict:
        """新規コンテキスト作成（安全版 + 高度機能）"""
        print("🔍 新規コンテキストを作成中...")
        
        # simple版の安全な基本解析
        base_context = self._create_safe_base_context()
        
        # 高度解析（可能であれば）
        if self.analyzer:
            try:
                enhanced_context = self._create_enhanced_context()
                # 安全な基本情報 + 高度情報を統合
                auto_context = {**base_context, **enhanced_context}
                print("✅ 高度解析完了")
            except Exception as e:
                print(f"⚠️ 高度解析失敗、基本解析を使用: {e}")
                auto_context = base_context
        else:
            auto_context = base_context
        
        # 人間確認が必要な項目
        print("\n❓ 開発方針の設定...")
        dev_policy = self.request_human_dev_policy()
        
        context = {**auto_context, "dev_policy": dev_policy}
        self.save_context(context)
        return context
    
    def _create_safe_base_context(self) -> Dict:
        """simple版と同じ安全な基本コンテキスト"""
        return {
            "tech_stack": {
                "frameworks": self._safe_detect_frameworks(),
                "python_version": f"{sys.version_info.major}.{sys.version_info.minor}+"
            },
            "file_structure": {
                "has_src_dir": os.path.exists(os.path.join(self.project_root, "src")),
                "has_tests_dir": os.path.exists(os.path.join(self.project_root, "tests")),
                "has_venv": os.path.exists(os.path.join(self.project_root, "venv")) or os.path.exists(os.path.join(self.project_root, ".venv")),
                "total_files": self._safe_count_files(),
                "python_files": self._safe_count_python_files()
            },
            "dependencies": {
                "external": ["gradio", "openai", "pytest"],
                "internal": ["nexuscore"]
            },
            "environment": {
                "platform": os.name,
                "env_file_exists": os.path.exists(os.path.join(self.project_root, ".env")),
                "in_venv": os.getenv("VIRTUAL_ENV") is not None
            },
            "last_updated": datetime.now().isoformat(),
            "version": "2.1-stable"
        }
    
    def _create_enhanced_context(self) -> Dict:
        """高度解析による追加情報"""
        return {
            "tech_stack_detailed": self.analyzer.detect_tech_stack(),
            "file_structure_detailed": self.analyzer.scan_file_structure(),
            "dependencies_detailed": self.analyzer.parse_dependencies(),
            "environment_detailed": self.analyzer.detect_environment()
        }
    
    def _safe_detect_frameworks(self) -> list:
        """simple版と同じ安全なフレームワーク検出"""
        frameworks = []
        req_file = os.path.join(self.project_root, "requirements.txt")
        
        if os.path.exists(req_file):
            try:
                with open(req_file, 'r', encoding='utf-8') as f:
                    content = f.read().lower()
                    if 'gradio' in content:
                        frameworks.append('gradio')
                    if 'openai' in content:
                        frameworks.append('openai')
                    if 'pytest' in content:
                        frameworks.append('pytest')
                    if 'streamlit' in content:
                        frameworks.append('streamlit')
            except Exception:
                frameworks = ['gradio', 'openai']
        
        return frameworks
    
    def _safe_count_files(self) -> int:
        """安全なファイル数カウント"""
        count = 0
        try:
            for root, dirs, files in os.walk(self.project_root):
                dirs[:] = [d for d in dirs if d not in ['.git', '__pycache__', '.venv', 'node_modules']]
                count += len(files)
                if count > 1000:  # 安全制限
                    break
        except Exception:
            count = 0
        return count
    
    def _safe_count_python_files(self) -> int:
        """安全なPythonファイル数カウント"""
        count = 0
        try:
            for root, dirs, files in os.walk(self.project_root):
                dirs[:] = [d for d in dirs if d not in ['.git', '__pycache__', '.venv', 'node_modules']]
                count += sum(1 for f in files if f.endswith('.py'))
                if count > 500:  # 安全制限
                    break
        except Exception:
            count = 0
        return count
    
    def request_human_dev_policy(self) -> Dict:
        """開発方針の人間確認"""
        # Gradio UIが利用可能であれば使用、そうでなければコマンドライン
        if self.policy_interface:
            try:
                return self.policy_interface.launch_and_wait_for_input(timeout=180)
            except Exception as e:
                print(f"⚠️ Gradio UI失敗、コマンドライン版を使用: {e}")
        
        # コマンドライン版（simple版と同様）
        return self._command_line_policy_setup()
    
    def _command_line_policy_setup(self) -> Dict:
        """コマンドライン版開発方針設定"""
        print("\n🤖 Context Agent: 開発方針を設定してください")
        
        test_policy = self._ask_choice(
            "テストファイルでのインポート方針は？",
            ["関数を直接埋め込み", "インポート文を使用", "混在OK"],
            default=0
        )
        
        error_lang = self._ask_choice(
            "エラーメッセージの言語は？",
            ["日本語", "英語", "自動"],
            default=0
        )
        
        quality_requirements = self._ask_multiple_choice(
  
```
