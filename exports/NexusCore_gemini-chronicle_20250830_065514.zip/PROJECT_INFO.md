# 📦 プロジェクト解析パッケージ情報
## 1. 概要
- 総ファイル数: 374
- 総コード行数: 133,893

## 2. ファイル統計
| 拡張子 | ファイル数 | コード行数 |
|---|---|---|
| `total` | 374 | 133,893 |
| `.py` | 293 | 73,245 |
| `.txt` | 33 | 48,645 |
| `.pyc` | 32 | 2,651 |
| `.html` | 5 | 2,115 |
| `NoExt` | 3 | 6 |
| `.md` | 2 | 193 |
| `.dll` | 2 | 530 |
| `.pdb` | 2 | 6,314 |
| `.hpp` | 1 | 116 |
| `.cpp` | 1 | 78 |

## 3. ディレクトリツリー
```
./ (NexusCore)
├── app
│   └── routes.py
├── evaluation
│   └── evalplus
│       ├── evalplus
│       │   └── _experimental
│       │       └── evaluate_runtime.py
│       └── tools
│           ├── _experimental
│           │   └── evaluate_runtime.py
│           └── tsr
│               └── run.py
├── exported_projects
│   ├── app_20250703_223016
│   │   ├── app
│   │   │   ├── routes
│   │   │   │   └── image_crawler_route.py
│   │   │   └── routes.py
│   │   └── run.py
│   ├── project_export_m73owrzi
│   │   ├── app
│   │   │   ├── routes
│   │   │   │   └── image_crawler_route.py
│   │   │   └── routes.py
│   │   └── run.py
│   ├── project_export_xb_l70t8
│   │   ├── app
│   │   │   ├── routes
│   │   │   │   └── image_crawler_route.py
│   │   │   └── routes.py
│   │   └── run.py
│   └── project_export_y7xxp1v8
│       ├── app
│       │   ├── routes
│       │   │   └── image_crawler_route.py
│       │   └── routes.py
│       └── run.py
├── exports
│   ├── NexusCore_export_dryrun_20250826_230000.txt
│   ├── NexusCore_export_dryrun_20250828_103714.txt
│   ├── NexusCore_export_dryrun_20250828_105714.txt
│   ├── NexusCore_export_dryrun_20250828_124733.txt
│   ├── NexusCore_export_dryrun_20250828_161754.txt
│   ├── NexusCore_export_dryrun_20250829_171752.txt
│   ├── NexusCore_export_run_20250826_235654.txt
│   ├── NexusCore_export_run_20250827_002736.txt
│   ├── NexusCore_export_run_20250827_005738.txt
│   ├── NexusCore_export_run_20250828_125215.txt
│   ├── NexusCore_export_run_20250828_162344.txt
│   ├── NexusCore_export_run_20250829_063315.txt
│   ├── NexusCore_export_run_20250829_114314.txt
│   ├── NexusCore_export_run_20250829_115251.txt
│   ├── NexusCore_export_run_20250829_162420.txt
│   └── NexusCore_export_run_20250829_163001.txt
├── healing_sandbox
│   ├── app
│   │   └── main.py
│   ├── logs
│   │   └── run_log.md
│   ├── sandbox_runner.py
│   ├── src
│   │   └── agents
│   │       └── orchestrator.py
│   └── tests
│       └── test_main.py
├── htmlcov
│   └── z_bdf857e34ba5c820_orchestrator_py.html
├── htmlcov_agents
│   └── z_bdf857e34ba5c820_orchestrator_py.html
├── htmlcov_detailed
│   └── z_bdf857e34ba5c820_orchestrator_py.html
├── htmlcov_final
│   └── z_bdf857e34ba5c820_orchestrator_py.html
├── htmlcov_full
│   └── z_bdf857e34ba5c820_orchestrator_py.html
├── logs
│   ├── NexusCore_export_dryrun_20250828_075409.txt
│   ├── NexusCore_export_dryrun_20250828_103714.txt
│   ├── NexusCore_export_dryrun_20250828_105714.txt
│   ├── NexusCore_export_dryrun_20250828_124733.txt
│   ├── NexusCore_export_dryrun_20250828_161754.txt
│   ├── NexusCore_export_dryrun_20250829_171752.txt
│   ├── NexusCore_export_run_20250827_145240.txt
│   ├── NexusCore_export_run_20250827_152429.txt
│   ├── NexusCore_export_run_20250828_064516.txt
│   ├── NexusCore_export_run_20250828_125215.txt
│   ├── NexusCore_export_run_20250828_162344.txt
│   ├── NexusCore_export_run_20250829_063315.txt
│   ├── NexusCore_export_run_20250829_114314.txt
│   ├── NexusCore_export_run_20250829_115251.txt
│   ├── NexusCore_export_run_20250829_162420.txt
│   └── NexusCore_export_run_20250829_163001.txt
├── main_cli.py
├── my-crm-app
│   ├── app
│   │   ├── main.py
│   │   └── routes.py
│   ├── run.py
│   └── tests
│       └── test_main.py
├── myenv
│   └── Lib
│       └── site-packages
│           └── pip
│               ├── __main__.py
│               ├── __pip-runner__.py
│               ├── _internal
│               │   ├── cli
│               │   │   ├── main.py
│               │   │   └── main_parser.py
│               │   └── main.py
│               └── _vendor
│                   ├── certifi
│                   │   └── __main__.py
│                   ├── distro
│                   │   └── __main__.py
│                   ├── platformdirs
│                   │   ├── __main__.py
│                   │   └── api.py
│                   ├── pygments
│                   │   └── __main__.py
│                   ├── requests
│                   │   └── api.py
│                   ├── rich
│                   │   └── __main__.py
│                   └── truststore
│                       └── _api.py
├── nexus_os_kernel.py
├── openenv
│   └── Lib
│       └── site-packages
│           ├── IPython
│           │   └── __main__.py
│           ├── PIL
│           │   └── __main__.py
│           ├── adodbapi
│           │   ├── __init__.py
│           │   ├── ado_consts.py
│           │   ├── adodbapi.py
│           │   ├── apibase.py
│           │   ├── examples
│           │   │   ├── db_print.py
│           │   │   ├── xls_read.py
│           │   │   └── xls_write.py
│           │   ├── is64bit.py
│           │   ├── process_connect_string.py
│           │   ├── setup.py
│           │   └── test
│           │       ├── adodbapitest.py
│           │       ├── adodbapitestconfig.py
│           │       ├── dbapi20.py
│           │       ├── is64bit.py
│           │       ├── setuptestframework.py
│           │       └── test_adodbapi_dbapi20.py
│           ├── aiohttp
│           │   └── web_runner.py
│           ├── certifi
│           │   └── __main__.py
│           ├── cffi
│           │   └── api.py
│           ├── charset_normalizer
│           │   ├── __main__.py
│           │   ├── api.py
│           │   └── cli
│           │       └── __main__.py
│           ├── debugpy
│           │   ├── __main__.py
│           │   ├── _vendored
│           │   │   └── pydevd
│           │   │       ├── _pydev_runfiles
│           │   │       │   ├── pydev_runfiles.py
│           │   │       │   ├── pydev_runfiles_coverage.py
│           │   │       │   ├── pydev_runfiles_nose.py
│           │   │       │   ├── pydev_runfiles_parallel.py
│           │   │       │   ├── pydev_runfiles_parallel_client.py
│           │   │       │   ├── pydev_runfiles_pytest2.py
│           │   │       │   ├── pydev_runfiles_unittest.py
│           │   │       │   └── pydev_runfiles_xml_rpc.py
│           │   │       ├── _pydevd_bundle
│           │   │       │   ├── _debug_adapter
│           │   │       │   │   └── __main__pydevd_gen_debug_adapter_protocol.py
│           │   │       │   ├── pydevd_api.py
│           │   │       │   ├── pydevd_extension_api.py
│           │   │       │   └── pydevd_runpy.py
│           │   │       ├── _pydevd_frame_eval
│           │   │       │   └── pydevd_frame_eval_main.py
│           │   │       ├── pydev_run_in_console.py
│           │   │       └── pydevd_attach_to_process
│           │   │           ├── run_code_on_dllmain_amd64.dll
│           │   │           ├── run_code_on_dllmain_amd64.pdb
│           │   │           ├── run_code_on_dllmain_x86.dll
│           │   │           ├── run_code_on_dllmain_x86.pdb
│           │   │           ├── winappdbg
│           │   │           │   └── win32
│           │   │           │       ├── advapi32.py
│           │   │           │       ├── psapi.py
│           │   │           │       ├── shlwapi.py
│           │   │           │       └── wtsapi32.py
│           │   │           └── windows
│           │   │               ├── run_code_in_memory.hpp
│           │   │               └── run_code_on_dllmain.cpp
│           │   ├── adapter
│           │   │   └── __main__.py
│           │   ├── launcher
│           │   │   ├── __main__.py
│           │   │   └── winapi.py
│           │   ├── public_api.py
│           │   └── server
│           │       └── api.py
│           ├── distro
│           │   └── __main__.py
│           ├── dotenv
│           │   ├── __main__.py
│           │   └── main.py
│           ├── filelock
│           │   └── _api.py
│           ├── fontTools
│           │   ├── __main__.py
│           │   ├── cu2qu
│           │   │   └── __main__.py
│           │   ├── designspaceLib
│           │   │   └── __main__.py
│           │   ├── feaLib
│           │   │   └── __main__.py
│           │   ├── merge
│           │   │   └── __main__.py
│           │   ├── mtiLib
│           │   │   └── __main__.py
│           │   ├── otlLib
│           │   │   └── optimize
│           │   │       └── __main__.py
│           │   ├── qu2cu
│           │   │   └── __main__.py
│           │   ├── subset
│           │   │   └── __main__.py
│           │   ├── ttLib
│           │   │   └── __main__.py
│           │   ├── varLib
│           │   │   ├── __main__.py
│           │   │   └── instancer
│           │   │       └── __main__.py
│           │   └── voltLib
│           │       └── __main__.py
│           ├── google
│           │   ├── api
│           │   │   ├── annotations_pb2.py
│           │   │   ├── auth_pb2.py
│           │   │   └── billing_pb2.py
│           │   ├── generativeai
│           │   │   └── notebook
│           │   │       └── run_cmd.py
│           │   └── longrunning
│           │       ├── operations_grpc.py
│           │       ├── operations_grpc_pb2.py
│           │       ├── operations_pb2.py
│           │       ├── operations_pb2_grpc.py
│           │       ├── operations_proto.py
│           │       └── operations_proto_pb2.py
│           ├── googleapiclient
│           │   └── discovery_cache
│           │       └── appengine_memcache.py
│           ├── googleapis_common_protos-1.70.0.dist-info
│           │   ├── INSTALLER
│           │   └── top_level.txt
│           ├── greenlet
│           │   └── tests
│           │       └── fail_clearing_run_switches.py
│           ├── grpc
│           │   └── _runtime_protos.py
│           ├── html2text
│           │   └── __main__.py
│           ├── httpx
│           │   └── _main.py
│           ├── huggingface_hub
│           │   └── utils
│           │       └── _runtime.py
│           ├── interpreter
│           │   ├── computer_use
│           │   │   └── tools
│           │   │       └── run.py
│           │   └── core
│           │       ├── computer
│           │       │   └── utils
│           │       │       └── run_applescript.py
│           │       ├── llm
│           │       │   ├── run_function_calling_llm.py
│           │       │   ├── run_text_llm.py
│           │       │   └── run_tool_calling_llm.py
│           │       └── utils
│           │           └── truncate_output.py
│           ├── ipykernel
│           │   ├── __main__.py
│           │   └── trio_runner.py
│           ├── jedi
│           │   ├── __main__.py
│           │   └── inference
│           │       └── compiled
│           │           └── subprocess
│           │               └── __main__.py
│           ├── jinja2
│           │   └── runtime.py
│           ├── jsonschema
│           │   └── __main__.py
│           ├── jupyter_client
│           │   └── runapp.py
│           ├── jupyter_core
│           │   └── __main__.py
│           ├── litellm
│           │   ├── assistants
│           │   │   └── main.py
│           │   ├── batch_completion
│           │   │   └── main.py
│           │   ├── batches
│           │   │   └── main.py
│           │   ├── files
│           │   │   └── main.py
│           │   ├── fine_tuning
│           │   │   └── main.py
│           │   ├── images
│           │   │   └── main.py
│           │   ├── llms
│           │   │   └── vertex_ai
│           │   │       ├── vertex_ai_partner_models
│           │   │       │   └── main.py
│           │   │       └── vertex_model_garden
│           │   │           └── main.py
│           │   ├── main.py
│           │   ├── passthrough
│           │   │   └── main.py
│           │   ├── proxy
│           │   │   └── client
│           │   │       └── cli
│           │   │           └── main.py
│           │   ├── realtime_api
│           │   │   └── main.py
│           │   ├── rerank_api
│           │   │   └── main.py
│           │   ├── responses
│           │   │   └── main.py
│           │   ├── secret_managers
│           │   │   └── main.py
│           │   └── types
│           │       ├── images
│           │       │   └── main.py
│           │       └── responses
│           │           └── main.py
│           ├── main.py
│           ├── markdown_it
│           │   └── main.py
│           ├── numpy
│           │   ├── f2py
│           │   │   └── __main__.py
│           │   └── typing
│           │       └── tests
│           │           └── test_runtime.py
│           ├── openai
│           │   ├── __main__.py
│           │   ├── cli
│           │   │   ├── _api
│           │   │   │   └── _main.py
│           │   │   └── _tools
│           │   │       └── _main.py
│           │   ├── resources
│           │   │   ├── beta
│           │   │   │   └── threads
│           │   │   │       └── runs
│           │   │   │           ├── __init__.py
│           │   │   │           ├── runs.py
│           │   │   │           └── steps.py
│           │   │   └── evals
│           │   │       └── runs
│           │   │           ├── __init__.py
│           │   │           ├── output_items.py
│           │   │           └── runs.py
│           │   └── types
│           │       ├── beta
│           │       │   ├── realtime
│           │       │   │   ├── conversation_item_truncate_event.py
│           │       │   │   ├── conversation_item_truncate_event_param.py
│           │       │   │   └── conversation_item_truncated_event.py
│           │       │   ├── thread_create_and_run_params.py
│           │       │   └── threads
│           │       │       ├── run.py
│           │       │       ├── run_create_params.py
│           │       │       ├── run_list_params.py
│           │       │       ├── run_status.py
│           │       │       ├── run_submit_tool_outputs_params.py
│           │       │       ├── run_update_params.py
│           │       │       └── runs
│           │       │           ├── __init__.py
│           │       │           ├── code_interpreter_logs.py
│           │       │           ├── code_interpreter_output_image.py
│           │       │           ├── code_interpreter_tool_call.py
│           │       │           ├── code_interpreter_tool_call_delta.py
│           │       │           ├── file_search_tool_call.py
│           │       │           ├── file_search_tool_call_delta.py
│           │       │           ├── function_tool_call.py
│           │       │           ├── function_tool_call_delta.py
│           │       │           ├── message_creation_step_details.py
│           │       │           ├── run_step.py
│           │       │           ├── run_step_delta.py
│           │       │           ├── run_step_delta_event.py
│           │       │           ├── run_step_delta_message_delta.py
│           │       │           ├── run_step_include.py
│           │       │           ├── step_list_params.py
│           │       │           ├── step_retrieve_params.py
│           │       │           ├── tool_call.py
│           │       │           ├── tool_call_delta.py
│           │       │           ├── tool_call_delta_object.py
│           │       │           └── tool_calls_step_details.py
│           │       ├── evals
│           │       │   ├── create_eval_completions_run_data_source.py
│           │       │   ├── create_eval_completions_run_data_source_param.py
│           │       │   ├── create_eval_jsonl_run_data_source.py
│           │       │   ├── create_eval_jsonl_run_data_source_param.py
│           │       │   ├── run_cancel_response.py
│           │       │   ├── run_create_params.py
│           │       │   ├── run_create_response.py
│           │       │   ├── run_delete_response.py
│           │       │   ├── run_list_params.py
│           │       │   ├── run_list_response.py
│           │       │   ├── run_retrieve_response.py
│           │       │   └── runs
│           │       │       ├── __init__.py
│           │       │       ├── output_item_list_params.py
│           │       │       ├── output_item_list_response.py
│           │       │       └── output_item_retrieve_response.py
│           │       └── fine_tuning
│           │           └── alpha
│           │               ├── grader_run_params.py
│           │               └── grader_run_response.py
│           ├── pip
│           │   ├── __main__.py
│           │   ├── __pip-runner__.py
│           │   ├── _internal
│           │   │   ├── cli
│           │   │   │   ├── main.py
│           │   │   │   └── main_parser.py
│           │   │   └── main.py
│           │   └── _vendor
│           │       ├── certifi
│           │       │   └── __main__.py
│           │       ├── distro
│           │       │   └── __main__.py
│           │       ├── platformdirs
│           │       │   └── __main__.py
│           │       ├── pygments
│           │       │   └── __main__.py
│           │       └── rich
│           │           └── __main__.py
│           ├── platformdirs
│           │   └── __main__.py
│           ├── playwright
│           │   ├── __main__.py
│           │   └── _impl
│           │       └── _impl_to_api_mapping.py
│           ├── prompt_toolkit
│           │   └── application
│           │       └── run_in_terminal.py
│           ├── psutil
│           │   └── tests
│           │       ├── __main__.py
│           │       └── runner.py
│           ├── pydantic
│           │   ├── main.py
│           │   └── v1
│           │       └── main.py
│           ├── pygments
│           │   └── __main__.py
│           ├── pyperclip
│           │   └── __main__.py
│           ├── pyreadline3
│           │   └── rlmain.py
│           ├── rich
│           │   └── __main__.py
│           ├── runs
│           │   └── __init__.py
│           ├── runs-1.2.2.dist-info
│           │   ├── INSTALLER
│           │   └── WHEEL
│           ├── selenium
│           │   └── webdriver
│           │       └── common
│           │           └── devtools
│           │               ├── v135
│           │               │   └── runtime.py
│           │               ├── v136
│           │               │   └── runtime.py
│           │               └── v137
│           │                   └── runtime.py
│           ├── send2trash
│           │   └── __main__.py
│           ├── setuptools
│           │   └── _vendor
│           │       ├── autocommand
│           │       │   └── automain.py
│           │       ├── backports
│           │       │   └── tarfile
│           │       │       └── __main__.py
│           │       ├── platformdirs
│           │       │   └── __main__.py
│           │       └── wheel
│           │           └── __main__.py
│           ├── shortuuid
│           │   └── main.py
│           ├── termcolor
│           │   └── __main__.py
│           ├── tornado
│           │   └── test
│           │       ├── __main__.py
│           │       └── runtests.py
│           ├── tqdm
│           │   ├── __main__.py
│           │   └── _main.py
│           ├── trio
│           │   ├── __main__.py
│           │   └── _core
│           │       ├── _generated_run.py
│           │       ├── _run.py
│           │       ├── _run_context.py
│           │       └── _tests
│           │           ├── test_run.py
│           │           └── type_tests
│           │               └── run.py
│           ├── typer
│           │   ├── __main__.py
│           │   └── main.py
│           ├── win32
│           │   └── Demos
│           │       └── pipes
│           │           └── runproc.py
│           └── zmq
│               └── log
│                   └── __main__.py
├── policy_test_sandbox
│   └── app
│       └── main.py
├── quality_loop_test_sandbox
│   ├── app
│   │   └── main.py
│   └── tests
│       └── test_main.py
├── run_policy_check_test.py
├── run_quality_gate_test.py
├── run_quality_loop_test.py
├── run_self_healing.py
├── run_tests.py
├── run_vc_scout.py
├── sandbox_repo
│   ├── app
│   │   └── main.py
│   └── tests
│       └── test_main.py
├── simple_context_agent.py
├── src
│   ├── __pycache__
│   │   ├── main_ui.cpython-311.pyc
│   │   ├── main_ui.cpython-312.pyc
│   │   └── main_ui.cpython-313.pyc
│   ├── main_ui.py
│   └── nexuscore
│       ├── api
│       │   └── server.py
│       ├── code_interpreter
│       │   ├── __pycache__
│       │   │   ├── gradio_test_runner.cpython-311.pyc
│       │   │   ├── gradio_test_runner.cpython-312.pyc
│       │   │   ├── gradio_test_runner.cpython-313.pyc
│       │   │   ├── sandbox_runner.cpython-311.pyc
│       │   │   ├── sandbox_runner.cpython-312.pyc
│       │   │   └── sandbox_runner.cpython-313.pyc
│       │   ├── gradio_test_runner.py
│       │   └── sandbox_runner.py
│       ├── core
│       │   ├── __pycache__
│       │   │   ├── orchestrator.cpython-311.pyc
│       │   │   ├── orchestrator.cpython-312.pyc
│       │   │   └── orchestrator.cpython-313.pyc
│       │   └── orchestrator.py
│       └── gradio_app
│           ├── __pycache__
│           │   ├── auto_revision_runner.cpython-311.pyc
│           │   ├── auto_revision_runner.cpython-312.pyc
│           │   └── auto_revision_runner.cpython-313.pyc
│           ├── auto_revision_runner.py
│           └── streamlit_migrated_tab.py
├── tests
│   ├── code_interpreter
│   │   └── test_sandbox_runner_enhanced.py
│   ├── core
│   │   ├── __pycache__
│   │   │   ├── test_orchestrator.cpython-311-pytest-8.4.1.pyc
│   │   │   ├── test_orchestrator.cpython-312-pytest-8.4.1.pyc
│   │   │   ├── test_orchestrator.cpython-313-pytest-8.4.1.pyc
│   │   │   ├── test_orchestrator.cpython-313.pyc
│   │   │   ├── test_orchestrator_enhanced.cpython-311-pytest-8.4.1.pyc
│   │   │   ├── test_orchestrator_enhanced.cpython-312-pytest-8.4.1.pyc
│   │   │   ├── test_orchestrator_enhanced.cpython-313-pytest-8.4.1.pyc
│   │   │   ├── test_orchestrator_enhanced.cpython-313.pyc
│   │   │   ├── test_orchestrator_mega.cpython-311-pytest-8.4.1.pyc
│   │   │   ├── test_orchestrator_ultimate.cpython-311-pytest-8.4.1.pyc
│   │   │   ├── test_orchestrator_ultimate.cpython-312-pytest-8.4.1.pyc
│   │   │   ├── test_orchestrator_ultimate.cpython-313-pytest-8.4.1.pyc
│   │   │   └── test_orchestrator_ultimate.cpython-313.pyc
│   │   ├── test_orchestrator.py
│   │   ├── test_orchestrator_enhanced.py
│   │   ├── test_orchestrator_mega.py
│   │   └── test_orchestrator_ultimate.py
│   ├── gradio_app
│   │   ├── __pycache__
│   │   │   ├── test_auto_revision_runner.cpython-311-pytest-8.4.1.pyc
│   │   │   ├── test_auto_revision_runner.cpython-312-pytest-8.4.1.pyc
│   │   │   ├── test_auto_revision_runner.cpython-313-pytest-8.4.1.pyc
│   │   │   └── test_auto_revision_runner.cpython-313.pyc
│   │   ├── api_key_test.py
│   │   ├── debug_api_key.py
│   │   └── test_auto_revision_runner.py
│   └── test_main_ui.py
├── tree_sitter_languages
│   └── tree-sitter-python
│       └── test
│           └── tags
│               └── main.py
└── workspace
    ├── crm_project
    │   └── app
    │       └── main.py
    ├── default_project
    │   ├── app
    │   │   └── main.py
    │   └── tests
    │       └── test_main.py
    └── test_crm_app
        ├── .nexus_logs
        │   └── run_log.md
        ├── app
        │   └── main.py
        └── tests
            └── test_main.py
```
