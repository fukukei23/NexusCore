# NexusCore - AI Analysis Package

- `PROJECT_CHRONICLE.md`: プロジェクトの進化史
- `PROJECT_INFO.md`: 統計とファイル構造
- `COMBINED_CODE.py`: ソースコード結合ファイル