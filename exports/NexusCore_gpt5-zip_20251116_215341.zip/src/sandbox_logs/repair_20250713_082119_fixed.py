def hello():
    print("Hi")