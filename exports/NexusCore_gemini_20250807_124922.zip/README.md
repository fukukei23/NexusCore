# NexusCore
## 📖 プロジェクト概要
このZIPは、`NexusCore` プロジェクトの重要ファイルを抽出し、Geminiでの解析用に最適化したものです。
## 📁 分析対象
- `C:\Users\USER\tools\NexusCore`
## 🚀 使用方法
このZIPファイルを直接Geminiにアップロードしてください。
## 📋 ファイル構成
- `PROJECT_INFO.md`: プロジェクトの統計情報と、このパッケージの作成方法
- `COMBINED_CODE.py`: 重要度順に結合されたソースコード
- `README.md`: このファイル
