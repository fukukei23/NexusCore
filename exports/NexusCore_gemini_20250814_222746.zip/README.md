# atelier-kyo-manager-NexusCore

## 概要
このZIPは、`atelier-kyo-manager-NexusCore` の重要ファイルを抽出し、Gemini解析に最適化したものです。

## 分析対象
- `C:\Users\USER\tools\atelier-kyo-manager`
- `C:\Users\USER\tools\NexusCore`

## 使い方
このZIPをそのままGeminiにアップロードしてください。

## 構成
- `PROJECT_INFO.md` — 統計/作成方法/ツリー/パス一覧
- `COMBINED_CODE.py` — 重要度順に結合されたソースコード
- `README.md` — このファイル
